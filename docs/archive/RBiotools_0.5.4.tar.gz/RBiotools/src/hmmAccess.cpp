#include <Rcpp.h>
using namespace Rcpp;

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <vector>
// #include <array>
#include <string>

#include <unistd.h>

// Adapted from the final stable release of HMMER2 (2.3.2, October 2003) available at hmmer.org and described in
//   Bioinformatics
//     Profile hidden Markov models
//     Sean R. Eddy
//     DOI: 10.1093/bioinformatics/14.9.755

// Copyright (c) 2021 Michael R. Leuze
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
//   documentation files (the "Software"), to deal in the Software without restriction, including without limitation
//   the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
//   to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//     * The above copyright notice and this permission notice shall be included in all copies or substantial portions
//       of the Software.
//     * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//       TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
//       THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
//       CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
//       DEALINGS IN THE SOFTWARE.





int debug = 0;    // debug = 3 will count function calls

// Function call counters

int AllocPlan7Body_count = 0;
int AllocPlan7Matrix_count = 0;
int AllocPlan7Shell_count = 0;
int AllocTophits_count = 0;
int CreatePlan7Matrix_count = 0;
int DegenerateSymbolScore_count = 0;
int DigitizeSequence_count = 0;
int ExtremeValueP_count = 0;
int FAdd_count = 0;
int FArgMax_count = 0;
int FNorm_count = 0;
int FScale_count = 0;
int FSet_count = 0;
int FSum_count = 0;
int FreePlan7Matrix_count = 0;
int FreePlan7_count = 0;
int GrowTophits_count = 0;
int ILogsum_count = 0;
int LogSum_count = 0;
int P7AllocTrace_count = 0;
int P7FreeTrace_count = 0;
int P7Logoddsify_count = 0;
int P7ParsingViterbi_count = 0;
int P7ReallocTrace_count = 0;
int P7ReverseTrace_count = 0;
int P7SmallViterbiSize_count = 0;
int P7SmallViterbi_count = 0;
int P7TraceScore_count = 0;
int P7ViterbiSize_count = 0;
int P7ViterbiSpaceOK_count = 0;
int P7ViterbiTrace_count = 0;
int P7Viterbi_count = 0;
int P7WeeViterbi_count = 0;
int P7WeeViterbiSize_count = 0;
int PValue_count = 0;
int Plan7Renormalize_count = 0;
int Plan7SetName_count = 0;
int PostprocessSignificantHit_count = 0;
int Prob2Score_count = 0;
int RegisterHit_count = 0;
int ResizePlan7Matrix_count = 0;
int Score2Prob_count = 0;
int Scorify_count = 0;
int SetAlphabet_count = 0;
int Strdup_count = 0;
int StringChop_count = 0;
int SymbolIndex_count = 0;
int TraceDecompose_count = 0;
int TraceScoreCorrection_count = 0;
int TraceSimpleBounds_count = 0;
int TransitionScoreLookup_count = 0;
int ascii2prob_count = 0;
int get_wee_midpt_count = 0;
int read_asc20hmm_count = 0;
int set_degenerate_count = 0;






#define ARC 0
#define BAC 1
#define EUK 2

#define TSU 0
#define SSU 1
#define LSU 2

#define INIT 0
#define FULL 1

#define MAXABET            20   // Could probably be 4, since we are doing only nucleic acid HMMs
#define MAXCODE            24	// maximum degenerate alphabet size (17 or 24)
#define hmmNUCLEIC          2   // Compatibility with squid's kRNA
#define hmmAMINO            3   // Compatibility with squid's kRNA
#define INFTY       987654321
#define INTSCALE       1000.0   // scaling constant for floats to integer scores
#define LOGSUM_TBL      20000   // controls precision of ILogsum()




// RAMLIMIT determines the point at which we switch from fast, full dynamic programming
// to slow, linear-memory divide and conquer dynamic programming algorithms.
// It is the minimum amount of available RAM on the systems the package will run on.
// By default, we assume we have 32 Mb RAM available.
// This value was set in a release of HMMer from October 2003, so it is VERY conservative.

#define RAMLIMIT 32


// Indices for Plan7 main model state transitions.
// Used for indexing hmm->t[k][]
// mnemonic: Transition from Match to Match = TMM

#define TMM  0
#define TMI  1
#define TMD  2
#define TIM  3
#define TII  4
#define TDM  5
#define TDD  6

// Indices for special state types, I: used for dynamic programming xmx[][]
// mnemonic: eXtra Matrix for B state = XMB

#define XMB 0
#define XME 1
#define XMC 2
#define XMJ 3
#define XMN 4

// Indices for special state types, II: used for hmm->xt[] indexing
// mnemonic: eXtra Transition for N state = XTN

#define XTN  0
#define XTE  1
#define XTC  2
#define XTJ  3

// Indices for extra state transitions
// Used for indexing hmm->xt[][].

#define MOVE 0          /* trNB, trEC, trCT, trJB */
#define LOOP 1          /* trNN, trEJ, trCC, trJJ */

// Plan 7 model state types used in traceback structure

#define STBOGUS 0
#define STM     1
#define STD     2
#define STI     3
#define STS     4
#define STN     5
#define STB     6
#define STE     7
#define STC     8
#define STT     9
#define STJ    10




#define PLAN7_HASBITS (1<<0)    /* raised if model has log-odds scores      */
#define PLAN7_DESC    (1<<1)    /* raised if description exists             */
#define PLAN7_RF      (1<<2)    /* raised if #RF annotation available       */
#define PLAN7_CS      (1<<3)    /* raised if #CS annotation available       */
#define PLAN7_XRAY    (1<<4)    /* raised if structural data available      */
#define PLAN7_HASPROB (1<<5)    /* raised if model has probabilities        */
#define PLAN7_HASDNA  (1<<6)    /* raised if protein HMM->DNA seq params set*/
#define PLAN7_STATS   (1<<7)    /* raised if EVD parameters are available   */
#define PLAN7_MAP     (1<<8)    /* raised if alignment map is available     */
#define PLAN7_ACC     (1<<9)    /* raised if accession number is available  */
#define PLAN7_GA      (1<<10)   /* raised if gathering thresholds available */
#define PLAN7_TC      (1<<11)   /* raised if trusted cutoffs available      */
#define PLAN7_NC      (1<<12)   /* raised if noise cutoffs available        */
#define PLAN7_CA      (1<<13)   /* raised if surface accessibility avail.   */

#define sreEXP2(x) (exp((x) * 0.69314718 ))
#define sreLOG2(x) ((x) > 0 ? log(x) * 1.44269504 : -9999.)
#define MAX(a,b)   (((a)>(b))?(a):(b))








// Global variable definitions

char  Alphabet[MAXCODE+1];          /* ACGT, for instance                                    */
int   Alphabet_type;                /* hmmNUCLEIC or hmmAMINO                                */
int   Alphabet_size;                /* uniq alphabet size: 4 or 20                           */
int   Alphabet_iupac;               /* total size of alphabet + IUPAC degen.                 */
char  Degenerate[MAXCODE][MAXABET]; /* 1/0 arrays, for whether IUPAC code includes a residue */
int   DegenCount[MAXCODE];

// Additional parameter settings:

int do_forward = 0;
int do_null2   = 1;











// BEGIN Structure Defintions

/* Structure: HMMFILE
 *
 * Purpose:   An open HMM file or HMM library. See hmmio.c.
 */
struct hmmfile_s {
  FILE    *f;                   /* pointer to file opened for reading           */
//SSIFILE *ssi;                 /* pointer to open SSI index, or NULL           */
  int (*parser)(struct hmmfile_s *, struct plan7_s **);  /* parsing function    */
  int   is_binary;              /* TRUE if format is a binary one               */
  int   byteswap;               /* TRUE if binary and byteswapped               */

  /* Ewan (GeneWise) needs the input API to know the offset of each
   * HMM on the disk, as it's being read. This might be enough
   * support for him. hmmindex also uses this. Ewan, see
   * HMMFilePositionByIndex() for an example of how to use this
   * opaque offset type in the SSI API - the call you need
   * is SSISetFilePosition().
   */
  int       is_seekable;        /* TRUE if we use offsets in this HMM file      */
  int       mode;               /* type of offset                               */
//SSIOFFSET offset;             /* Disk offset for beginning of the current HMM */
};

typedef struct hmmfile_s HMMFILE;







/* Structure: plan7_s
 *  
 * Declaration of a Plan 7 profile-HMM.
 */
struct plan7_s {
  /* Annotation on the model. A name is mandatory.
   * Other fields are optional; whether they are present is
   * flagged in the stateflags bit array.
   *
   * desc is only valid if PLAN7_DESC is set in flags.
   *  acc is only valid if PLAN7_ACC is set in flags.
   *   rf is only valid if PLAN7_RF is set in flags.
   *   cs is only valid if PLAN7_CS is set in flags.
   *   ca is only valid if PLAN7_CA is set in flags.
   *  map is only valid if PLAN7_MAP is set in flags.
   */
  char  *name;                  /* name of the model                    +*/
  char  *acc;                   /* accession number of model (Pfam)     +*/
  char  *desc;                  /* brief description of model           +*/
  char  *rf;                    /* reference line from alignment 0..M   +*/
  char  *cs;                    /* consensus structure line      0..M   +*/
  char  *ca;                    /* consensus accessibility line  0..M    */
  char  *comlog;                /* command line(s) that built model     +*/
  int    nseq;                  /* number of training sequences         +*/
  char  *ctime;                 /* creation date                        +*/
  int   *map;                   /* map of alignment cols onto model 1..M+*/
  int    checksum;              /* checksum of training sequences       +*/

  /* The following are annotations added to support work by Michael Asman,
   * CGR Stockholm. They are not stored in model files; they are only
   * used in model construction.
   *
   * #=GC X-PRM (PRT,PRI) annotation is picked up by hmmbuild and interpreted
   * as specifying which mixture Dirichlet component to use. If these flags
   * are non-NULL, the normal mixture Dirichlet code is bypassed, and a
   * single specific Dirichlet is used at each position.
   */
  int   *tpri;                  /* which transition mixture prior to use */
  int   *mpri;                  /* which match mixture prior to use */
  int   *ipri;                  /* which insert mixture prior to use */

  /* Pfam-specific score cutoffs.
   *
   * ga1, ga2 are valid if PLAN7_GA is set in flags.
   * tc1, tc2 are valid if PLAN7_TC is set in flags.
   * nc1, nc2 are valid if PLAN7_NC is set in flags.
   */
  float  ga1, ga2;              /* per-seq/per-domain gathering thresholds (bits) +*/
  float  tc1, tc2;              /* per-seq/per-domain trusted cutoff (bits)       +*/
  float  nc1, nc2;              /* per-seq/per-domain noise cutoff (bits)         +*/

  /* The main model in probability form: data-dependent probabilities.
   * This is the core Krogh/Haussler model.
   * Transition probabilities are usually accessed as a
   *   two-D array: hmm->t[k][TMM], for instance. They are allocated
   *   such that they can also be stepped through in 1D by pointer
   *   manipulations, for efficiency in DP algorithms.
   */
  int     M;                    /* length of the model (# nodes)        +*/
  float **t;                    /* transition prob's. t[1..M-1][0..6]   +*/
  float **mat;                  /* match emissions.  mat[1..M][0..19]   +*/
  float **ins;                  /* insert emissions. ins[1..M-1][0..19] +*/
  float   tbd1;                 /* B->D1 prob (data dependent)          +*/

  /* The unique states of Plan 7 in probability form.
   * These are the algorithm-dependent, data-independent probabilities.
   * Some parts of the code may briefly use a trick of copying tbd1
   * into begin[0]; this makes it easy to call FChoose() or FNorm()
   * on the resulting vector. However, in general begin[0] is not
   * a valid number.
   */
  float  xt[4][2];              /* N,E,C,J extra states: 2 transitions      +*/
  float *begin;                 /* 1..M B->M state transitions              +*/
  float *end;                   /* 1..M M->E state transitions (!= a dist!) +*/

  /* The null model probabilities.
   */
  float  null[MAXABET];         /* "random sequence" emission prob's     +*/
  float  p1;                    /* null model loop probability           +*/

  /* The model in log-odds score form.
   * These are created from the probabilities by LogoddsifyHMM().
   * By definition, null[] emission scores are all zero.
   * Note that emission distributions are over 26 upper-case letters,
   * not just the unambiguous protein or DNA alphabet: we
   * precalculate the scores for all IUPAC degenerate symbols we
   * may see. Non-IUPAC symbols simply have a -INFTY score.
   *
   * Note the reversed indexing on msc, isc, tsc -- for efficiency reasons.
   * They're not probability vectors any more so we can reorder them
   * without wildly complicating our life.
   *
   * The _mem ptrs are where the real memory is alloc'ed and free'd,
   * as opposed to where it is accessed.
   * This came in with Erik Lindahl's altivec port; it allows alignment on
   * 16-byte boundaries. In the non-altivec code, this is just a little
   * redundancy; tsc and tsc_mem point to the same thing, for example.
   *
   * Only valid if PLAN7_HASBITS is set.
   */
  int  **tsc;                   /* transition scores     [0.6][1.M-1]       -*/
  int  **msc;                   /* match emission scores [0.MAXCODE-1][1.M] -*/
  int  **isc;                   /* ins emission scores [0.MAXCODE-1][1.M-1] -*/
  int    xsc[4][2];             /* N,E,C,J transitions                      -*/
  int   *bsc;                   /* begin transitions     [1.M]              -*/
  int   *esc;                   /* end transitions       [1.M]              -*/
  int  *tsc_mem, *msc_mem, *isc_mem, *bsc_mem, *esc_mem;

  /* DNA translation scoring parameters
   * For aligning protein Plan7 models to DNA sequence.
   * Lookup value for a codon is calculated by pos1 * 16 + pos2 * 4 + pos3,
   * where 'pos1' is the digitized value of the first nucleotide position;
   * if any of the positions are ambiguous codes, lookup value 64 is used
   * (which will generally have a score of zero)
   *
   * Only valid if PLAN7_HASDNA is set.
   */
  int  **dnam;                  /* triplet match scores  [0.64][1.M]       -*/
  int  **dnai;                  /* triplet insert scores [0.64][1.M]       -*/
  int    dna2;                  /* -1 frameshift, doublet emission, M or I -*/
  int    dna4;                  /* +1 frameshift, doublet emission, M or I -*/

  /* P-value and E-value statistical parameters
   * Only valid if PLAN7_STATS is set.
   */
  float  mu;                    /* EVD mu       +*/
  float  lambda;                /* EVD lambda   +*/

  int flags;                    /* bit flags indicating state of HMM, valid data +*/
};






/* Declaration of Plan7 dynamic programming matrix structure.
 */
struct dpmatrix_s {
  int **xmx;                    /* special scores [0.1..N][BECJN]     */
  int **mmx;                    /* match scores [0.1..N][0.1..M]      */
  int **imx;                    /* insert scores [0.1..N][0.1..M-1.M] */
  int **dmx;                    /* delete scores [0.1..N][0.1..M-1.M] */

  /* Hidden ptrs where the real memory is kept; this trick was
   * introduced by Erik Lindahl with the Altivec port; it is used to
   * align xmx, etc. on 16-byte boundaries for cache optimization.
   */
  void *xmx_mem, *mmx_mem, *imx_mem, *dmx_mem;

  /* The other trick brought in w/ the Lindahl Altivec port; dp matrix
   * is retained and grown, rather than reallocated for every HMM or sequence.
   * Keep track of current allocated-for size in rows (sequence length N)
   * and columns (HMM length M). Also keep track of pad sizes: how much
   * we should overallocate rows or columns when we reallocate. If pad = 0,
   * then we're not growable in this dimension.
   */
  int maxN;                     /* alloc'ed for seq of length N; N+1 rows */
  int maxM;                     /* alloc'ed for HMM of length M; M+1 cols */

  int padN;                     /* extra pad in sequence length/rows */
  int padM;                     /* extra pad in HMM length/columns   */
};






/* Structure: p7trace_s
 *
 * Traceback structure for alignments of model to sequence.
 * Each array in a trace_s is 0..tlen-1.
 * Element 0 is always to STATE_S. Element tlen-1 is always to STATE_T.
 */
struct p7trace_s {
  int   tlen;                   /* length of traceback                          */
  char *statetype;              /* state type used for alignment                */
  int  *nodeidx;                /* index of aligned node, 1..M (if M,D,I), or 0 */
  int  *pos;                    /* position in dsq, 1..L, or 0 if none          */
};





/* Structure: hit_s
 *
 * Info about a high-scoring database hit.
 * We keep this info in memory, so we can output a
 * sorted list of high hits at the end.
 *
 * sqfrom and sqto are the coordinates that will be shown
 * in the results, not coords in arrays... therefore, reverse
 * complements have sqfrom > sqto
 */
struct hit_s {
  double sortkey;               /* number to sort by; big is better */
  float  score;                 /* score of the hit                 */
  double pvalue;                /* P-value of the hit               */
  float  mothersc;              /* score of whole sequence          */
  double motherp;               /* P-value of whole sequence        */
  char   *name;                 /* name of the target               */
  char   *acc;                  /* accession of the target          */
  char   *desc;                 /* description of the target        */
  int    sqfrom;                /* start position in seq (1..N)     */
  int    sqto;                  /* end position in seq (1..N)       */
  int    sqlen;                 /* length of sequence (N)           */
  int    hmmfrom;               /* start position in HMM (1..M)     */
  int    hmmto;                 /* end position in HMM (1..M)       */
  int    hmmlen;                /* length of HMM (M)                */
  int    domidx;                /* index of this domain             */
  int    ndom;                  /* total # of domains in this seq   */
};






/* Structure: tophit_s
 *
 * Array of high scoring hits, suitable for efficient sorting
 * when we prepare to output results. "hit" list is NULL and
 * unavailable until after we do a sort.
 */
struct tophit_s {
  struct hit_s **hit;           /* array of ptrs to top scoring hits        */
  struct hit_s  *unsrt;         /* unsorted array                           */
  int            alloc;         /* current allocation size                  */
  int            num;           /* number of hits in list now               */
  int            lump;          /* allocation lumpsize                      */
};






/* struct threshold_s
 * Contains score/evalue threshold settings.
 *
 * made first for hmmpfam:
 * Since we're going to loop over all HMMs in a Pfam (or pfam-like)
 * database in main_loop_{serial,pvm}, and we're going to
 * allow autocutoffs using Pfam GA, NC, TC lines, we will need
 * to reset those cutoffs with each HMM in turn. Therefore the
 * main loops need to know whether they're supposed to be
 * doing autocutoff. This amount of info was unwieldy enough
 * to pass through the argument list that I put it
 * in a structure.
 */
struct threshold_s {
  float  globT;                 /* T parameter: keep only hits > globT bits */
  double globE;                 /* E parameter: keep hits < globE E-value   */
  float  domT;                  /* T parameter for individual domains       */
  double domE;                  /* E parameter for individual domains       */
                                /* autosetting of cutoffs using Pfam annot: */
  enum { CUT_NONE, CUT_GA, CUT_NC, CUT_TC } autocut;
  int   Z;                      /* nseq to base E value calculation on      */
};




// END Structure Defintions







// Auxillary functions

void StringChop(char *s) {
  // Purpose:  Chop trailing whitespace off of a string

  StringChop_count++;

  int   i;

  i = strlen(s) - 1;                     /* set i at last char in string     */
  while (i >= 0 && isspace((int) s[i])) i--;   /* i now at last non-whitespace char, or -1 */
  s[i+1] = '\0';
}


char * Strdup(char *s) {
  // Purpose:  Implementation of the common (but non-ANSI) function strdup()
  // Robust against being passed a NULL pointer.

  Strdup_count++;

  // keyword /new/ changed to variable name /newp/
  char *newp;

  if (s == NULL) return NULL;
  if ((newp = (char *) malloc (strlen(s) +1)) == NULL) return NULL;
  strcpy(newp, s);
  return newp;

  return s;
}



void FSet(float *vec, int n, float value) {
  FSet_count++;

  int x;
  for (x = 0; x < n; x++) vec[x] = value;
}


float FSum(float *vec, int n) {
  FSum_count++;

  float sum = 0.;
  int   x;
  for (x = 0; x < n; x++) sum += vec[x];
  return sum;
}


void FNorm(float *vec, int n) {
  FNorm_count++;

  int    x;
  float  sum;

  sum = FSum(vec, n);
  if (sum != 0.0) for (x = 0; x < n; x++) vec[x] /= sum;
  else            for (x = 0; x < n; x++) vec[x] = 1. / (float) n;
}


void FScale(float *vec, int n, float scale) {
  FScale_count++;

  int x;
  for (x = 0; x < n; x++) vec[x] *= scale;
}


void FAdd(float *vec1, float *vec2, int n) {
  FAdd_count++;

  int x;
  for (x = 0; x < n; x++) vec1[x] += vec2[x];
}



/* Function: LogSum()
 *
 * Purpose:  Returns the log of the sum of two log probabilities.
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *           Note that this is in natural log space, not log_2.
 */
float
LogSum(float p1, float p2)
{
  LogSum_count++;

  if (p1 > p2)
    return (p1-p2 > 50.) ? p1 : p1 + log(1. + exp(p2-p1));
  else
    return (p2-p1 > 50.) ? p2 : p2 + log(1. + exp(p1-p2));
}



/* Function: ILogsum()
 *
 * Purpose:  Return the scaled integer log probability of
 *           the sum of two probabilities p1 and p2, where
 *           p1 and p2 are also given as scaled log probabilities.
 *
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *
 *           For speed, builds a lookup table the first time it's called.
 *           LOGSUM_TBL is set to 20000 by default, in config.h.
 *
 *           Because of the one-time initialization, we have to
 *           be careful in a multithreaded implementation... hence
 *           the use of pthread_once(), which forces us to put
 *           the initialization routine and the lookup table outside
 *           ILogsum(). (Thanks to Henry Gabb at Intel for pointing
 *           out this problem.)
 *
 * Args:     p1,p2 -- scaled integer log_2 probabilities to be summed
 *                    in probability space.
 *
 * Return:   scaled integer log_2 probability of the sum.
 */
static int ilogsum_lookup[LOGSUM_TBL];
static void
init_ilogsum(void)
{
  int i;
  for (i = 0; i < LOGSUM_TBL; i++)
    ilogsum_lookup[i] = (int) (INTSCALE * 1.44269504 *
           (log(1.+exp(0.69314718 * (float) -i/INTSCALE))));
}
int
ILogsum(int p1, int p2)
{
  ILogsum_count++;

  int    diff;

  static int firsttime = 1;
  if (firsttime) { init_ilogsum(); firsttime = 0; }

  diff = p1-p2;
  if      (diff >=  LOGSUM_TBL) return p1;
  else if (diff <= -LOGSUM_TBL) return p2;
  else if (diff > 0)            return p1 + ilogsum_lookup[diff];
  else                          return p2 + ilogsum_lookup[-diff];
}





int
FArgMax(float *vec, int n)
{
  FArgMax_count++;

  int i;
  int best = 0;

  for (i = 1; i < n; i++)
    if (vec[i] > vec[best]) best = i;
  return best;
}




/* Function: SymbolIndex()
 *
 * Purpose:  Convert a symbol to its index in Alphabet[].
 *           Bogus characters are converted to 'X'.
 *           More robust than the SYMIDX() macro but
 *           presumably slower.
 */
unsigned char SymbolIndex(char sym) {
  SymbolIndex_count++;

  char *s;
  return ((s = strchr(Alphabet, (char) toupper((int) sym))) == NULL) ?
          Alphabet_iupac-1 : s - Alphabet;
}


/* Function: Scorify()
 *
 * Purpose:  Convert a scaled integer log-odds score to a floating
 *           point score for output. (could be a macro but who cares.)
 */
float
Scorify(int sc)
{
  Scorify_count++;

  return ((float) sc / INTSCALE);
}


/* Function: Prob2Score()
 *
 * Purpose:  Convert a probability to a scaled integer log_2 odds score.
 *           Round to nearest integer (i.e. note use of +0.5 and floor())
 *           Return the score.
 */
int
Prob2Score(float p, float null)
{
  Prob2Score_count++;

  if   (p == 0.0) return -INFTY;
  else            return (int) floor(0.5 + INTSCALE * sreLOG2(p/null));
}



/* Function: ExtremeValueP()
 *
 * Purpose:  Calculate P(S>x) according to an extreme
 *           value distribution, given x and the parameters
 *           of the distribution (characteristic
 *           value mu, decay constant lambda).
 *
 *           This function is exquisitely prone to
 *           floating point exceptions if it isn't coded
 *           carefully.
 *
 * Args:     x      = score
 *           mu     = characteristic value of extreme value distribution
 *           lambda = decay constant of extreme value distribution
 *
 * Return:   P(S>x)
 */
double
ExtremeValueP(float x, float mu, float lambda)
{
  ExtremeValueP_count++;

  double y;
                        /* avoid exceptions near P=1.0 */
                        /* typical 32-bit sys: if () < -3.6, return 1.0 */
  if ((lambda * (x - mu)) <= -1. * log(-1. * log(DBL_EPSILON))) return 1.0;
                        /* avoid underflow fp exceptions near P=0.0*/
  if ((lambda * (x - mu)) >= 2.3 * (double) DBL_MAX_10_EXP)     return 0.0;
                        /* a roundoff issue arises; use 1 - e^-x --> x for small x */
  y = exp(-1. * lambda * (x - mu));
  if       (y < 1e-7) return y;
  else     return (1.0 - exp(-1. * y));
}




/* Function: PValue()
 * Date:     SRE, Mon Oct 27 12:21:02 1997 [Sanger Centre, UK]
 *
 * Purpose:  Convert an HMM score to a P-value.
 *           We know P(S>x) is bounded by 1 / (1 + exp_2^x) for a bit score of x.
 *           We can also use EVD parameters for a tighter bound if we have
 *           them available.
 *
 * Args:     hmm - model structure, contains EVD parameters
 *           sc  - score in bits
 *
 * Returns:  P value for score significance.
 */
double
PValue(struct plan7_s *hmm, float sc)
{
  PValue_count++;

  double pval;
  double pval2;

                                /* the bound from Bayes */
  if      (sc >= sreLOG2(DBL_MAX))       pval = 0.0;
  else if (sc <= -1. * sreLOG2(DBL_MAX)) pval = 1.0;
  else                        pval = 1. / (1.+sreEXP2(sc));

                                /* try for a better estimate from EVD fit */
  if (hmm != NULL && (hmm->flags & PLAN7_STATS))
    {
      pval2 = ExtremeValueP(sc, hmm->mu, hmm->lambda);
      if (pval2 < pval) pval = pval2;
    }
  return pval;
}













// Plan 7 functions

struct plan7_s * AllocPlan7Shell(void) {
  AllocPlan7Shell_count++;

  if (debug > 1) Rcout << "In AllocPlan7Shell" << std::endl;


  struct plan7_s *hmm;

  // hmm    = (struct plan7_s *) MallocOrDie (sizeof(struct plan7_s));

  hmm    = (struct plan7_s *) malloc(sizeof(struct plan7_s)); if (hmm == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->M = 0;

  hmm->name     = NULL;
  hmm->acc      = NULL;
  hmm->desc     = NULL;
  hmm->rf       = NULL;
  hmm->cs       = NULL;
  hmm->ca       = NULL;
  hmm->comlog   = NULL;
  hmm->nseq     = 0;
  hmm->ctime    = NULL;
  hmm->map      = NULL;
  hmm->checksum = 0;

  hmm->tpri = NULL;
  hmm->mpri = NULL;
  hmm->ipri = NULL;

  hmm->ga1 = hmm->ga2 = 0.0;
  hmm->tc1 = hmm->tc2 = 0.0;
  hmm->nc1 = hmm->nc2 = 0.0;

  hmm->t      = NULL;
  hmm->mat    = NULL;
  hmm->ins    = NULL;

  hmm->tsc     = hmm->msc     = hmm->isc     = NULL;
  // hmm->tsc_mem = hmm->msc_mem = hmm->msc_mem = NULL;
  // Error in HMMER code???             ^ here
  hmm->tsc_mem = hmm->msc_mem = hmm->isc_mem = NULL;

  hmm->begin  = NULL;
  hmm->end    = NULL;

  hmm->bsc = hmm->bsc_mem = NULL;
  hmm->esc = hmm->esc_mem = NULL;

                                /* DNA translation is not enabled by default */
  hmm->dnam   = NULL;
  hmm->dnai   = NULL;
  hmm->dna2   = -INFTY;
  hmm->dna4   = -INFTY;
                        /* statistical parameters set to innocuous empty values */
  hmm->mu     = 0.;
  hmm->lambda = 0.;

  hmm->flags = 0;
  if (debug > 1) Rcout << "Leaving AllocPlan7Shell" << std::endl;
  return hmm;
}



void AllocPlan7Body(struct plan7_s *hmm, int M) {
  AllocPlan7Body_count++;

  if (debug > 1) Rcout << "In AllocPlan7Body" << std::endl;


  // Replace all of the MallocOrDie call with malloc (and exit)

  int k, x;

  hmm->M = M;

  // hmm->rf     = MallocOrDie ((M+2) * sizeof(char));
  // hmm->cs     = MallocOrDie ((M+2) * sizeof(char));
  // hmm->ca     = MallocOrDie ((M+2) * sizeof(char));
  // hmm->map    = MallocOrDie ((M+1) * sizeof(int));

  // hmm->t      = MallocOrDie (M     *           sizeof(float *));
  // hmm->mat    = MallocOrDie ((M+1) *           sizeof(float *));
  // hmm->ins    = MallocOrDie (M     *           sizeof(float *));
  // hmm->t[0]   = MallocOrDie ((7*M)     *       sizeof(float));
  // hmm->mat[0] = MallocOrDie ((MAXABET*(M+1)) * sizeof(float));
  // hmm->ins[0] = MallocOrDie ((MAXABET*M) *     sizeof(float));

  // hmm->tsc     = MallocOrDie (7     *           sizeof(int *));
  // hmm->msc     = MallocOrDie (MAXCODE   *       sizeof(int *));
  // hmm->isc     = MallocOrDie (MAXCODE   *       sizeof(int *));
  // hmm->tsc_mem = MallocOrDie ((7*M)     *       sizeof(int));
  // hmm->msc_mem = MallocOrDie ((MAXCODE*(M+1)) * sizeof(int));
  // hmm->isc_mem = MallocOrDie ((MAXCODE*M) *     sizeof(int));

  hmm->rf      = (char*)   malloc((M+2)           * sizeof(char))  ; if (hmm->rf      == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->cs      = (char*)   malloc((M+2)           * sizeof(char))  ; if (hmm->rf      == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->ca      = (char*)   malloc((M+2)           * sizeof(char))  ; if (hmm->rf      == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->map     = (int*)    malloc((M+1)           * sizeof(int))   ; if (hmm->map     == NULL) Rcpp::stop("Memory allocation failed!\n");

  hmm->t       = (float**) malloc( M              * sizeof(float*)); if (hmm->t       == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->mat     = (float**) malloc((M+1)           * sizeof(float*)); if (hmm->mat     == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->ins     = (float**) malloc( M              * sizeof(float*)); if (hmm->ins     == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->t[0]    = (float*)  malloc((7*M)           * sizeof(float)) ; if (hmm->t[0]    == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->mat[0]  = (float*)  malloc((MAXABET*(M+1)) * sizeof(float)) ; if (hmm->mat[0]  == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->ins[0]  = (float*)  malloc((MAXABET*M)     * sizeof(float)) ; if (hmm->ins[0]  == NULL) Rcpp::stop("Memory allocation failed!\n");

  hmm->tsc     = (int**)   malloc( 7              * sizeof(int*))  ; if (hmm->tsc     == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->msc     = (int**)   malloc( MAXCODE        * sizeof(int*))  ; if (hmm->msc     == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->isc     = (int**)   malloc( MAXCODE        * sizeof(int*))  ; if (hmm->isc     == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->tsc_mem = (int*)    malloc((7*M)           * sizeof(int))   ; if (hmm->tsc_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->msc_mem = (int*)    malloc((MAXCODE*(M+1)) * sizeof(int))   ; if (hmm->msc_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->isc_mem = (int*)    malloc((MAXCODE*M)     * sizeof(int))   ; if (hmm->isc_mem == NULL) Rcpp::stop("Memory allocation failed!\n");


  hmm->tsc[0] = hmm->tsc_mem;
  hmm->msc[0] = hmm->msc_mem;
  hmm->isc[0] = hmm->isc_mem;

  /* note allocation strategy for important 2D arrays -- trying
   * to keep locality as much as possible, cache efficiency etc.
   */
  for (k = 1; k <= M; k++) {
    hmm->mat[k] = hmm->mat[0] + k * MAXABET;
    if (k < M) {
      hmm->ins[k] = hmm->ins[0] + k * MAXABET;
      hmm->t[k]   = hmm->t[0]   + k * 7;
    }
  }
  for (x = 1; x < MAXCODE; x++) {
    hmm->msc[x] = hmm->msc[0] + x * (M+1);
    hmm->isc[x] = hmm->isc[0] + x * M;
  }
  for (x = 0; x < 7; x++)
    hmm->tsc[x] = hmm->tsc[0] + x * M;

  /* tsc[x][0] is used as a boundary condition sometimes [Viterbi()],
   * so set to -inf always.
   */
  for (x = 0; x < 7; x++)
    hmm->tsc[x][0] = -INFTY;

  // hmm->begin  = MallocOrDie  ((M+1) * sizeof(float));
  // hmm->end    = MallocOrDie  ((M+1) * sizeof(float));

  // hmm->bsc_mem  = MallocOrDie  ((M+1) * sizeof(int));
  // hmm->esc_mem  = MallocOrDie  ((M+1) * sizeof(int));

  hmm->begin   = (float*) malloc((M+1) * sizeof(float)) ; if (hmm->begin   == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->end     = (float*) malloc((M+1) * sizeof(float)) ; if (hmm->end     == NULL) Rcpp::stop("Memory allocation failed!\n");

  hmm->bsc_mem = (int*)   malloc((M+1) * sizeof(int))   ; if (hmm->bsc_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  hmm->esc_mem = (int*)   malloc((M+1) * sizeof(int))   ; if (hmm->esc_mem == NULL) Rcpp::stop("Memory allocation failed!\n");

  hmm->bsc = hmm->bsc_mem;
  hmm->esc = hmm->esc_mem;

  if (debug > 1) Rcout << "Leaving AllocPlan7Body" << std::endl;
  return;
}



void FreePlan7(struct plan7_s *hmm) {
  FreePlan7_count++;


  if (debug > 1) Rcout << "In FreePlan7" << std::endl;


  if (hmm->name    != NULL) free(hmm->name);
  if (hmm->acc     != NULL) free(hmm->acc);
  if (hmm->desc    != NULL) free(hmm->desc);
  if (hmm->rf      != NULL) free(hmm->rf);
  if (hmm->cs      != NULL) free(hmm->cs);
  if (hmm->ca      != NULL) free(hmm->ca);
  if (hmm->comlog  != NULL) free(hmm->comlog);
  if (hmm->ctime   != NULL) free(hmm->ctime);
  if (hmm->map     != NULL) free(hmm->map);
  if (hmm->tpri    != NULL) free(hmm->tpri);
  if (hmm->mpri    != NULL) free(hmm->mpri);
  if (hmm->ipri    != NULL) free(hmm->ipri);
  if (hmm->bsc_mem != NULL) free(hmm->bsc_mem);
  if (hmm->begin   != NULL) free(hmm->begin);
  if (hmm->esc_mem != NULL) free(hmm->esc_mem);
  if (hmm->end     != NULL) free(hmm->end);
  if (hmm->msc_mem != NULL) free(hmm->msc_mem);
  if (hmm->isc_mem != NULL) free(hmm->isc_mem);
  if (hmm->tsc_mem != NULL) free(hmm->tsc_mem);
  if (hmm->mat     != NULL) free(hmm->mat[0]);
  if (hmm->ins     != NULL) free(hmm->ins[0]);
  if (hmm->t       != NULL) free(hmm->t[0]);
  if (hmm->msc     != NULL) free(hmm->msc);
  if (hmm->isc     != NULL) free(hmm->isc);
  if (hmm->tsc     != NULL) free(hmm->tsc);
  if (hmm->mat     != NULL) free(hmm->mat);
  if (hmm->ins     != NULL) free(hmm->ins);
  if (hmm->t       != NULL) free(hmm->t);
  if (hmm->dnam    != NULL) free(hmm->dnam);
  if (hmm->dnai    != NULL) free(hmm->dnai);
  free(hmm);
  if (debug > 1) Rcout << "Leaving FreePlan7" << std::endl;
}



void Plan7SetName(struct plan7_s *hmm, char *name) {
  Plan7SetName_count++;

  if (debug > 1) Rcout << "In Plan7SetName" << std::endl;

  if (hmm->name != NULL) free(hmm->name);
  hmm->name = Strdup(name);
  StringChop(hmm->name);
  if (debug > 1) Rcout << "Leaving Plan7SetName" << std::endl;
}



/* Function: Plan7Renormalize()
 *
 * Purpose:  Take an HMM in counts form, and renormalize
 *           all of its probability vectors. Also enforces
 *           Plan7 restrictions on nonexistent transitions.
 *
 * Args:     hmm - the model to renormalize.
 *
 * Return:   (void)
 *           hmm is changed.
 */

void Plan7Renormalize(struct plan7_s *hmm) {
  Plan7Renormalize_count++;

  if (debug > 1) Rcout << "In Plan7Renormalize" << std::endl;

  int   k;                      /* counter for model position */
  int   st;                     /* counter for special states */
  float d;                      /* denominator */

                                /* match emissions */
  for (k = 1; k <= hmm->M; k++)
    FNorm(hmm->mat[k], Alphabet_size);
                                /* insert emissions */
  for (k = 1; k < hmm->M; k++)
    FNorm(hmm->ins[k], Alphabet_size);
                                /* begin transitions */
  d = FSum(hmm->begin+1, hmm->M) + hmm->tbd1;
  FScale(hmm->begin+1, hmm->M, 1./d);
  hmm->tbd1 /= d;
                                /* main model transitions */
  for (k = 1; k < hmm->M; k++)
    {
      d = FSum(hmm->t[k], 3) + hmm->end[k];
      FScale(hmm->t[k], 3, 1./d);
      hmm->end[k] /= d;

      FNorm(hmm->t[k]+3, 2);    /* insert */
      FNorm(hmm->t[k]+5, 2);    /* delete */
    }
                                /* null model emissions */
  FNorm(hmm->null, Alphabet_size);
                                /* special transitions  */
  for (st = 0; st < 4; st++)
    FNorm(hmm->xt[st], 2);
                                /* enforce nonexistent transitions */
                                /* (is this necessary?) */
  hmm->t[0][TDM] = hmm->t[0][TDD] = 0.0;

  hmm->flags &= ~PLAN7_HASBITS; /* clear the log-odds ready flag */
  hmm->flags |= PLAN7_HASPROB;  /* set the probabilities OK flag */
  if (debug > 1) Rcout << "Leaving Plan7Renormalize" << std::endl;

}




















/* Function: set_degenerate()
 *
 * Purpose:  convenience function for setting up
 *           Degenerate[][] global for the alphabet.
 */

// Change second argument type from char to const char
//   this gets rid of the warnings, but will it produce any errors????

// static void set_degenerate(char iupac, char *syms) {

static void set_degenerate(char iupac, const char *syms) {
  set_degenerate_count++;

  if (debug > 1) Rcout << "In set_degenerate" << std::endl;

  // Call to set_degenerate results in
  //   warning: conversion from string literal to char * is deprecated
  // for second parameter.
  // For now, we will live with a warning!

  DegenCount[strchr(Alphabet,iupac)-Alphabet] = strlen(syms);
  while (*syms) {
    Degenerate[strchr(Alphabet,iupac)-Alphabet]
              [strchr(Alphabet,*syms)-Alphabet] = 1;
    syms++;
  }
  if (debug > 1) Rcout << "Leaving set_degenerate" << std::endl;
}







/* Function: SetAlphabet()
 *
 * Purpose:  Set the alphabet globals, given an alphabet type
 *           of either hmmAMINO or hmmNUCLEIC.
 */
void
SetAlphabet(int type)
{
  SetAlphabet_count++;

  if (debug > 1) Rcout << "In SetAlphabet" << std::endl;

  int x;

 /* Because the alphabet information is global, we must
  * be careful to make this a thread-safe function. The mutex
  * (above) takes care of that. But, indeed, it's also
  * just good sense (and more efficient) to simply never
  * allow resetting the alphabet. If type is Alphabet_type,
  * silently return; else die with an alphabet mismatch
  * warning.
  */

  switch(type) {

  case hmmAMINO:
    Alphabet_type     = type;
    strcpy(Alphabet, "ACDEFGHIKLMNPQRSTVWYUBZX");
    Alphabet_size     = 20;
    Alphabet_iupac    = 24;
    for (x = 0; x < Alphabet_iupac; x++) {
      memset(Degenerate[x], 0, Alphabet_size);
    }
    for (x = 0; x < Alphabet_size; x++) {
      Degenerate[x][x] = 1;
      DegenCount[x] = 1;
    }
    set_degenerate('U', "S");   /* selenocysteine is treated as serine */
    set_degenerate('B', "ND");
    set_degenerate('Z', "QE");
    set_degenerate('X', "ACDEFGHIKLMNPQRSTVWY");
    break;

  case hmmNUCLEIC:
    Alphabet_type     = type;
    strcpy(Alphabet, "ACGTUNRYMKSWHBVDX");
    Alphabet_size     = 4;
    Alphabet_iupac    = 17;
    for (x = 0; x < Alphabet_iupac; x++) {
      memset(Degenerate[x], 0, Alphabet_size);
    }
    for (x = 0; x < Alphabet_size; x++) {
      Degenerate[x][x] = 1;
      DegenCount[x] = 1;
    }
    set_degenerate('U', "T");
    set_degenerate('N', "ACGT");
    set_degenerate('X', "ACGT");
    set_degenerate('R', "AG");
    set_degenerate('Y', "CT");
    set_degenerate('M', "AC");
    set_degenerate('K', "GT");
    set_degenerate('S', "CG");
    set_degenerate('W', "AT");
    set_degenerate('H', "ACT");
    set_degenerate('B', "CGT");
    set_degenerate('V', "ACG");
    set_degenerate('D', "AGT");
    break;
  }

  if (debug > 1) Rcout << "Leaving SetAlphabet" << std::endl;
}









/* Function: Score2Prob()
 *
 * Purpose:  Convert an integer log_2 odds score back to a probability;
 *           needs the null model probability, if any, to do the conversion.
 */
float
Score2Prob(int sc, float null)
{
  Score2Prob_count++;

  if (sc == -INFTY) return 0.;
  else              return (null * sreEXP2((float) sc / INTSCALE));
}








/* Function: ascii2prob()
 *
 * Purpose:  Convert a saved string back to a probability.
 */
static float
ascii2prob(char *s, float null)
{
  ascii2prob_count++;

  return (*s == '*') ? 0. : Score2Prob(atoi(s), null);
}










static int read_asc20hmm(FILE *fp, struct plan7_s **ret_hmm) {
  read_asc20hmm_count++;

  if (debug > 1) Rcout << "In read_asc20hmm" << std::endl;


  // A stripped-down version:
  //   Since it only reads the RNAmmer HMMs, much of the defensive programming is removed.

  struct plan7_s *hmm;
  char  buffer[512];
  char *s;
  int   M;
  float p;
  int   k, x;
  int   atype;                  /* alphabet type, hmmAMINO or hmmNUCLEIC */

  // Get the header information: tag/value pairs in any order, ignore unknown tags,
  // stop when "HMM" is reached (signaling start of main model)

  hmm = AllocPlan7Shell();
  M = -1;

  // Things we know already about the RNAmmer HMMs

  atype = hmmNUCLEIC;      // ALPH - alphabet is Nucleic
  SetAlphabet(atype);
                           // RF - reference annotation not present
                           // CF - consensus annotation not present
  hmm->flags |= PLAN7_MAP; // MAP - map annotation IS present


  while (fgets(buffer, 512, fp) != NULL) {
    if      (strncmp(buffer, "NAME ", 5) == 0) Plan7SetName(hmm, buffer+6);
    else if (strncmp(buffer, "LENG ", 5) == 0) M = atoi(buffer+6);
    else if (strncmp(buffer, "NSEQ ", 5) == 0) hmm->nseq = atoi(buffer+6);

    else if (strncmp(buffer, "COM  ", 5) == 0)
      {                         /* Command line log */
        StringChop(buffer+6);
        if (hmm->comlog == NULL)
          hmm->comlog = Strdup(buffer+6);
        else
          {
            // Rewrite ReallocOrDie:
            //   hmm->comlog = ReallocOrDie(hmm->comlog, sizeof(char *) * (strlen(hmm->comlog) + 1 + strlen(buffer+6)));

            hmm->comlog = (char*) realloc(hmm->comlog, sizeof(char*) * (strlen(hmm->comlog) + 1 + strlen(buffer+6)));  if (hmm->comlog == NULL) Rcpp::stop("Memory allocation failed!\n");

            strcat(hmm->comlog, "\n");
            strcat(hmm->comlog, buffer+6);
          }
      }

    else if (strncmp(buffer, "DATE ", 5) == 0)
      {                         /* Date file created */
        StringChop(buffer+6);
        hmm->ctime= Strdup(buffer+6);
      }

    else if (strncmp(buffer, "XT   ", 5) == 0)
      {                         /* Special transition section */
        if ((s = strtok(buffer+6, " \t\n")) == NULL) goto FAILURE;
        for (k = 0; k < 4; k++)
          for (x = 0; x < 2; x++)
            {
              if (s == NULL) goto FAILURE;
              hmm->xt[k][x] = ascii2prob(s, 1.0);
              s = strtok(NULL, " \t\n");
            }
      }

    else if (strncmp(buffer, "NULT ", 5) == 0)
      {                         /* Null model transitions */
        if ((s = strtok(buffer+6, " \t\n")) == NULL) goto FAILURE;
        hmm->p1 = ascii2prob(s, 1.);
        if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
        hmm->p1 = hmm->p1 / (hmm->p1 + ascii2prob(s, 1.0));
      }

    else if (strncmp(buffer, "NULE ", 5) == 0)
      {                         /* Null model emissions */
        s = strtok(buffer+6, " \t\n");
        for (x = 0; x < Alphabet_size; x++) {
          if (s == NULL) goto FAILURE;
          hmm->null[x] = ascii2prob(s, 1./(float)Alphabet_size);
          s = strtok(NULL, " \t\n");
        }
      }

    else if (strncmp(buffer, "EVD  ", 5) == 0)
      {                         /* EVD parameters */
        hmm->flags |= PLAN7_STATS;
        if ((s = strtok(buffer+6, " \t\n")) == NULL) goto FAILURE;
        hmm->mu = atof(s);
        if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
        hmm->lambda = atof(s);
      }

    else if (strncmp(buffer, "CKSUM", 5) == 0) hmm->checksum = atoi(buffer+6);
    else if (strncmp(buffer, "HMM  ", 5) == 0) break;
  }

                                /* partial check for mandatory fields */
  if (feof(fp))                goto FAILURE;
  if (M < 1)                         goto FAILURE;
  if (hmm->name == NULL)             goto FAILURE;

  /* Main model section. Read as integer log odds, convert
   * to probabilities
   */
  AllocPlan7Body(hmm, M);
                                /* skip an annotation line */
  if (fgets(buffer, 512, fp) == NULL)  goto FAILURE;
                                /* parse tbd1 line */
  if (fgets(buffer, 512, fp) == NULL)  goto FAILURE;
  if ((s = strtok(buffer, " \t\n")) == NULL) goto FAILURE;
  p = ascii2prob(s, 1.0);
  if ((s = strtok(NULL,   " \t\n")) == NULL) goto FAILURE;
  if ((s = strtok(NULL,   " \t\n")) == NULL) goto FAILURE;
  hmm->tbd1 = ascii2prob(s, 1.0);
  hmm->tbd1 = hmm->tbd1 / (p + hmm->tbd1);

                                /* main model */
  for (k = 1; k <= hmm->M; k++) {
                                /* Line 1: k, match emissions, map */
    if (fgets(buffer, 512, fp) == NULL)  goto FAILURE;
    if ((s = strtok(buffer, " \t\n")) == NULL) goto FAILURE;
    if (atoi(s) != k)                          goto FAILURE;
    for (x = 0; x < Alphabet_size; x++) {
      if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
      hmm->mat[k][x] = ascii2prob(s, hmm->null[x]);
    }
    if (hmm->flags & PLAN7_MAP) {
      if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
      hmm->map[k] = atoi(s);
    }
                                /* Line 2:  RF and insert emissions */
    if (fgets(buffer, 512, fp) == NULL)  goto FAILURE;
    if ((s = strtok(buffer, " \t\n")) == NULL) goto FAILURE;
    if (hmm->flags & PLAN7_RF) hmm->rf[k] = *s;
    if (k < hmm->M) {
      for (x = 0; x < Alphabet_size; x++) {
        if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
        hmm->ins[k][x] = ascii2prob(s, hmm->null[x]);
      }
    }
                                /* Line 3: CS and transitions */
    if (fgets(buffer, 512, fp) == NULL)  goto FAILURE;
    if ((s = strtok(buffer, " \t\n")) == NULL) goto FAILURE;
    if (hmm->flags & PLAN7_CS) hmm->cs[k] = *s;
    for (x = 0; x < 7; x++) {
      if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
      if (k < hmm->M) hmm->t[k][x] = ascii2prob(s, 1.0);
    }
    if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
    hmm->begin[k] = ascii2prob(s, 1.0);
    if ((s = strtok(NULL, " \t\n")) == NULL) goto FAILURE;
    hmm->end[k] = ascii2prob(s, 1.0);

    if (debug > 1) Rcout << "    End loop " << k << std::endl;   // MRL - Debug

    if (k < hmm->M) {
      for (x = 0; x < 7; x++) {
        if (debug > 1) Rcout << "         t[" << k << "][" << x << "] = " << hmm->t[k][x] << std::endl;   // MRL - Debug
      }
    }

  } /* end loop over main model */

  /* Advance to record separator
   */
  while (fgets(buffer, 512, fp) != NULL)
    if (strncmp(buffer, "//", 2) == 0) break;

  Plan7Renormalize(hmm);        /* Paracel reported bug 6/11/99 */

  /* Set flags and return
   */
  hmm->flags |= PLAN7_HASPROB;  /* probabilities are valid */
  hmm->flags &= ~PLAN7_HASBITS; /* scores are not valid    */

  *ret_hmm = hmm;
  if (debug > 1) Rcout << "Leaving read_asc20hmm" << std::endl;
  return 1;

FAILURE:
  if (hmm  != NULL) FreePlan7(hmm);
  *ret_hmm = NULL;
  return 1;
}








/* Function: CreatePlan7Matrix()
 *
 * Purpose:  Create a dynamic programming matrix for standard Forward,
 *           Backward, or Viterbi, with scores kept as scaled log-odds
 *           integers. Keeps 2D arrays compact in RAM in an attempt
 *           to maximize cache hits.
 *
 *           The mx structure can be dynamically grown, if a new
 *           HMM or seq exceeds the currently allocated size. Dynamic
 *           growing is more efficient than an alloc/free of a whole
 *           matrix for every new target. The ResizePlan7Matrix()
 *           call does this reallocation, if needed. Here, in the
 *           creation step, we set up some pads - to inform the resizing
 *           call how much to overallocate when it realloc's.
 *
 * Args:     N     - N+1 rows are allocated, for sequence.
 *           M     - size of model in nodes
 *           padN  - over-realloc in seq/row dimension, or 0
 *           padM  - over-realloc in HMM/column dimension, or 0
 *
 * Return:   mx
 *           mx is allocated here. Caller frees with FreePlan7Matrix(mx).
 */
struct dpmatrix_s *
CreatePlan7Matrix(int N, int M, int padN, int padM)
{
  CreatePlan7Matrix_count++;

  if (debug > 1) Rcout << "In CreatePlan7Matrix" << std::endl;

  struct dpmatrix_s *mx;
  int i;

  // mx          = (struct dpmatrix_s *) MallocOrDie (sizeof(struct dpmatrix_s));
  // mx->xmx     = (int **) MallocOrDie (sizeof(int *) * (N+1));
  // mx->mmx     = (int **) MallocOrDie (sizeof(int *) * (N+1));
  // mx->imx     = (int **) MallocOrDie (sizeof(int *) * (N+1));
  // mx->dmx     = (int **) MallocOrDie (sizeof(int *) * (N+1));
  // mx->xmx_mem = (void *) MallocOrDie (sizeof(int) * ((N+1)*5));
  // mx->mmx_mem = (void *) MallocOrDie (sizeof(int) * ((N+1)*(M+2)));
  // mx->imx_mem = (void *) MallocOrDie (sizeof(int) * ((N+1)*(M+2)));
  // mx->dmx_mem = (void *) MallocOrDie (sizeof(int) * ((N+1)*(M+2)));

  mx          = (struct dpmatrix_s *) malloc(sizeof(struct dpmatrix_s))    ; if (mx          == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->xmx     = (int **)              malloc(sizeof(int *) * (N+1))        ; if (mx->xmx     == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->mmx     = (int **)              malloc(sizeof(int *) * (N+1))        ; if (mx->mmx     == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->imx     = (int **)              malloc(sizeof(int *) * (N+1))        ; if (mx->imx     == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->dmx     = (int **)              malloc(sizeof(int *) * (N+1))        ; if (mx->dmx     == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->xmx_mem = (void *)              malloc(sizeof(int)   * ((N+1)*5))    ; if (mx->xmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->mmx_mem = (void *)              malloc(sizeof(int)   * ((N+1)*(M+2))); if (mx->mmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->imx_mem = (void *)              malloc(sizeof(int)   * ((N+1)*(M+2))); if (mx->imx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->dmx_mem = (void *)              malloc(sizeof(int)   * ((N+1)*(M+2))); if (mx->dmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");


  /* The indirect assignment below looks wasteful; it's actually
   * used for aligning data on 16-byte boundaries as a cache
   * optimization in the fast altivec implementation
   */
  mx->xmx[0] = (int *) mx->xmx_mem;
  mx->mmx[0] = (int *) mx->mmx_mem;
  mx->imx[0] = (int *) mx->imx_mem;
  mx->dmx[0] = (int *) mx->dmx_mem;
  for (i = 1; i <= N; i++)
    {
      mx->xmx[i] = mx->xmx[0] + (i*5);
      mx->mmx[i] = mx->mmx[0] + (i*(M+2));
      mx->imx[i] = mx->imx[0] + (i*(M+2));
      mx->dmx[i] = mx->dmx[0] + (i*(M+2));
    }

  mx->maxN = N;
  mx->maxM = M;
  mx->padN = padN;
  mx->padM = padM;

  if (debug > 1) Rcout << "Leaving CreatePlan7Matrix" << std::endl;
 
  return mx;
}










/* Function: DigitizeSequence()
 *
 * Purpose:  Internal representation of a sequence in HMMER is
 *           as a char array. 1..L are the indices
 *           of seq symbols in Alphabet[]. 0,L+1 are sentinel
 *           bytes, set to be Alphabet_iupac -- i.e. one more
 *           than the maximum allowed index.
 *
 *           Assumes that 'X', the fully degenerate character,
 *           is the last character in the allowed alphabet.
 *
 * Args:     seq - sequence to be digitized (0..L-1)
 *           L   - length of sequence
 *
 * Return:   digitized sequence, dsq.
 *           dsq is allocated here and must be free'd by caller.
 */
unsigned char *
DigitizeSequence(char *seq, int L)
{
  DigitizeSequence_count++;

  if (debug > 1) Rcout << "In DigitizeSequence" << std::endl;

  unsigned char *dsq;
  int i;

  // dsq = MallocOrDie (sizeof(unsigned char) * (L+2));
  dsq = (unsigned char *) malloc(sizeof(unsigned char) * (L+2)); if (dsq == NULL) Rcpp::stop("Memory allocation failed!\n");

  dsq[0] = dsq[L+1] = (unsigned char) Alphabet_iupac;
  for (i = 1; i <= L; i++)
    dsq[i] = SymbolIndex(seq[i-1]);
  if (debug > 1) Rcout << "Leaving DigitizeSequence" << std::endl;
  return dsq;
}




/* Function: P7ViterbiSize()
 * Date:     SRE, Fri Mar  6 15:13:20 1998 [St. Louis]
 *
 * Purpose:  Returns the ballpark predicted memory requirement for a
 *           P7Viterbi() alignment, in MB.
 *
 *           Currently L must fit in an int (< 2 GB), but we have
 *           to deal with LM > 2 GB - e.g. watch out for overflow, do
 *           the whole calculation in floating point. Bug here detected
 *           in 2.1.1 by David Harper, Sanger Centre.
 *
 * Args:     L  - length of sequence
 *           M  - length of HMM
 *
 * Returns:  # of MB
 */
int
P7ViterbiSize(int L, int M)
{
  P7ViterbiSize_count++;

  if (debug > 1) Rcout << "In P7ViterbiSize" << std::endl;

  float Mbytes;

  /* We're excessively precise here, but it doesn't cost
   * us anything to be pedantic. The four terms are:
   *   1. the matrix structure itself;
   *   2. the O(NM) main matrix (this dominates!)
   *   3. ptrs into the rows of the matrix
   *   4. storage for 5 special states. (xmx)
   */
  Mbytes =  (float) sizeof(struct dpmatrix_s);
  Mbytes += 3. * (float) (L+1) * (float) (M+2) * (float) sizeof(int);
  Mbytes += 4. * (float) (L+1) * (float) sizeof(int *);
  Mbytes += 5. * (float) (L+1) * (float) sizeof(int);
  Mbytes /= 1048576.;
  if (debug > 1) Rcout << "Leaving P7ViterbiSize" << std::endl;
  return (int) Mbytes;
}





int P7ViterbiSpaceOK(int L, int M, struct dpmatrix_s *mx) {
  P7ViterbiSpaceOK_count++;

  if (debug > 1) Rcout << "In P7ViterbiSpaceOK" << std::endl;

  int newM;
  int newN;

  if (debug > 1) Rcout << "L:    " << L << std::endl;
  if (debug > 1) Rcout << "M:    " << M << std::endl;

  if (M > mx->maxM) newM = M + mx->padM; else newM = mx->maxM;
  if (L > mx->maxN) newN = L + mx->padN; else newN = mx->maxN;

  if (debug > 1) Rcout << "Needed:    " << P7ViterbiSize(newN, newM) << std::endl;
  if (debug > 1) Rcout << "Available: " << RAMLIMIT << std::endl;

  if (debug > 1) Rcout << "Leaving P7ViterbiSpaceOK" << std::endl;
  if (P7ViterbiSize(newN, newM) <= RAMLIMIT)
    return TRUE;
  else
    return FALSE;
}








/* Function: ResizePlan7Matrix()
 *
 * Purpose:  Reallocate a dynamic programming matrix, if necessary,
 *           for a problem of NxM: sequence length N, model size M.
 *           (N=1 for small memory score-only variants; we allocate
 *           N+1 rows in the DP matrix.)
 *
 *           We know (because of the way hmmsearch and hmmpfam are coded)
 *           that only one of the two dimensions is going to change
 *           in size after the first call to ResizePlan7Matrix();
 *           that is, for hmmsearch, we have one HMM of fixed size M
 *           and our target sequences may grow in N; for hmmpfam,
 *           we have one sequence of fixed size N and our target models
 *           may grow in M. What we have to watch out for is P7SmallViterbi()
 *           working on a divide and conquer problem and passing us N < maxN,
 *           M > maxM; we should definitely *not* reallocate a smaller N.
 *           Since we know that only one dimension is going to grow,
 *           we aren't scared of reallocating to maxN,maxM. (If both
 *           M and N could grow, we would be more worried.)
 *
 *           Returns individual ptrs to the four matrix components
 *           as a convenience.
 *
 * Args:     mx    - an already allocated model to grow.
 *           N     - seq length to allocate for; N+1 rows
 *           M     - size of model
 *           xmx, mmx, imx, dmx
 *                 - RETURN: ptrs to four mx components as a convenience
 *
 * Return:   (void)
 *           mx is (re)allocated here.
 */
void
ResizePlan7Matrix(struct dpmatrix_s *mx, int N, int M,
                  int ***xmx, int ***mmx, int ***imx, int ***dmx)
{
  ResizePlan7Matrix_count++;

  if (debug > 1) Rcout << "In ResizePlan7Matrix" << std::endl;

  int i;

  if (debug > 1) Rcout << "       N,mx->maxN,M,mx->maxM " << N << " " << mx->maxN << " " << M << " " << mx->maxM << std::endl;

  // return; // DEBUG - MRL

  if (N <= mx->maxN && M <= mx->maxM) goto DONE;

  if (N > mx->maxN) {
    N          += mx->padN;
    mx->maxN    = N;
    // mx->xmx     = (int **) ReallocOrDie (mx->xmx, sizeof(int *) * (mx->maxN+1));
    // mx->mmx     = (int **) ReallocOrDie (mx->mmx, sizeof(int *) * (mx->maxN+1));
    // mx->imx     = (int **) ReallocOrDie (mx->imx, sizeof(int *) * (mx->maxN+1));
    // mx->dmx     = (int **) ReallocOrDie (mx->dmx, sizeof(int *) * (mx->maxN+1));

    mx->xmx = (int **) realloc (mx->xmx, sizeof(int *) * (mx->maxN+1)); if (mx->xmx == NULL) Rcpp::stop("Memory allocation failed!\n");
    mx->mmx = (int **) realloc (mx->mmx, sizeof(int *) * (mx->maxN+1)); if (mx->mmx == NULL) Rcpp::stop("Memory allocation failed!\n");
    mx->imx = (int **) realloc (mx->imx, sizeof(int *) * (mx->maxN+1)); if (mx->imx == NULL) Rcpp::stop("Memory allocation failed!\n");
    mx->dmx = (int **) realloc (mx->dmx, sizeof(int *) * (mx->maxN+1)); if (mx->dmx == NULL) Rcpp::stop("Memory allocation failed!\n");
  }

  if (M > mx->maxM) {
    M += mx->padM;
    mx->maxM = M;
  }

  // mx->xmx_mem = (void *) ReallocOrDie (mx->xmx_mem, sizeof(int) * ((mx->maxN+1)*5));
  // mx->mmx_mem = (void *) ReallocOrDie (mx->mmx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2)));
  // mx->imx_mem = (void *) ReallocOrDie (mx->imx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2)));
  // mx->dmx_mem = (void *) ReallocOrDie (mx->dmx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2)));

  mx->xmx_mem = (void *) realloc (mx->xmx_mem, sizeof(int) * ((mx->maxN+1)*5));            if (mx->xmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->mmx_mem = (void *) realloc (mx->mmx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2))); if (mx->mmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->imx_mem = (void *) realloc (mx->imx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2))); if (mx->imx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");
  mx->dmx_mem = (void *) realloc (mx->dmx_mem, sizeof(int) * ((mx->maxN+1)*(mx->maxM+2))); if (mx->dmx_mem == NULL) Rcpp::stop("Memory allocation failed!\n");

  mx->xmx[0] = (int *) mx->xmx_mem;
  mx->mmx[0] = (int *) mx->mmx_mem;
  mx->imx[0] = (int *) mx->imx_mem;
  mx->dmx[0] = (int *) mx->dmx_mem;

  for (i = 1; i <= mx->maxN; i++)
    {
      mx->xmx[i] = mx->xmx[0] + (i*5);
      mx->mmx[i] = mx->mmx[0] + (i*(mx->maxM+2));
      mx->imx[i] = mx->imx[0] + (i*(mx->maxM+2));
      mx->dmx[i] = mx->dmx[0] + (i*(mx->maxM+2));
    }

 DONE:
  if (xmx != NULL) *xmx = mx->xmx;
  if (mmx != NULL) *mmx = mx->mmx;
  if (imx != NULL) *imx = mx->imx;
  if (dmx != NULL) *dmx = mx->dmx;

  if (debug > 1) Rcout << "Leaving ResizePlan7Matrix" << std::endl;

}







void P7AllocTrace(int tlen, struct p7trace_s **ret_tr) {
  P7AllocTrace_count++;

  if (debug > 1) Rcout << "In P7AllocTrace" << std::endl;

  struct p7trace_s *tr;

  // tr =            MallocOrDie (sizeof(struct p7trace_s));
  // tr->statetype = MallocOrDie (sizeof(char) * tlen);
  // tr->nodeidx   = MallocOrDie (sizeof(int)  * tlen);
  // tr->pos       = MallocOrDie (sizeof(int)  * tlen);

  tr            = (struct p7trace_s *) malloc (sizeof(struct p7trace_s)); if (tr            == NULL) Rcpp::stop("Memory allocation failed!\n");
  tr->statetype = (char *)             malloc (sizeof(char) * tlen)     ; if (tr->statetype == NULL) Rcpp::stop("Memory allocation failed!\n");
  tr->nodeidx   = (int  *)             malloc (sizeof(int)  * tlen)     ; if (tr->nodeidx   == NULL) Rcpp::stop("Memory allocation failed!\n");
  tr->pos       = (int  *)             malloc (sizeof(int)  * tlen)     ; if (tr->pos       == NULL) Rcpp::stop("Memory allocation failed!\n");

  *ret_tr = tr;
  if (debug > 1) Rcout << "Leaving P7AllocTrace" << std::endl;
}


void P7ReallocTrace(struct p7trace_s *tr, int tlen) {
  P7ReallocTrace_count++;

  if (debug > 1) Rcout << "In P7ReallocTrace" << std::endl;

  // tr->statetype = ReallocOrDie (tr->statetype, tlen * sizeof(char));
  // tr->nodeidx   = ReallocOrDie (tr->nodeidx,   tlen * sizeof(int));
  // tr->pos       = ReallocOrDie (tr->pos,       tlen * sizeof(int));

  tr->statetype = (char *) realloc (tr->statetype, tlen * sizeof(char)); if (tr->statetype == NULL) Rcpp::stop("Memory allocation failed!\n");
  tr->nodeidx   = (int  *) realloc (tr->nodeidx,   tlen * sizeof(int)) ; if (tr->nodeidx   == NULL) Rcpp::stop("Memory allocation failed!\n");
  tr->pos       = (int  *) realloc (tr->pos,       tlen * sizeof(int)) ; if (tr->pos       == NULL) Rcpp::stop("Memory allocation failed!\n");
  // if (debug > 1) Rcout << "Leaving P7ReallocTrace" << std::endl;
}


void P7FreeTrace(struct p7trace_s *tr) {
  P7FreeTrace_count++;

  if (debug > 1) Rcout << "In P7FreeTrace" << std::endl;

  if (tr == NULL) return;
  free(tr->pos);
  free(tr->nodeidx);
  free(tr->statetype);
  free(tr);
  if (debug > 1) Rcout << "Leaving P7FreeTrace" << std::endl;
}









/* Function: P7ReverseTrace()
 * Date:     SRE, Mon Aug 25 12:57:29 1997; Denver CO.
 *
 * Purpose:  Reverse the arrays in a traceback structure.
 *           Tracebacks from Forward() and Viterbi() are
 *           collected backwards, and call this function
 *           when they're done.
 *
 *           It's possible to reverse the arrays in place
 *           more efficiently; but the realloc/copy strategy
 *           has the advantage of reallocating the trace
 *           into the right size of memory. (Tracebacks
 *           overallocate.)
 *
 * Args:     tr - the traceback to reverse. tr->tlen must be set.
 *
 * Return:   (void)
 *           tr is modified.
 */
void
P7ReverseTrace(struct p7trace_s *tr)
{
  P7ReverseTrace_count++;

  if (debug > 1) Rcout << "In P7ReverseTrace" << std::endl;

  char  *statetype;
  int   *nodeidx;
  int   *pos;
  int    opos, npos;

  /* Allocate
   */
  // statetype = MallocOrDie (sizeof(char)* tr->tlen);
  // nodeidx   = MallocOrDie (sizeof(int) * tr->tlen);
  // pos       = MallocOrDie (sizeof(int) * tr->tlen);

  statetype = (char *) malloc (tr->tlen * sizeof(char)); if (statetype == NULL) Rcpp::stop("Memory allocation failed!\n");
  nodeidx   = (int  *) malloc (tr->tlen * sizeof(int)) ; if (nodeidx   == NULL) Rcpp::stop("Memory allocation failed!\n");
  pos       = (int  *) malloc (tr->tlen * sizeof(int)) ; if (pos       == NULL) Rcpp::stop("Memory allocation failed!\n");

  /* Reverse the trace.
   */
  for (opos = tr->tlen-1, npos = 0; npos < tr->tlen; npos++, opos--)
    {
      statetype[npos] = tr->statetype[opos];
      nodeidx[npos]   = tr->nodeidx[opos];
      pos[npos]       = tr->pos[opos];
    }

  /* Swap old, new arrays.
   */
  free(tr->statetype);
  free(tr->nodeidx);
  free(tr->pos);
  tr->statetype = statetype;
  tr->nodeidx   = nodeidx;
  tr->pos       = pos;
  if (debug > 1) Rcout << "Leaving P7ReverseTrace" << std::endl;
}










/* Function: P7ViterbiTrace()
 * Date:     SRE, Sat Aug 23 10:30:11 1997 (St. Louis Lambert Field)
 *
 * Purpose:  Traceback of a Viterbi matrix: i.e. retrieval
 *           of optimum alignment.
 *
 * Args:     hmm    - hmm, log odds form, used to make mx
 *           dsq    - sequence aligned to (digital form) 1..N
 *           N      - length of seq
 *           mx     - the matrix to trace back in, N x hmm->M
 *           ret_tr - RETURN: traceback.
 *
 * Return:   (void)
 *           ret_tr is allocated here. Free using P7FreeTrace().
 */
void
P7ViterbiTrace(struct plan7_s *hmm, unsigned char *dsq, int N,
               struct dpmatrix_s *mx, struct p7trace_s **ret_tr)
{
  P7ViterbiTrace_count++;

  if (debug > 1) Rcout << "In P7ViterbiTrace" << std::endl;

  struct p7trace_s *tr;
  int curralloc;                /* current allocated length of trace */
  int tpos;                     /* position in trace */
  int i;                        /* position in seq (1..N) */
  int k;                        /* position in model (1..M) */
  int **xmx, **mmx, **imx, **dmx;
  int sc;                       /* temp var for pre-emission score */

  /* Overallocate for the trace.
   * S-N-B- ... - E-C-T  : 6 states + N is minimum trace;
   * add N more as buffer.
   */
  curralloc = N * 2 + 6;
  P7AllocTrace(curralloc, &tr);

  xmx = mx->xmx;
  mmx = mx->mmx;
  imx = mx->imx;
  dmx = mx->dmx;

  /* Initialization of trace
   * We do it back to front; ReverseTrace() is called later.
   */
  tr->statetype[0] = STT;
  tr->nodeidx[0]   = 0;
  tr->pos[0]       = 0;
  tr->statetype[1] = STC;
  tr->nodeidx[1]   = 0;
  tr->pos[1]       = 0;
  tpos = 2;
  i    = N;                     /* current i (seq pos) we're trying to assign */
  k    = N;                     /* BEST GUESS ... k never initialized in hmmer v.2 */

  /* Traceback
   */
  while (tr->statetype[tpos-1] != STS) {
    switch (tr->statetype[tpos-1]) {
    case STM:                   /* M connects from i-1,k-1, or B */
      sc = mmx[i+1][k+1] - hmm->msc[dsq[i+1]][k+1];
      if (sc <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (sc == xmx[i][XMB] + hmm->bsc[k+1])
        {
                                /* Check for wing unfolding */
          if (Prob2Score(hmm->begin[k+1], hmm->p1) + 1 * INTSCALE <= hmm->bsc[k+1])
            while (k > 0)
              {
                tr->statetype[tpos] = STD;
                tr->nodeidx[tpos]   = k--;
                tr->pos[tpos]       = 0;
                tpos++;
                if (tpos == curralloc)
                  {                             /* grow trace if necessary  */
                    curralloc += N;
                    P7ReallocTrace(tr, curralloc);
                  }
              }

          tr->statetype[tpos] = STB;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
        }
      else if (sc == mmx[i][k] + hmm->tsc[TMM][k])
        {
          tr->statetype[tpos] = STM;
          tr->nodeidx[tpos]   = k--;
          tr->pos[tpos]       = i--;
        }
      else if (sc == imx[i][k] + hmm->tsc[TIM][k])
        {
          tr->statetype[tpos] = STI;
          tr->nodeidx[tpos]   = k;
          tr->pos[tpos]       = i--;
        }
      else if (sc == dmx[i][k] + hmm->tsc[TDM][k])
        {
          tr->statetype[tpos] = STD;
          tr->nodeidx[tpos]   = k--;
          tr->pos[tpos]       = 0;
        }
      else
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STD:                   /* D connects from M,D */
      if (dmx[i][k+1] <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (dmx[i][k+1] == mmx[i][k] + hmm->tsc[TMD][k])
        {
          tr->statetype[tpos] = STM;
          tr->nodeidx[tpos]   = k--;
          tr->pos[tpos]       = i--;
        }
      else if (dmx[i][k+1] == dmx[i][k] + hmm->tsc[TDD][k])
        {
          tr->statetype[tpos] = STD;
          tr->nodeidx[tpos]   = k--;
          tr->pos[tpos]       = 0;
        }
      else
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STI:                   /* I connects from M,I */
      sc = imx[i+1][k] - hmm->isc[dsq[i+1]][k];
      if (sc <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (sc == mmx[i][k] + hmm->tsc[TMI][k])
        {
          tr->statetype[tpos] = STM;
          tr->nodeidx[tpos]   = k--;
          tr->pos[tpos]       = i--;
        }
      else if (sc == imx[i][k] + hmm->tsc[TII][k])
        {
          tr->statetype[tpos] = STI;
          tr->nodeidx[tpos]   = k;
          tr->pos[tpos]       = i--;
        }
      else
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STN:                   /* N connects from S, N */
      if (i == 0 && xmx[i][XMN] == 0)
        {
          tr->statetype[tpos] = STS;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
        }
      else if (i > 0 && xmx[i+1][XMN] == xmx[i][XMN] + hmm->xsc[XTN][LOOP])
        {
          tr->statetype[tpos] = STN;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;    /* note convention adherence:  */
          tr->pos[tpos-1]     = i--;  /* first N doesn't emit        */
        }
      else
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STB:                   /* B connects from N, J */
      if (xmx[i][XMB] <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (xmx[i][XMB] == xmx[i][XMN] + hmm->xsc[XTN][MOVE])
        {
          tr->statetype[tpos] = STN;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
        }
      else if (xmx[i][XMB] == xmx[i][XMJ] + hmm->xsc[XTJ][MOVE])
        {
          tr->statetype[tpos] = STJ;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
        }

      else
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STE:                   /* E connects from any M state. k set here */
      if (xmx[i][XME] <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      for (k = hmm->M; k >= 1; k--)
        if (xmx[i][XME] == mmx[i][k] + hmm->esc[k])
          {
                                /* check for wing unfolding */
            if (Prob2Score(hmm->end[k], 1.) + 1*INTSCALE <=  hmm->esc[k])
              {
                int dk;         /* need a tmp k while moving thru delete wing */
                for (dk = hmm->M; dk > k; dk--)
                  {
                    tr->statetype[tpos] = STD;
                    tr->nodeidx[tpos]   = dk;
                    tr->pos[tpos]       = 0;
                    tpos++;
                    if (tpos == curralloc)
                      {                         /* grow trace if necessary  */
                        curralloc += N;
                        P7ReallocTrace(tr, curralloc);
                      }
                  }
              }

            tr->statetype[tpos] = STM;
            tr->nodeidx[tpos]   = k--;
            tr->pos[tpos]       = i--;
            break;
          }
      if (k < 0)
        // Die("traceback failed");
        Rcpp::stop("traceback failed!\n");
      break;

    case STC:                   /* C comes from C, E */
      if (xmx[i][XMC] <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (xmx[i][XMC] == xmx[i-1][XMC] + hmm->xsc[XTC][LOOP])
        {
          tr->statetype[tpos] = STC;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;    /* note convention adherence: */
          tr->pos[tpos-1]     = i--;  /* first C doesn't emit       */
        }
      else if (xmx[i][XMC] == xmx[i][XME] + hmm->xsc[XTE][MOVE])
        {
          tr->statetype[tpos] = STE;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0; /* E is a nonemitter */
        }

      else
        // Die("Traceback failed.");
        Rcpp::stop("traceback failed!\n");
      break;

    case STJ:                   /* J connects from E, J */
      if (xmx[i][XMJ] <= -INFTY) { P7FreeTrace(tr); *ret_tr = NULL; return; }
      else if (xmx[i][XMJ] == xmx[i-1][XMJ] + hmm->xsc[XTJ][LOOP])
        {
          tr->statetype[tpos] = STJ;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;    /* note convention adherence: */
          tr->pos[tpos-1]     = i--;  /* first J doesn't emit       */
        }
      else if (xmx[i][XMJ] == xmx[i][XME] + hmm->xsc[XTE][LOOP])
        {
          tr->statetype[tpos] = STE;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0; /* E is a nonemitter */
        }

      else
        //  Die("Traceback failed.");
        Rcpp::stop("traceback failed!\n");
      break;

    default:
      // Die("traceback failed");
      Rcpp::stop("traceback failed!\n");

    } /* end switch over statetype[tpos-1] */

    tpos++;
    if (tpos == curralloc)
      {                         /* grow trace if necessary  */
        curralloc += N;
        P7ReallocTrace(tr, curralloc);
      }

  } /* end traceback, at S state; tpos == tlen now */
  tr->tlen = tpos;
  P7ReverseTrace(tr);
  *ret_tr = tr;

  if (debug > 1) Rcout << "Leaving P7ViterbiTrace" << std::endl;
}









/* Function: P7Viterbi() - portably optimized version
 * Incept:   SRE, Fri Nov 15 13:14:33 2002 [St. Louis]
 *
 * Purpose:  The Viterbi dynamic programming algorithm.
 *           Derived from core_algorithms.c:P7Viterbi().
 *
 * Args:     dsq    - sequence in digitized form
 *           L      - length of dsq
 *           hmm    - the model
 *           mx     - re-used DP matrix
 *           ret_tr - RETURN: traceback; pass NULL if it's not wanted
 *
 * Return:   log P(S|M)/P(S|R), as a bit score
 */
float
P7Viterbi(unsigned char *dsq, int L, struct plan7_s *hmm, struct dpmatrix_s *mx, struct p7trace_s **ret_tr)
{
  P7Viterbi_count++;

  if (debug > 1) Rcout << "In P7Viterbi" << std::endl;

  struct p7trace_s  *tr;
  int **xmx;
  int **mmx;
  int **imx;
  int **dmx;
  int   i,k;
  int   sc;
  int  *mc, *dc, *ic;        /* pointers to rows of mmx, dmx, imx */
  int  *ms, *is;             /* pointers to msc[i], isc[i] */
  int  *mpp, *mpc, *ip;      /* ptrs to mmx[i-1], mmx[i], imx[i-1] */
  int  *bp;                  /* ptr into bsc[] */
  int  *ep;                  /* ptr into esc[] */
  int   xmb;                 /* value of xmx[i-1][XMB] */
  int   xme;                 /* max for xmx[i][XME] */
  int  *dpp;                 /* ptr into dmx[i-1] (previous row) */
  int  *tpmm, *tpmi, *tpmd, *tpim, *tpii, *tpdm, *tpdd; /* ptrs into tsc */
  int   M;


  /* Make sure we have space for a DP matrix with 0..L rows, 0..M-1 columns.
   */
  ResizePlan7Matrix(mx, L, hmm->M, &xmx, &mmx, &imx, &dmx);

  // return(0.0);       // DEBUG-MRL

  /* Initialization of the zero row.
   */
  xmx[0][XMN] = 0;                                   /* S->N, p=1            */
  xmx[0][XMB] = hmm->xsc[XTN][MOVE];                 /* S->N->B, no N-tail   */
  xmx[0][XME] = xmx[0][XMC] = xmx[0][XMJ] = -INFTY;  /* need seq to get here */
  for (k = 0; k <= hmm->M; k++)
    mmx[0][k] = imx[0][k] = dmx[0][k] = -INFTY;      /* need seq to get here */

  /* Initializations that help icc vectorize.
   */
  M        = hmm->M;

  /* Recursion. Done as a pull.
   * Note some slightly wasteful boundary conditions:
   *    tsc[0] = -INFTY for all eight transitions (no node 0)
   *    D_M and I_M are wastefully calculated (they don't exist)
   */

  tpmm  = hmm->tsc[TMM];
  tpim  = hmm->tsc[TIM];
  tpdm  = hmm->tsc[TDM];
  tpmd  = hmm->tsc[TMD];
  tpdd  = hmm->tsc[TDD];
  tpmi  = hmm->tsc[TMI];
  tpii  = hmm->tsc[TII];
  bp    = hmm->bsc;
  for (i = 1; i <= L; i++) {
    mc    = mmx[i];
    dc    = dmx[i];
    ic    = imx[i];
    mpp   = mmx[i-1];
    dpp   = dmx[i-1];
    ip    = imx[i-1];
    xmb   = xmx[i-1][XMB];
    ms    = hmm->msc[dsq[i]];
    is    = hmm->isc[dsq[i]];
    mc[0] = -INFTY;
    dc[0] = -INFTY;
    ic[0] = -INFTY;

    for (k = 1; k <= M; k++) {
      mc[k] = mpp[k-1]   + tpmm[k-1];
      if ((sc = ip[k-1]  + tpim[k-1]) > mc[k])  mc[k] = sc;
      if ((sc = dpp[k-1] + tpdm[k-1]) > mc[k])  mc[k] = sc;
      if ((sc = xmb  + bp[k])         > mc[k])  mc[k] = sc;
      mc[k] += ms[k];
      if (mc[k] < -INFTY) mc[k] = -INFTY;

      dc[k] = dc[k-1] + tpdd[k-1];
      if ((sc = mc[k-1] + tpmd[k-1]) > dc[k]) dc[k] = sc;
      if (dc[k] < -INFTY) dc[k] = -INFTY;

      if (k < M) {
        ic[k] = mpp[k] + tpmi[k];
        if ((sc = ip[k] + tpii[k]) > ic[k]) ic[k] = sc;
        ic[k] += is[k];
        if (ic[k] < -INFTY) ic[k] = -INFTY;
      }
    }

    /* Now the special states. Order is important here.
     * remember, C and J emissions are zero score by definition,
     */
                                /* N state */
    xmx[i][XMN] = -INFTY;
    if ((sc = xmx[i-1][XMN] + hmm->xsc[XTN][LOOP]) > -INFTY)
      xmx[i][XMN] = sc;

                                /* E state */
    xme = -INFTY;
    mpc = mmx[i];
    ep  = hmm->esc;
    for (k = 1; k <= hmm->M; k++)
      if ((sc =  mpc[k] + ep[k]) > xme) xme = sc;
    xmx[i][XME] = xme;
                                /* J state */
    xmx[i][XMJ] = -INFTY;
    if ((sc = xmx[i-1][XMJ] + hmm->xsc[XTJ][LOOP]) > -INFTY)
      xmx[i][XMJ] = sc;
    if ((sc = xmx[i][XME]   + hmm->xsc[XTE][LOOP]) > xmx[i][XMJ])
      xmx[i][XMJ] = sc;

                                /* B state */
    xmx[i][XMB] = -INFTY;
    if ((sc = xmx[i][XMN] + hmm->xsc[XTN][MOVE]) > -INFTY)
      xmx[i][XMB] = sc;
    if ((sc = xmx[i][XMJ] + hmm->xsc[XTJ][MOVE]) > xmx[i][XMB])
      xmx[i][XMB] = sc;

                                /* C state */
    xmx[i][XMC] = -INFTY;
    if ((sc = xmx[i-1][XMC] + hmm->xsc[XTC][LOOP]) > -INFTY)
      xmx[i][XMC] = sc;
    if ((sc = xmx[i][XME] + hmm->xsc[XTE][MOVE]) > xmx[i][XMC])
      xmx[i][XMC] = sc;
  }
                                /* T state (not stored) */
  sc = xmx[L][XMC] + hmm->xsc[XTC][MOVE];

  if (ret_tr != NULL) {
    P7ViterbiTrace(hmm, dsq, L, mx, &tr);
    *ret_tr = tr;
  }

  if (debug > 1) Rcout << "Leaving P7Viterbi" << std::endl;

  return Scorify(sc);           /* the total Viterbi score. */
}










/* Function: AllocTophits()
 *
 * Purpose:  Allocate a struct tophit_s, for maintaining
 *           a list of top-scoring hits in a database search.
 *
 * Args:     lumpsize - allocation lumpsize
 *
 * Return:   An allocated struct hit_s. Caller must free.
 */
struct tophit_s *
AllocTophits(int lumpsize)
{
  AllocTophits_count++;

  if (debug > 1) Rcout << "In AllocTophits" << std::endl;

  struct tophit_s *hitlist;

  //hitlist        = MallocOrDie (sizeof(struct tophit_s));
  hitlist        = (struct tophit_s *) malloc(sizeof(struct tophit_s)); if (hitlist == NULL) Rcpp::stop("Memory allocation failed!\n");
  hitlist->hit   = NULL;


  //hitlist->unsrt = MallocOrDie (lumpsize * sizeof(struct hit_s));
  hitlist->unsrt = (struct hit_s *) malloc(lumpsize * sizeof(struct hit_s)); if (hitlist->unsrt == NULL) Rcpp::stop("Memory allocation failed!\n");
  hitlist->alloc = lumpsize;
  hitlist->num   = 0;
  hitlist->lump  = lumpsize;
  if (debug > 1) Rcout << "Leaving AllocTophits" << std::endl;
  return hitlist;
}












/* Function: TraceDecompose()
 * Date:     Sat Aug 30 11:18:40 1997 (Denver CO)
 *
 * Purpose:  Decompose a long multi-hit trace into zero or more
 *           traces without N,C,J transitions: for consistent
 *           scoring and statistical evaluation of single domain
 *           hits.
 *
 * Args:     otr    - original trace structure
 *           ret_tr - RETURN: array of simpler traces
 *           ret_ntr- RETURN: number of traces.
 *
 * Return:   (void)
 *           ret_tr alloc'ed here; free individuals with FreeTrace().
 */
void
TraceDecompose(struct p7trace_s *otr, struct p7trace_s ***ret_tr, int *ret_ntr)
{
  TraceDecompose_count++;

  if (debug > 1) Rcout << "In TraceDecompose" << std::endl;

  struct p7trace_s **tr;        /* array of new traces          */
  int ntr;                      /* number of traces             */
  int i,j;                      /* position counters in traces  */
  int idx;                      /* index over ntr subtraces     */

  /* First pass: count begin states to get ntr.
   */
  for (ntr = 0, i = 0; i < otr->tlen; i++)
    if (otr->statetype[i] == STB) ntr++;

  /* Allocations.
   */
  if (ntr == 0) {
    *ret_ntr = 0;
    *ret_tr  = NULL;
    return;
  }
  // tr = (struct p7trace_s **) MallocOrDie (sizeof(struct p7trace_s *) * ntr);
  tr = (struct p7trace_s **) malloc (ntr * sizeof(struct p7trace_s *)); if (tr == NULL) Rcpp::stop("Memory allocation failed!\n");

  for (idx = 0, i = 0; i < otr->tlen; i++) /* i = position in old trace */
    if (otr->statetype[i] == STB)
      {
        for (j = i+1; j < otr->tlen; j++) /* j = tmp; get length of subtrace */
          if (otr->statetype[j] == STE) break;
                        /* trace = S-N-(B..E)-C-T : len + 4 : j-i+1 + 4*/
        P7AllocTrace(j-i+5, &(tr[idx]));
        tr[idx]->tlen = j-i+5;

        tr[idx]->statetype[0] = STS;
        tr[idx]->nodeidx[0]   = 0;
        tr[idx]->pos[0]       = 0;
        tr[idx]->statetype[1] = STN;
        tr[idx]->nodeidx[1]   = 0;
        tr[idx]->pos[1]       = 0;
        j = 2;                  /* now j = position in new subtrace */
        while (1)               /* copy subtrace */
          {
            tr[idx]->statetype[j] = otr->statetype[i];
            tr[idx]->nodeidx[j]   = otr->nodeidx[i];
            tr[idx]->pos[j]       = otr->pos[i];
            if (otr->statetype[i] == STE) break;
            i++; j++;
          }
        j++;
        tr[idx]->statetype[j] = STC;
        tr[idx]->nodeidx[j]   = 0;
        tr[idx]->pos[j]       = 0;
        j++;
        tr[idx]->statetype[j] = STT;
        tr[idx]->nodeidx[j]   = 0;
        tr[idx]->pos[j]       = 0;
        idx++;
      }

  *ret_tr  = tr;
  *ret_ntr = ntr;
  if (debug > 1) Rcout << "Leaving TraceDecompose" << std::endl;
  return;
}









/* Function: DegenerateSymbolScore()
 *
 * Purpose:  Given a sequence character x and an hmm emission probability
 *           vector, calculate the log-odds (base 2) score of
 *           the symbol.
 *
 *           Easy if x is in the emission alphabet, but not so easy
 *           is x is a degenerate symbol. The "correct" Bayesian
 *           philosophy is to calculate score(X) by summing over
 *           p(x) for all x in the degenerate symbol X to get P(X),
 *           doing the same sum over the prior to get F(X), and
 *           doing log_2 (P(X)/F(X)). This gives an X a zero score,
 *           for instance.
 *
 *           Though this is correct in a formal Bayesian sense --
 *           we have no information on the sequence, so we can't
 *           say if it's random or model, so it scores zero --
 *           it sucks, big time, for scoring biological sequences.
 *           Sequences with lots of X's score near zero, while
 *           real sequences have average scores that are negative --
 *           so the X-laden sequences appear to be lifted out
 *           of the noise of a full histogram of a database search.
 *           Correct or not, this is highly undesirable.
 *
 *           So therefore we calculated the expected score of
 *           the degenerate symbol by summing over all x in X:
 *                 e_x log_2 (p(x)/f(x))
 *           where the expectation of x, e_x, is calculated from
 *           the random model.
 *
 *           Empirically, this works; it also has a wooly hand-waving
 *           probabilistic justification that I'm happy enough about.
 *
 * Args:     p      - probabilities of normal symbols
 *           null   - null emission model
 *           ambig  - index of the degenerate character in Alphabet[]
 *
 * Return:   the integer log odds score of x given the emission
 *           vector and the null model, scaled up by INTSCALE.
 */
int
DegenerateSymbolScore(float *p, float *null, int ambig)
{
  DegenerateSymbolScore_count++;

  if (debug > 1) Rcout << "In DegenerateSymbolScore" << std::endl;

  int x;
  float numer = 0.;
  float denom = 0.;

  for (x = 0; x < Alphabet_size; x++) {
    if (Degenerate[ambig][x]) {
      numer += null[x] * sreLOG2(p[x] / null[x]);
      denom += null[x];
    }
  }
  if (debug > 1) Rcout << "Leaving DegenerateSymbolScore" << std::endl;
  return (int) (INTSCALE * numer / denom);
}









/* Function: P7Logoddsify()
 *
 * Purpose:  Take an HMM with valid probabilities, and
 *           fill in the integer log-odds score section of the model.
 *
 *    Notes on log-odds scores:
 *         type of parameter       probability        score
 *         -----------------       -----------        ------
 *         any emission             p_x           log_2 p_x/null_x
 *             N,J,C /assume/ p_x = null_x so /always/ score zero.
 *         transition to emitters   t_x           log_2 t_x/p1
 *            (M,I; N,C; J)
 *             NN and CC loops are often equal to p1, so usu. score zero.
 *         C->T transition          t_x            log_2 t_x/p2
 *            often zero, usu. C->T = p2.
 *         all other transitions    t_x           log_2 t_x
 *             (no null model counterpart, so null prob is 1)
 *
 *    Notes on entry/exit scores, B->M and M->E:
 *         The probability form model includes delete states 1 and M.
 *         these states are removed from a search form model to
 *         prevent B->D...D->E->J->B mute cycles, which would complicate
 *         dynamic programming algorithms. The data-independent
 *         S/W B->M and M->E transitions are folded together with
 *         data-dependent B->D...D->M and M->D...D->E paths.
 *
 *         This process is referred to in the code as "wing folding"
 *         or "wing retraction"... the analogy is to a swept-wing
 *         fighter in landing vs. high speed flight configuration.
 *
 *    Note on Viterbi vs. forward flag:
 *         Wing retraction must take forward vs. Viterbi
 *         into account. If forward, sum two paths; if Viterbi, take
 *         max. I tried to slide this by as a sum, without
 *         the flag, but Alex detected it as a bug, because you can
 *         then find cases where the Viterbi score doesn't match
 *         the P7TraceScore().
 *
 * Args:      hmm          - the hmm to calculate scores in.
 *            viterbi_mode - TRUE to fold wings in Viterbi configuration.
 *
 * Return:    (void)
 *            hmm scores are filled in.
 */ 
void
P7Logoddsify(struct plan7_s *hmm, int viterbi_mode)
{
  P7Logoddsify_count++;

  int k;                        /* counter for model position */
  int x;                        /* counter for symbols        */
  float accum;
  float tbm, tme;

  if (hmm->flags & PLAN7_HASBITS) return;

  /* Symbol emission scores
   */
  for (k = 1; k <= hmm->M; k++)
    {
                                /* match/insert emissions in main model */
      for (x = 0; x < Alphabet_size; x++)
        {
          hmm->msc[x][k] = Prob2Score(hmm->mat[k][x], hmm->null[x]);
          if (k < hmm->M)
            hmm->isc[x][k] =  Prob2Score(hmm->ins[k][x], hmm->null[x]);
        }
                                /* degenerate match/insert emissions */
      for (x = Alphabet_size; x < Alphabet_iupac; x++)
        {
          hmm->msc[x][k] = DegenerateSymbolScore(hmm->mat[k], hmm->null, x);
          if (k < hmm->M)
            hmm->isc[x][k] = DegenerateSymbolScore(hmm->ins[k], hmm->null, x);
        }
    }

  /* State transitions.
   *
   * A note on "folding" of D_1 and D_M.
   * These two delete states are folded out of search form models
   * in order to prevent null cycles in the dynamic programming
   * algorithms (see code below). However, we use their log transitions
   * when we save the model! So the following log transition probs
   * are used *only* in save files, *never* in search algorithms:
   *    log (tbd1), D1 -> M2, D1 -> D2
   *    Mm-1 -> Dm, Dm-1 -> Dm
   *   
   * In a search algorithm, these have to be interpreted as -INFTY
   * because their contributions are folded into bsc[] and esc[]
   * entry/exit scores. They can't be set to -INFTY here because
   * we need them in save files.
   */
  for (k = 1; k < hmm->M; k++)
    {
      hmm->tsc[TMM][k] = Prob2Score(hmm->t[k][TMM], hmm->p1);
      hmm->tsc[TMI][k] = Prob2Score(hmm->t[k][TMI], hmm->p1);
      hmm->tsc[TMD][k] = Prob2Score(hmm->t[k][TMD], 1.0);
      hmm->tsc[TIM][k] = Prob2Score(hmm->t[k][TIM], hmm->p1);
      hmm->tsc[TII][k] = Prob2Score(hmm->t[k][TII], hmm->p1);
      hmm->tsc[TDM][k] = Prob2Score(hmm->t[k][TDM], hmm->p1);
      hmm->tsc[TDD][k] = Prob2Score(hmm->t[k][TDD], 1.0);
    }

  /* B->M entry transitions. Note how D_1 is folded out.
   * M1 is just B->M1
   * M2 is sum (or max) of B->M2 and B->D1->M2
   * M_k is sum (or max) of B->M_k and B->D1...D_k-1->M_k
   * These have to be done in log space, else you'll get
   * underflow errors; and we also have to watch for log(0).
   * A little sloppier than it probably has to be; historically,
   * doing in this in log space was in response to a bug report.
   */
  accum = hmm->tbd1 > 0.0 ? log(hmm->tbd1) : -9999.;
  for (k = 1; k <= hmm->M; k++)
    {
      tbm = hmm->begin[k] > 0. ? log(hmm->begin[k]) : -9999.;   /* B->M_k part */

      /* B->D1...D_k-1->M_k part we get from accum*/
      if (k > 1 && accum > -9999.)
        {      
          if (hmm->t[k-1][TDM] > 0.0)
            {
              if (viterbi_mode) tbm =  MAX(tbm, accum + log(hmm->t[k-1][TDM]));
              else              tbm =  LogSum(tbm, accum + log(hmm->t[k-1][TDM]));
            }

          accum = (hmm->t[k-1][TDD] > 0.0) ? accum + log(hmm->t[k-1][TDD]) : -9999.;
        }
                                /* Convert from log_e to scaled integer log_2 odds. */
      if (tbm > -9999.)
        hmm->bsc[k] = (int) floor(0.5 + INTSCALE * 1.44269504 * (tbm - log(hmm->p1)));
      else
        hmm->bsc[k] = -INFTY;
    }

  /* M->E exit transitions. Note how D_M is folded out.
   * M_M is 1 by definition
   * M_M-1 is sum of M_M-1->E and M_M-1->D_M->E, where D_M->E is 1 by definition
   * M_k is sum of M_k->E and M_k->D_k+1...D_M->E
   * Must be done in log space to avoid underflow errors.
   * A little sloppier than it probably has to be; historically,
   * doing in this in log space was in response to a bug report.
   */
  hmm->esc[hmm->M] = 0;
  accum = 0.;
  for (k = hmm->M-1; k >= 1; k--)
    {
      tme = hmm->end[k] > 0. ? log(hmm->end[k]) : -9999.;
      if (accum > -9999.)
        {
          if (hmm->t[k][TMD] > 0.0)
            {  
              if (viterbi_mode) tme = MAX(tme, accum + log(hmm->t[k][TMD]));
              else              tme = LogSum(tme, accum + log(hmm->t[k][TMD]));
            }
          accum = (hmm->t[k][TDD] > 0.0) ? accum + log(hmm->t[k][TDD]) : -9999.;
        }
                                /* convert from log_e to scaled integer log odds. */
      hmm->esc[k] = (tme > -9999.) ? (int) floor(0.5 + INTSCALE * 1.44269504 * tme) : -INFTY;
    }

                                /* special transitions */
  hmm->xsc[XTN][LOOP] = Prob2Score(hmm->xt[XTN][LOOP], hmm->p1);
  hmm->xsc[XTN][MOVE] = Prob2Score(hmm->xt[XTN][MOVE], 1.0);
  hmm->xsc[XTE][LOOP] = Prob2Score(hmm->xt[XTE][LOOP], 1.0);
  hmm->xsc[XTE][MOVE] = Prob2Score(hmm->xt[XTE][MOVE], 1.0);
  hmm->xsc[XTC][LOOP] = Prob2Score(hmm->xt[XTC][LOOP], hmm->p1);
  hmm->xsc[XTC][MOVE] = Prob2Score(hmm->xt[XTC][MOVE], 1.-hmm->p1);
  hmm->xsc[XTJ][LOOP] = Prob2Score(hmm->xt[XTJ][LOOP], hmm->p1);
  hmm->xsc[XTJ][MOVE] = Prob2Score(hmm->xt[XTJ][MOVE], 1.0);

  hmm->flags |= PLAN7_HASBITS;  /* raise the log-odds ready flag */
}











/* Function: TraceScoreCorrection()
 * Date:     Sun Dec 21 12:05:47 1997 [StL]
 *
 * Purpose:  Calculate a correction (in integer log_2 odds) to be
 *           applied to a sequence, using a second null model,
 *           based on a traceback. M/I emissions are corrected;
 *           C/N/J are not -- as if the nonmatching part and
 *           matching part were each generated by the best null model.
 *           The null model is constructed /post hoc/ as the
 *           average over all the M,I distributions used by the trace.
 *
 * Return:   the log_2-odds score correction.
 */
float
TraceScoreCorrection(struct plan7_s *hmm, struct p7trace_s *tr, unsigned char *dsq)
{
  TraceScoreCorrection_count++;

  if (debug > 1) Rcout << "In TraceScoreCorrection" << std::endl;

  float p[MAXABET];             /* null model distribution */
  int   sc[MAXCODE];            /* null model scores       */
  int   x;
  int   tpos;
  int   score;

  /* Rarely, the alignment was totally impossible, and tr is NULL.
   */
  if (tr == NULL) return 0.0;

  /* Set up model: average over the emission distributions of
   * all M, I states that appear in the trace. Ad hoc? Sure, you betcha.
   */
  FSet(p, Alphabet_size, 0.0);
  for (tpos = 0; tpos < tr->tlen; tpos++)
     if      (tr->statetype[tpos] == STM)
       FAdd(p, hmm->mat[tr->nodeidx[tpos]], Alphabet_size);
     else if (tr->statetype[tpos] == STI)
       FAdd(p, hmm->ins[tr->nodeidx[tpos]], Alphabet_size);
  FNorm(p, Alphabet_size);

  for (x = 0; x < Alphabet_size; x++)
    sc[x] = Prob2Score(p[x], hmm->null[x]);
                                /* could avoid this chunk if we knew
                                   we didn't need any degenerate char scores */
  for (x = Alphabet_size; x < Alphabet_iupac; x++)
    sc[x] = DegenerateSymbolScore(p, hmm->null, x);


  /* Score all the M,I state emissions that appear in the trace.
   */
   score = 0;
   for (tpos = 0; tpos < tr->tlen; tpos++)
     if (tr->statetype[tpos] == STM || tr->statetype[tpos] == STI)
       score += sc[dsq[tr->pos[tpos]]];

   /* Apply an ad hoc 8 bit fudge factor penalty;
    * interpreted as a prior, saying that the second null model is
    * 1/2^8 (1/256) as likely as the standard null model
    */
   score -= 8 * INTSCALE;

   /* Return the correction to the bit score.
    */
  if (debug > 1) Rcout << "Leaving TraceScoreCorrection" << std::endl;
   return Scorify(ILogsum(0, score));
}








/* Function: TransitionScoreLookup()
 *
 * Purpose:  Convenience function used in PrintTrace() and TraceScore();
 *           given state types and node indices for a transition,
 *           return the integer score for that transition.
 */
int
TransitionScoreLookup(struct plan7_s *hmm, char st1, int k1,
                      char st2, int k2)
{
  TransitionScoreLookup_count++;

  if (debug > 1) Rcout << "In TransitionScoreLookup" << std::endl;

  switch (st1) {
  case STS: return 0;   /* S never pays */
  case STN:
    switch (st2) {
    case STB: return hmm->xsc[XTN][MOVE];
    case STN: return hmm->xsc[XTN][LOOP];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STB:
    switch (st2) {
    case STM: return hmm->bsc[k2];
    case STD: return Prob2Score(hmm->tbd1, 1.);
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STM:
    switch (st2) {
    case STM: return hmm->tsc[TMM][k1];
    case STI: return hmm->tsc[TMI][k1];
    case STD: return hmm->tsc[TMD][k1];
    case STE: return hmm->esc[k1];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STI:
    switch (st2) {
    case STM: return hmm->tsc[TIM][k1];
    case STI: return hmm->tsc[TII][k1];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STD:
    switch (st2) {
    case STM: return hmm->tsc[TDM][k1];
    case STD: return hmm->tsc[TDD][k1];
    case STE: return 0; /* D_m->E has probability 1.0 by definition in Plan7 */
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STE:
    switch (st2) {
    case STC: return hmm->xsc[XTE][MOVE];
    case STJ: return hmm->xsc[XTE][LOOP];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STJ:
    switch (st2) {
    case STB: return hmm->xsc[XTJ][MOVE];
    case STJ: return hmm->xsc[XTJ][LOOP];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STC:
    switch (st2) {
    case STT: return hmm->xsc[XTC][MOVE];
    case STC: return hmm->xsc[XTC][LOOP];
    default:      Rcpp::stop("illegal transition!\n"); // Die("illegal %s->%s transition", Statetype(st1), Statetype(st2));
    }
    break;
  case STT:   return 0; /* T makes no transitions */
  default:        Rcpp::stop("illegal transition!\n"); // Die("illegal state %s in traceback", Statetype(st1));
  }
  /*NOTREACHED*/
  return 0;
}








/* Function: P7TraceScore()
 *
 * Purpose:  Score a traceback and return the score in scaled bits.
 *
 * Args:     hmm   - HMM with valid log odds scores.
 *           dsq   - digitized sequence that traceback aligns to the HMM (1..L)
 *           tr    - alignment of seq to HMM
 *
 * Return:   (void)
 */
float
P7TraceScore(struct plan7_s *hmm, unsigned char *dsq, struct p7trace_s *tr)
{
  P7TraceScore_count++;

  if (debug > 1) Rcout << "In P7TraceScore" << std::endl;

  int score;                    /* total score as a scaled integer */
  int tpos;                     /* position in tr */
  unsigned char sym;            /* digitized symbol in dsq */

  /*  P7PrintTrace(stdout, tr, hmm, dsq); */
  score = 0;
  for (tpos = 0; tpos < tr->tlen-1; tpos++)
    {
      sym = dsq[tr->pos[tpos]];

      /* Emissions.
       * Don't bother counting null states N,J,C.
       */
      if (tr->statetype[tpos] == STM)
        score += hmm->msc[sym][tr->nodeidx[tpos]];
      else if (tr->statetype[tpos] == STI)
        score += hmm->isc[sym][tr->nodeidx[tpos]];

      /* State transitions.
       */
      score += TransitionScoreLookup(hmm,
                             tr->statetype[tpos], tr->nodeidx[tpos],
                             tr->statetype[tpos+1], tr->nodeidx[tpos+1]);
    }
  if (debug > 1) Rcout << "Leaving P7TraceScore" << std::endl;
  return Scorify(score);
}








/* Function: TraceSimpleBounds()
 *
 * Purpose:  For a trace that contains only a single
 *           traverse of the model (i.e. something that's
 *           come from TraceDecompose(), or a global
 *           alignment), determine the bounds of
 *           the match on both the sequence [1..L] and the
 *           model [1..M].
 *
 * Args:     tr   - trace to look at
 *           i1   - RETURN: start point in sequence [1..L]
 *           i2   - RETURN: end point in sequence [1..L]
 *           k1   - RETURN: start point in model [1..M]
 *           k2   - RETURN: end point in model [1..M]
 */
void
TraceSimpleBounds(struct p7trace_s *tr, int *ret_i1, int *ret_i2,
                  int *ret_k1,  int *ret_k2)
{
  TraceSimpleBounds_count++;

  if (debug > 1) Rcout << "In TraceSimpleBounds" << std::endl;

  int i1, i2, k1, k2, tpos;

  i1 = k1 = i2 = k2 = -1;

                                /* Look forwards to find start of match */
  for (tpos = 0; tpos < tr->tlen; tpos++)
    {
      if (k1 == -1 && (tr->statetype[tpos] == STM || tr->statetype[tpos] == STD))
        k1 = tr->nodeidx[tpos];
      if (tr->statetype[tpos] == STM)
        {
          i1 = tr->pos[tpos];
          break;
        }
    }
  if (tpos == tr->tlen || i1 == -1 || k1 == -1)
    Rcpp::stop("sanity check failed!\n"); // Die("sanity check failed: didn't find a match state in trace");

                                /* Look backwards to find end of match */
  for (tpos = tr->tlen-1; tpos >= 0; tpos--)
    {
      if (k2 == -1 && (tr->statetype[tpos] == STM || tr->statetype[tpos] == STD))
        k2 = tr->nodeidx[tpos];
      if (tr->statetype[tpos] == STM)
        {
          i2 = tr->pos[tpos];
          break;
        }
    }
  if (tpos == tr->tlen || i2 == -1 || k2 == -1)
    Rcpp::stop("sanity check failed!\n"); // Die("sanity check failed: didn't find a match state in trace");

  *ret_k1 = k1;
  *ret_i1 = i1;
  *ret_k2 = k2;
  *ret_i2 = i2;
  if (debug > 1) Rcout << "Leaving TraceSimpleBounds" << std::endl;
}






void
GrowTophits(struct tophit_s *h)
{
  GrowTophits_count++;

  if (debug > 1) Rcout << "In GrowTophits" << std::endl;

  // h->unsrt = ReallocOrDie(h->unsrt,(h->alloc + h->lump) * sizeof(struct hit_s));
  h->unsrt = (struct hit_s *) realloc(h->unsrt,(h->alloc + h->lump) * sizeof(struct hit_s));  if (h->unsrt == NULL) Rcpp::stop("Memory allocation failed!\n");
  h->alloc += h->lump;

  if (debug > 1) Rcout << "Leaving GrowTophits" << std::endl;
}





/* Function: RegisterHit()
 *
 * Purpose:  Add a new hit to a list of top hits.
 *
 *           "ali", if provided, is a pointer to allocated memory
 *           for an alignment output structure.
 *           Management is turned over to the top hits structure.
 *           Caller should not free them; they will be free'd by
 *           the FreeTophits() call.
 *
 *           In contrast, "name", "acc", and "desc" are copied, so caller
 *           is still responsible for these.
 *
 *           Number of args is unwieldy.
 *
 * Args:     h        - active top hit list
 *           key      - value to sort by: bigger is better
 *           pvalue   - P-value of this hit
 *           score    - score of this hit
 *           motherp  - P-value of parent whole sequence
 *           mothersc - score of parent whole sequence
 *           name     - name of target
 *           acc      - accession of target (may be NULL)
 *           desc     - description of target (may be NULL)
 *           sqfrom   - 1..L pos in target seq  of start
 *           sqto     - 1..L pos; sqfrom > sqto if rev comp
 *           sqlen    - length of sequence, L
 *           hmmfrom  - 0..M+1 pos in HMM of start
 *           hmmto    - 0..M+1 pos in HMM of end
 *           hmmlen   - length of HMM, M
 *           domidx   - number of this domain
 *           ndom     - total # of domains in sequence
 *           ali      - optional printable alignment info
 *
 * Return:   (void)
 *           hitlist is modified and possibly reallocated internally.
 */
void
RegisterHit(struct tophit_s *h, double key,
            double pvalue, float score, double motherp, float mothersc,
        //  char *name, char *acc, char *desc,
            int sqfrom, int sqto, int sqlen,
            int hmmfrom, int hmmto, int hmmlen,
        //  int domidx, int ndom,
        //  struct fancyali_s *ali)  // Remove ali
            int domidx, int ndom)
{
  RegisterHit_count++;

  if (debug > 1) Rcout << "In RegisterHit" << std::endl;

  /* Check to see if list is full and we must realloc.
   */
  if (h->num == h->alloc) GrowTophits(h);

  // h->unsrt[h->num].name    = Strdup(name);
  // h->unsrt[h->num].acc     = Strdup(acc);
  // h->unsrt[h->num].desc    = Strdup(desc);
  h->unsrt[h->num].sortkey = key;
  h->unsrt[h->num].pvalue  = pvalue;
  h->unsrt[h->num].score   = score;
  h->unsrt[h->num].motherp = motherp;
  h->unsrt[h->num].mothersc= mothersc;
  h->unsrt[h->num].sqfrom  = sqfrom;
  h->unsrt[h->num].sqto    = sqto;
  h->unsrt[h->num].sqlen   = sqlen;
  h->unsrt[h->num].hmmfrom = hmmfrom;
  h->unsrt[h->num].hmmto   = hmmto;
  h->unsrt[h->num].hmmlen  = hmmlen;
  h->unsrt[h->num].domidx  = domidx;
  h->unsrt[h->num].ndom    = ndom;
  // h->unsrt[h->num].ali     = ali;
  h->num++;
  if (debug > 1) Rcout << "Leaving RegisterHit" << std::endl;
  return;
}













/* Function: PostprocessSignificantHit()
 * Date:     SRE, Wed Dec 20 12:11:01 2000 [StL]
 *
 * Purpose:  Add a significant hit to per-seq and per-domain hit
 *           lists, after postprocessing the scores appropriately,
 *           and making sure per-domain scores add up to the per-seq
 *           score.
 *
 *          [doesn't really belong in core_algorithms.c, because
 *           it's more of a hack than an algorithm, but on the other
 *           hand it's now part of the core of how HMMER scores
 *           things. Maybe there should be a core_hacks.c.]
 *
 *           Given: active hit lists for per-seq and per-domain
 *           scores (e.g. hmmpfam and hmmsearch, collating their
 *           results), and a new hit that's significant enough
 *           that it may need to be reported in final output.
 *
 *           Breaks the traceback into individual domain traces;
 *           scores each one of them, then applies null2 correction
 *           for biased composition. Recalculates the per-seq score
 *           as the sum of the per-domain scores. Stores the hits
 *           in the lists, for eventual sorting and output by the
 *           caller.
 *
 * Notes:    In principle we've got the score, and a pvalue, and a traceback
 *           by doing the Viterbi algorithm, right? What else is left
 *           to do? Well, in practice, life is more complicated, because
 *           of the trace-dependent null2 score correction.
 *
 *           After a null2 score correction is carried out on
 *           each domain (the default) the number of detected domains
 *           with scores > 0 may have decreased. We want the
 *           global (per-seq) hit list to have the recalculated number of
 *           domains, not necessarily what Viterbi gave us.
 *
 *           Also, since we want the global score to be the sum of
 *           the individual domains, but the null2 correction is
 *           applied to each domain individually, we have to calculate
 *           an adjusted global score. (To do otherwise invites
 *           subtle inconsistencies; xref bug 2.)
 *
 *           We don't have final evalues, so we may put a few
 *           more hits into the hit lists than we end up reporting.
 *           The main output routine is responsible for final
 *           enforcement of the thresholds.
 *
 *           This routine is NOT THREADSAFE. When multithreaded,
 *           with using shared ghit/dhit output buffers, calls to
 *           PostprocessSignificantHit() need to be protected.
 *
 * Args:     ghit     - an active list of per-seq (global) hits
 *           dhit     - an active list of per-domain hits
 *           tr       - the significant HMM/seq traceback we'll report on
 *           hmm      - ptr to the HMM
 *           dsq      - digitized sequence (1..L)
 *           L        - length of dsq
 *           seqname  - name of sequence (same as targname, in hmmsearch)
 *           seqacc   - seq's accession (or NULL)
 *           seqdesc  - seq's description (or NULL)
 *           do_forward  - TRUE if we've already calculated final per-seq score
 *           sc_override - per-seq score to use if do_forward is TRUE
 *           do_null2    - TRUE to apply the null2 scoring correction
 *           thresh      - contains the threshold/cutoff information.
 *           hmmpfam_mode - TRUE if called by hmmpfam, else assumes hmmsearch;
 *                          affects how the lists' sort keys are set.
 *
 * Returns:  the recalculated per-seq score (or sc_override),
 *           as appropriate, for subsequent storage in the histogram
 */
float
PostprocessSignificantHit(struct tophit_s    *ghit,
                          struct tophit_s    *dhit,
                          struct p7trace_s   *tr,
                          struct plan7_s     *hmm,
                          unsigned char      *dsq,
                          int                 L,
                     //   char               *seqname,
                     //   char               *seqacc,
                     //   char               *seqdesc,
                          int                 do_forward,
                          float               sc_override,
                          int                 do_null2,
                          struct threshold_s *thresh,
                          int                 hmmpfam_mode)
{
  PostprocessSignificantHit_count++;

  if (debug > 1) Rcout << "In PostprocessSignificantHit" << std::endl;

  struct p7trace_s **tarr;      /* array of per-domain traces */
  // struct fancyali_s *ali;       /* alignment of a domain      */
  int ntr;                      /* number of domain traces from Viterbi */
  int tidx;                     /* index for traces (0..ntr-1) */
  int ndom;                     /* # of domains accepted in sequence */
  int didx;                     /* index for domains (1..ndom) */
  int k1, k2;                   /* start, stop coord in model */
  int i1, i2;                   /* start, stop in sequence    */
  float   whole_sc;             /* whole sequence score = \sum domain scores */
  float  *score;                /* array of raw scores for each domain */
  int    *usedomain;            /* TRUE if this domain is accepted */
  double  whole_pval;
  double  pvalue;
  double  sortkey;

  /* Special case: rarely, the alignment was totally impossible
   * and tr is NULL.
   */
  if (tr == NULL) return sc_override;

  /* Break the trace into one or more individual domains.
   */
  TraceDecompose(tr, &tarr, &ntr);
  if (ntr == 0) Rcpp::stop("screwup!\n"); // Die("TraceDecompose() screwup"); /* "can't happen" (!) */

  /* Rescore each domain, apply null2 correction if asked.
   * Mark positive-scoring ones (we'll definitely report those),
   * and include their score in the whole sequence score.
   */
  // score     = MallocOrDie(sizeof(float) * ntr);
  // usedomain = MallocOrDie(sizeof(int)   * ntr);
  score     = (float *) malloc(ntr * sizeof(float));  if (score     == NULL) Rcpp::stop("Memory allocation failed!\n");
  usedomain = (int   *) malloc(ntr * sizeof(int)  );  if (usedomain == NULL) Rcpp::stop("Memory allocation failed!\n");

  ndom      = 0;
  whole_sc  = 0.;
  for (tidx = 0; tidx < ntr; tidx++)
    {
      score[tidx]  = P7TraceScore(hmm, dsq, tarr[tidx]);
      if (do_null2) score[tidx] -= TraceScoreCorrection(hmm, tarr[tidx], dsq);
      if (score[tidx] > 0.0) {
        usedomain[tidx] = TRUE;
        ndom++;
        whole_sc += score[tidx];
      } else
        usedomain[tidx] = FALSE;
    }

  /* Make sure at least one positive scoring domain is in
   * the trace. If not, invoke "weak single domain" rules:
   * we will always report at least one domain per sequence, even
   * if it has a negative score. (HMMER's Plan7 architecture can report
   * one negative scoring domain but not more.)
   */
  if (ndom == 0) {
    tidx            = FArgMax(score, ntr);
    usedomain[tidx] = TRUE;
    whole_sc        = score[tidx];
    ndom            = 1;
  }

  /* Implement --do_forward: override the trace-dependent sum-of-domain
   * whole score, use the P7Forward() score that the called passed
   * us instead. This is a hack; null2 is trace-dependent and
   * thus undefined for P7Forward() scoring; see commentary in hmmpfam.c.
   */
  if (do_forward) whole_sc = sc_override;

  /* Go through and put all the accepted domains into the hit list.
   */
  whole_pval = PValue(hmm, whole_sc);
  for (tidx = 0, didx = 1; tidx < ntr; tidx++) {
    if (! usedomain[tidx]) continue;

    TraceSimpleBounds(tarr[tidx], &i1, &i2, &k1, &k2);
    pvalue = PValue(hmm, score[tidx]);

    if (pvalue <= thresh->domE && score[tidx] >= thresh->domT) {
      // We are not going to do this
      // ali     = CreateFancyAli(tarr[tidx], hmm, dsq, seqname);

      if (hmmpfam_mode)
        sortkey = -1.*(double)i1; /* hmmpfam: sort on position in seq    */
      else
        sortkey = score[tidx];    /* hmmsearch: sort on E (monotonic w/ sc) */

      RegisterHit(dhit, sortkey,
                  pvalue,     score[tidx],
                  whole_pval, whole_sc,
              //  hmmpfam_mode ? hmm->name : seqname,
              //  hmmpfam_mode ? hmm->acc  : seqacc,
              //  hmmpfam_mode ? hmm->desc : seqdesc,
                  i1,i2, L,
                  k1,k2, hmm->M,
              //  didx,ndom,ali);    // Remove ali
                  didx,ndom);
    }
    didx++;
  }

  /* Now register the global hit, with the domain-derived score.
   */

  /* sorting:
   * hmmpfam has to worry that score and E-value are not monotonic
   * when multiple HMMs (with different EVD parameters) are potential
   * targets. Therefore in hmmpfam_mode we apply a weird hack
   * to sort primarily on E-value, but on score
   * for really good hits with E=0.0... works because we can
   * assume 100000. > -log(DBL_MIN).
   * hmmsearch simply sorts on score (which for a single HMM, we
   * know is monotonic with E-value).
   */
  if (hmmpfam_mode)
    sortkey = (whole_pval > 0.0) ? -1.*log(whole_pval) : 100000. + whole_sc;
  else
    sortkey = whole_sc;

  /* Note: we've recalculated whole_sc and it may have decreased
   *       after the null2 correction was applied. For Pfam GA, TC,
   *       or NC cutoffs, we have to be sure that everything on the
   *       hitlist is correct (the hmmpfam output routine assumes it,
   *       otherwise it would have to reload each HMM to get its
   *       cutoffs). In all other cases, though, we don't care if
   *       the hit list has a bit too many things on it, because the
   *       output routine in hmmsearch or hmmpfam will check against
   *       the cutoffs. Hence we only need to check against globT
   *       (it may be set by GA, TC, or NC) but not globE.
   *                 - SRE, CSHL genome mtg May 2001
   */
  if (whole_sc >= thresh->globT) {
    RegisterHit(ghit, sortkey,
                whole_pval, whole_sc,
                0., 0.,                   /* no mother seq */
            //  hmmpfam_mode ? hmm->name : seqname,
            //  hmmpfam_mode ? hmm->acc  : seqacc,
            //  hmmpfam_mode ? hmm->desc : seqdesc,
                0,0,0,                    /* seq positions  */
                0,0,0,                    /* HMM positions  */
            //  0, ndom,                  /* # domains info    */
            //  NULL);                    /* alignment info */
                0, ndom);                 /* # domains info    */
  }

  /* Clean up and return.
   */
  for (tidx = 0; tidx < ntr; tidx++)
    P7FreeTrace(tarr[tidx]);
  free(tarr);
  free(score);
  free(usedomain);
  if (debug > 1) Rcout << "Leaving PostprocessSignificantHit" << std::endl;
  return whole_sc;
}








/* Function: AllocPlan7Matrix()
 * Date:     SRE, Tue Nov 19 07:14:47 2002 [St. Louis]
 *
 * Purpose:  Used to be the main allocator for dp matrices; we used to
 *           allocate, calculate, free. But this spent a lot of time
 *           in malloc(). Replaced with Create..() and Resize..() to
 *           allow matrix reuse in P7Viterbi(), the main alignment
 *           engine. But matrices are alloc'ed by other alignment engines
 *           too, ones that are less frequently called and less
 *           important to optimization of cpu performance. Instead of
 *           tracking changes through them, for now, provide
 *           an Alloc...() call with the same API that's just a wrapper.
 *
 * Args:     rows  - generally L+1, or 2; # of DP rows in seq dimension to alloc
 *           M     - size of model, in nodes
 *           xmx, mmx, imx, dmx
 *                 - RETURN: ptrs to four mx components as a convenience
 *
 * Returns:  mx
 *           Caller free's w/ FreePlan7Matrix()
 */
struct dpmatrix_s *
AllocPlan7Matrix(int rows, int M, int ***xmx, int ***mmx, int ***imx, int ***dmx)
{
  AllocPlan7Matrix_count++;

  if (debug > 1) Rcout << "In AllocPlan7Matrix" << std::endl;

  struct dpmatrix_s *mx;
  mx = CreatePlan7Matrix(rows-1, M, 0, 0);
  if (xmx != NULL) *xmx = mx->xmx;
  if (mmx != NULL) *mmx = mx->mmx;
  if (imx != NULL) *imx = mx->imx;
  if (dmx != NULL) *dmx = mx->dmx;
  if (debug > 1) Rcout << "Leaving AllocPlan7Matrix" << std::endl;
  return mx;
}








/* Function: FreePlan7Matrix()
 *
 * Purpose:  Free a dynamic programming matrix allocated by CreatePlan7Matrix().
 *
 * Return:   (void)
 */
void
FreePlan7Matrix(struct dpmatrix_s *mx)
{
  FreePlan7Matrix_count++;
  
  if (debug > 1) Rcout << "In FreePlan7Matrix" << std::endl;

  free (mx->xmx_mem);
  free (mx->mmx_mem);
  free (mx->imx_mem);
  free (mx->dmx_mem);
  free (mx->xmx);
  free (mx->mmx);
  free (mx->imx);
  free (mx->dmx);
  free (mx);
  if (debug > 1) Rcout << "Leaving FreePlan7Matrix" << std::endl;
}










/* Function: P7SmallViterbiSize()
 * Date:     SRE, Fri Mar  6 15:20:04 1998 [St. Louis]
 *
 * Purpose:  Returns the ballpark predicted memory requirement for
 *           a P7SmallViterbi() alignment, in MB.
 *
 *           P7SmallViterbi() is a wrapper, calling both P7ParsingViterbi()
 *           and P7WeeViterbi(). P7ParsingViterbi() typically dominates
 *           the memory requirement, so the value returned
 *           is the P7ParsingViterbi() number.
 *    
 *           We don't (yet) worry about overflow issues like we did with
 *           P7ViterbiSize(). We'll have many other 32-bit int issues in the
 *           code if we overflow here.
 *
 * Args:     L - length of sequence
 *           M - length of HMM
 *
 * Returns:  # of MB
 */
int
P7SmallViterbiSize(int L, int M)
{
  P7SmallViterbiSize_count++;

  if (debug > 1) Rcout << "In P7SmallViterbiSize" << std::endl;
  if (debug > 1) Rcout << "Leaving P7SmallViterbiSize" << std::endl;

  return ((2 * sizeof(struct dpmatrix_s) +
           12 * (M+2) * sizeof(int)      + /* 2 matrices w/ 2 rows */
           16 * sizeof(int *)            + /* ptrs into rows of matrix */
           20 * sizeof(int)              + /* 5 special states     */
           2  * (L+1) * sizeof(int))       /* traceback indices    */
          / 1000000);
}


/* Function: P7WeeViterbiSize()
 * Date:     SRE, Fri Mar  6 15:40:42 1998 [St. Louis]
 *
 * Purpose:  Returns the ballpark predicted memory requirement for
 *           a P7WeeViterbi() alignment, in MB.
 *
 * Args:     L - length of sequence
 *           M - length of HMM
 *
 * Returns:  # of MB
 */
int
P7WeeViterbiSize(int L, int M)
{
  P7WeeViterbiSize_count++;

  if (debug > 1) Rcout << "In P7WeeViterbiSize" << std::endl;
  if (debug > 1) Rcout << "Leaving P7WeeViterbiSize" << std::endl;

  return ((2 * sizeof(struct dpmatrix_s) +
           12 * (M+2) * sizeof(int)      + /* 2 matrices w/ 2 rows */
           16 * sizeof(int *)            + /* ptrs into rows of matrix */
           20 * sizeof(int)              + /* 5 special states      */
           2  * (L+2) * sizeof(int) +      /* stacks for starts/ends (overkill) */
           (L+2) * sizeof(int) +           /* k assignments to seq positions */
           (L+2) * sizeof(char))           /* state assignments to seq pos */
          / 1000000);
}





/* Function: P7ParsingViterbi()
 * Date:     SRE, Wed Mar  4 14:07:31 1998 [St. Louis]
 *
 * Purpose:  The "hmmfs" linear-memory algorithm for finding
 *           the optimal alignment of a very long sequence to
 *           a looping, multihit (e.g. Plan7) model, parsing it into
 *           a series of nonoverlapping subsequences that match
 *           the model once. Other algorithms (e.g. P7Viterbi()
 *           or P7WeeViterbi()) are applied subsequently to
 *           these subsequences to recover complete alignments.
 *
 *           The hmmfs algorithm appears briefly in [Durbin98],
 *           but is otherwise unpublished.
 *
 *           The traceback structure returned is special: a
 *           "collapsed" trace S->B->E->...->B->E->T, where
 *           stateidx is unused and pos is used to indicate the
 *           position of B and E in the sequence. The matched
 *           subsequence is B_pos+1...E_pos. The number of
 *           matches in the trace is (tlen/2)-1.
 *
 * Args:     dsq    - sequence in digitized form
 *           L      - length of dsq
 *           hmm    - the model (log odds scores ready)
 *           ret_tr - RETURN: a collapsed traceback.
 *
 * Returns:  Score of the optimal Viterbi alignment, in bits.
 */
float
P7ParsingViterbi(unsigned char *dsq, int L, struct plan7_s *hmm, struct p7trace_s **ret_tr)
{
  P7ParsingViterbi_count++;

  if (debug > 1) Rcout << "In P7ParsingViterbi" << std::endl;

  struct dpmatrix_s *mx;        /* two rows of score matrix */
  struct dpmatrix_s *tmx;       /* two rows of misused score matrix: traceback ptrs */
  struct p7trace_s  *tr;        /* RETURN: collapsed traceback */
  int  **xmx, **mmx, **dmx, **imx; /* convenience ptrs to score matrix */
  int  **xtr, **mtr, **dtr, **itr; /* convenience ptrs to traceback pointers */
  int   *btr, *etr;             /* O(L) trace ptrs for B, E state pts in seq */
  int    sc;                    /* integer score of optimal alignment  */
  int    i,k,tpos;              /* index for seq, model, trace position */
  int    cur, prv;              /* indices for rolling dp matrix */
  int    curralloc;             /* size of allocation for tr */


  /* Alloc a DP matrix and traceback pointers, two rows each, O(M).
   * Alloc two O(L) arrays to trace back through the sequence thru B and E.
   */
  mx  = AllocPlan7Matrix(2, hmm->M, &xmx, &mmx, &imx, &dmx);
  tmx = AllocPlan7Matrix(2, hmm->M, &xtr, &mtr, &itr, &dtr);
  // btr = MallocOrDie(sizeof(int) * (L+1));
  // etr = MallocOrDie(sizeof(int) * (L+1));
  btr = (int *) malloc((L+1) * sizeof(int));  if (btr == NULL) Rcpp::stop("Memory allocation failed!\n");
  etr = (int *) malloc((L+1) * sizeof(int));  if (etr == NULL) Rcpp::stop("Memory allocation failed!\n");

  /* Initialization of the zero row.
   */
  xmx[0][XMN] = 0;                                   /* S->N, p=1            */
  xmx[0][XMB] = hmm->xsc[XTN][MOVE];                 /* S->N->B, no N-tail   */
  btr[0]      = 0;
  xmx[0][XME] = xmx[0][XMC] = xmx[0][XMJ] = -INFTY;  /* need seq to get here */
  etr[0]      = -1;
  for (k = 0; k <= hmm->M; k++)
    mmx[0][k] = imx[0][k] = dmx[0][k] = -INFTY;      /* need seq to get here */

  /* Recursion. Done as a pull. Rolling index trick. Trace ptr propagation trick.
   * Note some slightly wasteful boundary conditions:
   *    tsc[0] = -INFTY for all eight transitions (no node 0)
   *    D_M and I_M are wastefully calculated (they don't exist)
   *   
   * Notes on traceback pointer propagation.
   *  - In the path B->E, we propagate the i that B was aligned to in the optimal
   *    alignment, via mtr, dtr, and itr.
   *  - When we reach an E, we record the i of the B it started from in etr.
   *  - In a looping path E->J...->B or terminal path E->C...->T, we propagate
   *    the i that E was aligned to in the optimal alignment via xtr[][XMC]
   *    and xtr[][XMJ].
   *  - When we enter B, we record the i of the best previous E, or 0 if there
   *    isn't one, in btr.
   */


  if (debug > 1) Rcout << "    P7ParsingViterbi ... entering loop with L=" << L << std::endl;

  if (debug > 1) Rcout << "       hmm->tsc[TMM]   [1] = " << hmm->tsc[TMM]   [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->tsc[TIM]   [1] = " << hmm->tsc[TIM]   [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->bsc        [1] = " << hmm->bsc        [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->tsc[TDM]   [1] = " << hmm->tsc[TDM]   [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->msc[dsq[1]][1] = " << hmm->msc[dsq[1]][1] << std::endl;    // DEBUG - MRL ... check progress


  cur = 0;   /* Added to prevent compile warning: 'cur' may be used uninitialized */

  for (i = 1; i <= L; i++) {
     if (i%1000000 == 0) {
       if (debug > 1) Rcout << "    i = " << i << std::endl;    // DEBUG - MRL ... check progress

       if (debug > 1) Rcout << "       hmm->tsc[TMM]   [1] = " << hmm->tsc[TMM]   [1] << std::endl;    // DEBUG - MRL ... check progress
       if (debug > 1) Rcout << "       hmm->tsc[TIM]   [1] = " << hmm->tsc[TIM]   [1] << std::endl;    // DEBUG - MRL ... check progress
       if (debug > 1) Rcout << "       hmm->bsc        [1] = " << hmm->bsc        [1] << std::endl;    // DEBUG - MRL ... check progress
       if (debug > 1) Rcout << "       hmm->tsc[TDM]   [1] = " << hmm->tsc[TDM]   [1] << std::endl;    // DEBUG - MRL ... check progress
       if (debug > 1) Rcout << "       hmm->msc[dsq[i]][1] = " << hmm->msc[dsq[i]][1] << std::endl;    // DEBUG - MRL ... check progress
       
     }
    cur = i % 2;
    prv = !cur;

    mmx[cur][0] = imx[cur][0] = dmx[cur][0] = -INFTY;

    for (k = 1; k <= hmm->M; k++) {
                                /* match state */
      mmx[cur][k] = -INFTY;
      if ((sc = mmx[prv][k-1] + hmm->tsc[TMM][k-1]) > -INFTY)
        { mmx[cur][k] = sc; mtr[cur][k] = mtr[prv][k-1]; }
      if ((sc = imx[prv][k-1] + hmm->tsc[TIM][k-1]) > mmx[cur][k])
        { mmx[cur][k] = sc; mtr[cur][k] = itr[prv][k-1]; }
      if ((sc = xmx[prv][XMB] + hmm->bsc[k]) > mmx[cur][k])
        { mmx[cur][k] = sc; mtr[cur][k] = i-1; }
      if ((sc = dmx[prv][k-1] + hmm->tsc[TDM][k-1]) > mmx[cur][k])
        { mmx[cur][k] = sc; mtr[cur][k] = dtr[prv][k-1]; }
      if (hmm->msc[dsq[i]][k] != -INFTY)
        mmx[cur][k] += hmm->msc[dsq[i]][k];
      else
        mmx[cur][k] = -INFTY;

                                /* delete state */
      dmx[cur][k] = -INFTY;
      if ((sc = mmx[cur][k-1] + hmm->tsc[TMD][k-1]) > -INFTY)
        { dmx[cur][k] = sc; dtr[cur][k] = mtr[cur][k-1]; }
      if ((sc = dmx[cur][k-1] + hmm->tsc[TDD][k-1]) > dmx[cur][k])
        { dmx[cur][k] = sc; dtr[cur][k] = dtr[cur][k-1]; }

                                /* insert state */
      if (k < hmm->M) {
        imx[cur][k] = -INFTY;
        if ((sc = mmx[prv][k] + hmm->tsc[TMI][k]) > -INFTY)
          { imx[cur][k] = sc; itr[cur][k] = mtr[prv][k]; }
        if ((sc = imx[prv][k] + hmm->tsc[TII][k]) > imx[cur][k])
          { imx[cur][k] = sc; itr[cur][k] = itr[prv][k]; }
        if (hmm->isc[dsq[i]][k] != -INFTY)
          imx[cur][k] += hmm->isc[dsq[i]][k];
        else
          imx[cur][k] = -INFTY;
      }
    }

    /* Now the special states. Order is important here.
     * remember, C and J emissions are zero score by definition,
     */
                                /* N state */
    xmx[cur][XMN] = -INFTY;
    if ((sc = xmx[prv][XMN] + hmm->xsc[XTN][LOOP]) > -INFTY)
      xmx[cur][XMN] = sc;
                                /* E state */
    xmx[cur][XME] = -INFTY;
    for (k = 1; k <= hmm->M; k++)
      if ((sc =  mmx[cur][k] + hmm->esc[k]) > xmx[cur][XME])
        { xmx[cur][XME] = sc; etr[i] = mtr[cur][k]; }
                                /* J state */
    xmx[cur][XMJ] = -INFTY;
    if ((sc = xmx[prv][XMJ] + hmm->xsc[XTJ][LOOP]) > -INFTY)
      { xmx[cur][XMJ] = sc; xtr[cur][XMJ] = xtr[prv][XMJ]; }
    if ((sc = xmx[cur][XME]   + hmm->xsc[XTE][LOOP]) > xmx[cur][XMJ])
      { xmx[cur][XMJ] = sc; xtr[cur][XMJ] = i; }
                                /* B state */
    xmx[cur][XMB] = -INFTY;
    if ((sc = xmx[cur][XMN] + hmm->xsc[XTN][MOVE]) > -INFTY)
      { xmx[cur][XMB] = sc; btr[i] = 0; }
    if ((sc = xmx[cur][XMJ] + hmm->xsc[XTJ][MOVE]) > xmx[cur][XMB])
      { xmx[cur][XMB] = sc; btr[i] = xtr[cur][XMJ]; }
                                /* C state */
    xmx[cur][XMC] = -INFTY;
    if ((sc = xmx[prv][XMC] + hmm->xsc[XTC][LOOP]) > -INFTY)
      { xmx[cur][XMC] = sc; xtr[cur][XMC] = xtr[prv][XMC]; }
    if ((sc = xmx[cur][XME] + hmm->xsc[XTE][MOVE]) > xmx[cur][XMC])
      { xmx[cur][XMC] = sc; xtr[cur][XMC] = i; }

  }
  
  if (debug > 1) Rcout << "    P7ParsingViterbi ... leaving loop" << std::endl;

                                /* T state (not stored) */
  sc = xmx[cur][XMC] + hmm->xsc[XTC][MOVE];


  /*****************************************************************
   * Collapsed traceback stage.
   * xtr[L%2][XMC] contains the position j of the previous E
   * etr[j]        contains the position i of the previous B
   * btr[i]        contains the position j of the previous E, or 0
   * continue until btr[i] = 0.
   *****************************************************************/

  if (debug > 1) Rcout << "      L             = " << L             << std::endl;    // DEBUG - MRL
  if (debug > 1) Rcout << "      XMC           = " << XMC           << std::endl;    // DEBUG - MRL
  if (debug > 1) Rcout << "      i             = " << i             << std::endl;    // DEBUG - MRL
  if (debug > 1) Rcout << "      xtr[L%2][XMC] = " << xtr[L%2][XMC] << std::endl;    // DEBUG - MRL
  if (debug > 1) Rcout << "      etr[i]        = " << etr[i]        << std::endl;    // DEBUG - MRL
  if (debug > 1) Rcout << "      btr[i]        = " << btr[i]        << std::endl;    // DEBUG - MRL


  curralloc = 2;                /* minimum: no hits */
  P7AllocTrace(curralloc, &tr);

  /* Init of collapsed trace. Back to front; we ReverseTrace() later.
   */
  tpos = 0;
  tr->statetype[tpos] = STT;
  tr->pos[tpos]       = 0;
  i                   = xtr[L%2][XMC];

  if (debug > 1) Rcout << "      Prior to R7ReallocTrace loop:    i=" << i << std::endl;    // DEBUG - MRL

  while (i > 0)
    {
      curralloc += 2;
      P7ReallocTrace(tr, curralloc);

      tpos++;
      tr->statetype[tpos] = STE;
      tr->pos[tpos] = i;
      i = etr[i];

      tpos++;
      tr->statetype[tpos] = STB;
      tr->pos[tpos] = i;
      i = btr[i];
    }

  // Rcpp::stop("Ending Execution\n");

  tpos++;
  tr->statetype[tpos] = STS;
  tr->pos[tpos]       = 0;
  tr->tlen = tpos + 1;
  P7ReverseTrace(tr);

  FreePlan7Matrix(mx);
  FreePlan7Matrix(tmx);
  free(btr);
  free(etr);

  *ret_tr = tr;
  if (debug > 1) Rcout << "Leaving P7ParsingViterbi" << std::endl;
  return Scorify(sc);
}






static float
get_wee_midpt(struct plan7_s *hmm, unsigned char *dsq, int L,
              int k1, char t1, int s1,
              int k3, char t3, int s3,
              int *ret_k2, char *ret_t2, int *ret_s2)
{
  get_wee_midpt_count++;
  
  if (debug > 1) Rcout << "In get_wee_midpt" << std::endl;

  struct dpmatrix_s *fwd;
  struct dpmatrix_s *bck;
  int        **xmx;             /* convenience ptr into special states */
  int        **mmx;             /* convenience ptr into match states   */
  int        **imx;             /* convenience ptr into insert states  */
  int        **dmx;             /* convenience ptr into delete states  */
  int          k2;
  char         t2;
  int          s2;
  int          cur, prv, nxt;   /* current, previous, next row index (0 or 1)*/
  int          i,k;             /* indices for seq, model */
  int          sc;              /* integer score */
  int          max;             /* maximum integer score */
  int          start;           /* s1 to start at (need, for STS special case) */


  /* Choose our midpoint.
   * Special cases: s1, s3 adjacent and t1 == STS: s2 = s1
   *                s1, s3 adjacent and t3 == STT: s2 = s3
   *                (where we must replace STS, STT eventually)
   */
  s2 = s1 + (s3-s1) / 2;
  if (s3-s1 == 1 && t1 == STS) s2 = s1;
  if (s3-s1 == 1 && t3 == STT) s2 = s3;

  /* STS is a special case. STS aligns to row zero by convention,
   * but we'll be passed s1=1, t1=STS. We have to init on row
   * zero then start DP on row 1.
   */
  start = (t1 == STS) ? 0 : s1;

  /* Allocate our forward two rows.
   * Initialize row zero.
   */
  fwd = AllocPlan7Matrix(2, hmm->M, &xmx, &mmx, &imx, &dmx);
  cur = start%2;
  xmx[cur][XMN] = xmx[cur][XMB] = -INFTY;
  xmx[cur][XME] = xmx[cur][XMC] = -INFTY;
  for (k = k1; k <= k3; k++)
    mmx[cur][k] = imx[cur][k] = dmx[cur][k] = -INFTY;

  /* Where to put our zero for our start point...
   * (only possible to start on an emitting state; J disallowed)
   */
  switch (t1) {
  case STM: mmx[cur][k1]  = 0; break;
  case STI: imx[cur][k1]  = 0; break;
  case STN: xmx[cur][XMN] = 0; break;
  case STC: xmx[cur][XMC] = 0; break;
  case STS: xmx[cur][XMN] = 0; break;
  // default:  Die("you can't init get_wee_midpt with a %s\n", Statetype(t1));
  }

  /* Still initializing.
   * Deal with pulling horizontal matrix moves in initial row.
   * These are any transitions to nonemitters:
   *    STM-> E, D
   *    STI-> none
   *    STN-> B
   *    STC-> (T, but we never observe this in the forward pass of a d&c)
   *    STE-> C
   *    STS-> (N, already implied by setting xmx[cur][XMN] = 0)
   *    STB-> M
   */
  if (t1 == STM)
    {
      for (k = k1+1; k <= k3; k++)
        {                               /* transits into STD */
          dmx[cur][k] = -INFTY;
          if ((sc = mmx[cur][k-1] + hmm->tsc[TMD][k-1]) > -INFTY)
            dmx[cur][k] = sc;
          if ((sc = dmx[cur][k-1] + hmm->tsc[TDD][k-1]) > dmx[cur][k])
            dmx[cur][k] = sc;
        }
                                /* transit into STE */
      xmx[cur][XME] = -INFTY;
      if ((sc = mmx[cur][k1] + hmm->esc[k1]) > -INFTY)
        xmx[cur][XME] = sc;
    }
                                /* transit into STB from STN */
  xmx[cur][XMB] = -INFTY;
  if ((sc = xmx[cur][XMN] + hmm->xsc[XTN][MOVE]) > -INFTY)
    xmx[cur][XMB] = sc;
                                /* transit into STC from STE */
  xmx[cur][XMC] = -INFTY;
  if ((sc = xmx[cur][XME] + hmm->xsc[XTE][MOVE]) > -INFTY)
    xmx[cur][XMC] = sc;
 
  /* Done initializing.
   * Start recursive DP; sweep forward to chosen s2 midpoint. Done as a pull.
   */
  for (i = start+1; i <= s2; i++) {
    cur = i % 2;
    prv = !cur;

    mmx[cur][k1] = imx[cur][k1] = dmx[cur][k1] = -INFTY;

    /* Insert state in column k1, and B->M transition in k1.
     */
    if (k1 < hmm->M) {
      imx[cur][k1] = -INFTY;
      if ((sc = mmx[prv][k1] + hmm->tsc[TMI][k1]) > -INFTY)
        imx[cur][k1] = sc;
      if ((sc = imx[prv][k1] + hmm->tsc[TII][k1]) > imx[cur][k1])
        imx[cur][k1] = sc;
      if (hmm->isc[dsq[i]][k1] != -INFTY)
        imx[cur][k1] += hmm->isc[dsq[i]][k1];
      else
        imx[cur][k1] = -INFTY;
    }
    if ((sc = xmx[prv][XMB] + hmm->bsc[k1]) > -INFTY)
      mmx[cur][k1] = sc;
    if (hmm->msc[dsq[i]][k1] != -INFTY)
      mmx[cur][k1] += hmm->msc[dsq[i]][k1];
    else
      mmx[cur][k1] = -INFTY;

    /* Main chunk of recursion across model positions
     */
    for (k = k1+1; k <= k3; k++) {
                                /* match state */
      mmx[cur][k]  = -INFTY;
      if ((sc = mmx[prv][k-1] + hmm->tsc[TMM][k-1]) > -INFTY)
        mmx[cur][k] = sc;
      if ((sc = imx[prv][k-1] + hmm->tsc[TIM][k-1]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if ((sc = xmx[prv][XMB] + hmm->bsc[k]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if ((sc = dmx[prv][k-1] + hmm->tsc[TDM][k-1]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if (hmm->msc[dsq[i]][k] != -INFTY)
        mmx[cur][k] += hmm->msc[dsq[i]][k];
      else
        mmx[cur][k] = -INFTY;

                                /* delete state */
      dmx[cur][k] = -INFTY;
      if (k < hmm->M) {
        if ((sc = mmx[cur][k-1] + hmm->tsc[TMD][k-1]) > -INFTY)
          dmx[cur][k] = sc;
        if ((sc = dmx[cur][k-1] + hmm->tsc[TDD][k-1]) > dmx[cur][k])
          dmx[cur][k] = sc;
      }

                                /* insert state */
      imx[cur][k] = -INFTY;
      if (k < hmm->M) {
        if ((sc = mmx[prv][k] + hmm->tsc[TMI][k]) > -INFTY)
          imx[cur][k] = sc;
        if ((sc = imx[prv][k] + hmm->tsc[TII][k]) > imx[cur][k])
          imx[cur][k] = sc;
        if (hmm->isc[dsq[i]][k] != -INFTY)
          imx[cur][k] += hmm->isc[dsq[i]][k];
        else
          imx[cur][k] = -INFTY;
      }
    }
                                /* N state */
    xmx[cur][XMN] = -INFTY;
    if ((sc = xmx[prv][XMN] + hmm->xsc[XTN][LOOP]) > -INFTY)
      xmx[cur][XMN] = sc;
                                /* E state */
    xmx[cur][XME] = -INFTY;
    for (k = k1; k <= k3 && k <= hmm->M; k++)
      if ((sc =  mmx[cur][k] + hmm->esc[k]) > xmx[cur][XME])
        xmx[cur][XME] = sc;
                                /* B state */
    xmx[cur][XMB] = -INFTY;
    if ((sc = xmx[cur][XMN] + hmm->xsc[XTN][MOVE]) > -INFTY)
      xmx[cur][XMB] = sc;
                                /* C state */
    xmx[cur][XMC] = -INFTY;
    if ((sc = xmx[prv][XMC] + hmm->xsc[XTC][LOOP]) > -INFTY)
      xmx[cur][XMC] = sc;
    if ((sc = xmx[cur][XME] + hmm->xsc[XTE][MOVE]) > xmx[cur][XMC])
      xmx[cur][XMC] = sc;
  }

  /* Row s2%2 in fwd matrix now contains valid scores from s1 (start) to s2,
   * with J transitions disallowed (no cycles through model).
   */

  /*****************************************************************
   * Backwards pass.
   *****************************************************************/

  /* Allocate our backwards two rows. Init last row.
   */
  bck = AllocPlan7Matrix(2, hmm->M, &xmx, &mmx, &imx, &dmx);
  nxt = s3%2;
  xmx[nxt][XMN] = xmx[nxt][XMB] = -INFTY;
  xmx[nxt][XME] = xmx[nxt][XMC] = -INFTY;
  for (k = k1; k <= k3 + 1; k++)
    mmx[nxt][k] = imx[nxt][k] = dmx[nxt][k] = -INFTY;
  cur = !nxt;
  mmx[cur][k3+1] = imx[cur][k3+1] = dmx[cur][k3+1] = -INFTY;

  /* Where to put the zero for our end point on last row.
   */
  switch (t3) {
  case STM: mmx[nxt][k3]  = 0; break;
  case STI: imx[nxt][k3]  = 0; break;
  case STN: xmx[nxt][XMN] = 0; break;
  case STC: xmx[nxt][XMC] = 0; break;   /* must be an emitting C */
  case STT: xmx[nxt][XMC] = hmm->xsc[XTC][MOVE];  break; /* C->T implied */
  // default:  Die("you can't init get_wee_midpt with a %s\n", Statetype(t3));
  }

  /* Still initializing.
   * In the case t3==STT, there are a few horizontal moves possible
   * on row s3, because STT isn't an emitter. All other states are
   * emitters, so their connections have to be to the previous row s3-1.
   */
  if (t3 == STT)
    {                           /* E->C */
      xmx[nxt][XME] = xmx[nxt][XMC] + hmm->xsc[XTE][MOVE];
                                /* M->E */
      for (k = k3; k >= k1; k--) {
        mmx[nxt][k] = xmx[nxt][XME] + hmm->esc[k];
        if (s3 != s2)
          mmx[nxt][k] += hmm->msc[dsq[s3]][k];
      }
    }

  /* Start recursive DP; sweep backwards to chosen s2 midpoint.
   * Done as a pull. M, I scores at current row do /not/ include
   * emission scores. Be careful of integer underflow.
   */
  for (i = s3-1; i >= s2; i--) {
                                /* note i < L, so i+1 is always a legal index */
    cur = i%2;
    nxt = !cur;
                                /* C pulls from C (T is special cased) */
    xmx[cur][XMC] = -INFTY;
    if ((sc = xmx[nxt][XMC] + hmm->xsc[XTC][LOOP]) > -INFTY)
      xmx[cur][XMC] = sc;
                                /* B pulls from M's */
    xmx[cur][XMB] = -INFTY;
    for (k = k1; k <= k3; k++)
      if ((sc = mmx[nxt][k] + hmm->bsc[k]) > xmx[cur][XMB])
        xmx[cur][XMB] = sc;
                                /* E pulls from C (J disallowed) */
    xmx[cur][XME] = -INFTY;
    if ((sc = xmx[cur][XMC] + hmm->xsc[XTE][MOVE]) > -INFTY)
      xmx[cur][XME] = sc;
                                /* N pulls from B, N */
    xmx[cur][XMN] = -INFTY;
    if ((sc = xmx[cur][XMB] + hmm->xsc[XTN][MOVE]) > -INFTY)
      xmx[cur][XMN] = sc;
    if ((sc = xmx[nxt][XMN] + hmm->xsc[XTN][LOOP]) > xmx[cur][XMN])
      xmx[cur][XMN] = sc;

    /* Main recursion across model
     */
    for (k = k3; k >= k1; k--)  {
                                /* special case k == M */
      if (k == hmm->M) {
        mmx[cur][k] = xmx[cur][XME]; /* p=1 transition to E by definition */
        dmx[cur][k] = -INFTY;   /* doesn't exist */
        imx[cur][k] = -INFTY;   /* doesn't exist */
        if (i != s2)
          mmx[cur][k] += hmm->msc[dsq[i]][k];
        continue;
      }         /* below this k < M, so k+1 is a legal index */

                                /* pull into match state */
      mmx[cur][k] = -INFTY;
      if ((sc = xmx[cur][XME] + hmm->esc[k]) > -INFTY)
        mmx[cur][k] = sc;
      if ((sc = mmx[nxt][k+1] + hmm->tsc[TMM][k]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if ((sc = imx[nxt][k] + hmm->tsc[TMI][k]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if ((sc = dmx[cur][k+1] + hmm->tsc[TMD][k]) > mmx[cur][k])
        mmx[cur][k] = sc;
      if (i != s2)
        mmx[cur][k] += hmm->msc[dsq[i]][k];

                                /* pull into delete state */
      dmx[cur][k] = -INFTY;
      if ((sc = mmx[nxt][k+1] + hmm->tsc[TDM][k]) > -INFTY)
        dmx[cur][k] = sc;
      if ((sc = dmx[cur][k+1] + hmm->tsc[TDD][k]) > dmx[cur][k])
        dmx[cur][k] = sc;
                                /* pull into insert state */
      imx[cur][k] = -INFTY;
      if ((sc = mmx[nxt][k+1] + hmm->tsc[TIM][k]) > -INFTY)
        imx[cur][k] = sc;
      if ((sc = imx[nxt][k] + hmm->tsc[TII][k]) > imx[cur][k])
        imx[cur][k] = sc;
      if (i != s2)
        imx[cur][k] += hmm->isc[dsq[i]][k];

    }
  }
  
  /*****************************************************************
   * DP complete; we have both forward and backward passes. Now we
   * look across the s2 row and find the optimal emitting state.
   *****************************************************************/

  cur = s2%2;
  max = -INFTY;
  for (k = k1; k <= k3; k++)
    {
      if ((sc = fwd->mmx[cur][k] + bck->mmx[cur][k]) > max)
        { k2 = k; t2 = STM; max = sc; }
      if ((sc = fwd->imx[cur][k] + bck->imx[cur][k]) > max)
        { k2 = k; t2 = STI; max = sc; }
    }
  if ((sc = fwd->xmx[cur][XMN] + bck->xmx[cur][XMN]) > max)
    { k2 = 1;        t2 = STN; max = sc; }
  if ((sc = fwd->xmx[cur][XMC] + bck->xmx[cur][XMC]) > max)
    { k2 = hmm->M;   t2 = STC; max = sc; }

  /*****************************************************************
   * Garbage collection, return.
   *****************************************************************/

  FreePlan7Matrix(fwd);
  FreePlan7Matrix(bck);
  *ret_k2 = k2;
  *ret_t2 = t2;
  *ret_s2 = s2;
  if (debug > 1) Rcout << "Leaving get_wee_midpt" << std::endl;
  return Scorify(max);
}












/* Function: P7WeeViterbi()
 * Date:     SRE, Wed Mar  4 08:24:04 1998 [St. Louis]
 *
 * Purpose:  Hirschberg/Myers/Miller linear memory alignment.
 *           See [Hirschberg75,MyM-88a] for the idea of the algorithm.
 *           Adapted to HMM implementation.
 *
 *           Requires that you /know/ that there's only
 *           one hit to the model in the sequence: either
 *           because you're forcing single-hit, or you've
 *           previously called P7ParsingViterbi to parse
 *           the sequence into single-hit segments. The reason
 *           for this is that a cyclic model (a la Plan7)
 *           defeats the nice divide and conquer trick.
 *           (I think some trickery with propagated trace pointers
 *           could get around this but haven't explored it.)
 *           This is implemented by ignoring transitions
 *           to/from J state.
 *
 * Args:     dsq    - sequence in digitized form
 *           L      - length of dsq
 *           hmm    - the model
 *           ret_tr - RETURN: traceback.
 *
 * Returns:  Score of the optimal Viterbi alignment.
 */
float
P7WeeViterbi(unsigned char *dsq, int L, struct plan7_s *hmm, struct p7trace_s **ret_tr)
{
  P7WeeViterbi_count++;

  if (debug > 1) Rcout << "In P7WeeViterbi" << std::endl;

  struct p7trace_s *tr;         /* RETURN: traceback */
  int          *kassign;        /* 0..L+1, alignment of seq positions to model nodes */
  char         *tassign;        /* 0..L+1, alignment of seq positions to state types */
  int          *endlist;        /* stack of end points on sequence to work on */
  int          *startlist;      /* stack of start points on sequence to work on */
  int          lpos;            /* position in endlist, startlist */
  int          k1, k2, k3;      /* start, mid, end in model      */
  char         t1, t2, t3;      /* start, mid, end in state type */
  int          s1, s2, s3;      /* start, mid, end in sequence   */
  float        sc;              /* score of segment optimal alignment */
  float        ret_sc;          /* optimal score over complete seq */
  int          tlen;            /* length needed for trace */
  int          i, k, tpos;      /* index in sequence, model, trace */


  /* Initialize.
   */
  // kassign   = MallocOrDie (sizeof(int) * (L+1));
  // tassign   = MallocOrDie (sizeof(char)* (L+1));
  // endlist   = MallocOrDie (sizeof(int) * (L+1));
  // startlist = MallocOrDie (sizeof(int) * (L+1));

  kassign   = (int  *) malloc ((L+1) * sizeof(int) );
  tassign   = (char *) malloc ((L+1) * sizeof(char));
  endlist   = (int  *) malloc ((L+1) * sizeof(int) );
  startlist = (int  *) malloc ((L+1) * sizeof(int) );

  lpos = 0;
  startlist[lpos] = 1;
  endlist[lpos]   = L;
  kassign[1]      = 1;
  kassign[L]      = hmm->M;
  tassign[1]      = STS;        /* temporary boundary condition! will become N or M */
  tassign[L]      = STT;        /* temporary boundary condition! will become M or C */

  
  ret_sc = 0.0;  /* k2 will be (probably) be set by the following loop
                    Statement added to prevent compiler warning */

  /* Recursive divide-and-conquer alignment.
   */
  while (lpos >= 0)
    {
                                /* Pop a segment off the stack */
      s1 = startlist[lpos];
      k1 = kassign[s1];
      t1 = tassign[s1];
      s3 = endlist[lpos];
      k3 = kassign[s3];
      t3 = tassign[s3];
      lpos--;

      k2 = 0;  /* k2 will be set by call to get_wee_midpt
                  Statement added to prevent compiler warning */

                                /* find optimal midpoint of segment */
      sc = get_wee_midpt(hmm, dsq, L, k1, t1, s1, k3, t3, s3, &k2, &t2, &s2);
      kassign[s2] = k2;
      tassign[s2] = t2;
                               /* score is valid on first pass */
      if (t1 == STS && t3 == STT) ret_sc = sc;

                                /* push N-terminal segment on stack */
      if (t2 != STN && (s2 - s1 > 1 || (s2 - s1 == 1 && t1 == STS)))
        {
          lpos++;
          startlist[lpos] = s1;
          endlist[lpos]   = s2;
        }
                                /* push C-terminal segment on stack */
      if (t2 != STC && (s3 - s2 > 1 || (s3 - s2 == 1 && t3 == STT)))
        {
          lpos++;
          startlist[lpos] = s2;
          endlist[lpos]   = s3;
        }

      if (t2 == STN)
        {                       /* if we see STN midpoint, we know the whole N-term is STN */
          for (; s2 >= s1; s2--) {
            kassign[s2] = 1;
            tassign[s2] = STN;
          }
        }
      if (t2 == STC)
        {                       /* if we see STC midpoint, we know whole C-term is STC */
          for (; s2 <= s3; s2++) {
            kassign[s2] = hmm->M;
            tassign[s2] = STC;
          }
        }
    }

  /*****************************************************************
   * Construct a traceback structure from kassign/tassign by interpolating
   * necessary states.
   * Trace allocation is as follows. We clearly need L emitting states.
   * We also need nonemitting states as follows:
   * STS,STN,STB,STE,STC,STT = 6
   * STD: count k2-k1-1 in kassign M->M's
   * Also, count N->M's and M->C's (potential wing unfoldings)...
   *   ...and be careful to check wing unfoldings when there aren't
   *      any emitting N or C flanks! (bugfix, 2.1.1b)
   *****************************************************************/
  tlen = L + 6;
  for (i = 1; i < L; i++)
    {
      if (tassign[i] == STM && tassign[i+1] == STM)
        tlen += kassign[i+1] - kassign[i] - 1;
      if (tassign[i] == STN && tassign[i+1] == STM)
        tlen += kassign[i+1] - 1;
      if (tassign[i] == STM && tassign[i+1] == STC)
        tlen += hmm->M - kassign[i];
    }
  if (tassign[1] == STM) tlen += kassign[1] - 1;
  if (tassign[L] == STM) tlen += hmm->M - kassign[L];
  P7AllocTrace(tlen, &tr);

  tr->statetype[0] = STS;
  tr->nodeidx[0]   = 0;
  tr->pos[0]       = 0;
  tr->statetype[1] = STN;
  tr->nodeidx[1]   = 0;
  tr->pos[1]       = 0;
  tpos = 2;

  for (i = 1; i <= L; i++)
    {
      switch(tassign[i]) {
      case STM:
                                /* check for first match state */
        if (tr->statetype[tpos-1] == STN) {
          tr->statetype[tpos] = STB;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
          tpos++;
                                /* check for wing unfolding */
          if (Prob2Score(hmm->begin[kassign[i]], hmm->p1) + INTSCALE <= hmm->bsc[kassign[i]])
            for (k = 1; k < kassign[i]; k++) {
              tr->statetype[tpos] = STD;
              tr->nodeidx[tpos]   = k;
              tr->pos[tpos]       = 0;
              tpos++;
            }
        }
                                /* do the match state itself */
        tr->statetype[tpos] = STM;
        tr->nodeidx[tpos]   = kassign[i];
        tr->pos[tpos]       = i;
        tpos++;
                                /* do any deletes necessary 'til next match */
        if (i < L && tassign[i+1] == STM && kassign[i+1] - kassign[i] > 1)
          for (k = kassign[i] + 1; k < kassign[i+1]; k++)
            {
              tr->statetype[tpos] = STD;
              tr->nodeidx[tpos]   = k;
              tr->pos[tpos]       = 0;
              tpos++;
            }
                                /* check for last match state */
        if (i == L || tassign[i+1] == STC) {
                                /* check for wing unfolding */
          if (Prob2Score(hmm->end[kassign[i-1]], 1.) + INTSCALE <=  hmm->esc[kassign[i-1]])
            for (k = kassign[i]+1; k <= hmm->M; k++)
              {
                tr->statetype[tpos] = STD;
                tr->nodeidx[tpos]   = k;
                tr->pos[tpos]       = 0;
                tpos++;
              }
                                /* add on the end state */
          tr->statetype[tpos] = STE;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
          tpos++;
                                /* and a nonemitting C state */
          tr->statetype[tpos] = STC;
          tr->nodeidx[tpos]   = 0;
          tr->pos[tpos]       = 0;
          tpos++;
        }
        break;

      case STI:
        tr->statetype[tpos] = STI;
        tr->nodeidx[tpos]   = kassign[i];
        tr->pos[tpos]       = i;
        tpos++;
        break;

      case STN:
        tr->statetype[tpos] = STN;
        tr->nodeidx[tpos]   = 0;
        tr->pos[tpos]       = i;
        tpos++;
        break;

      case STC:
        tr->statetype[tpos] = STC;
        tr->nodeidx[tpos]   = 0;
        tr->pos[tpos]       = i;
        tpos++;
        break;

      // default: Die("Bogus state %s", Statetype(tassign[i]));
      }
    }
                                /* terminate the trace */
  tr->statetype[tpos] = STT;
  tr->nodeidx[tpos]   = 0;
  tr->pos[tpos]       = 0;
  tr->tlen = tpos+1;

  *ret_tr = tr;

  free(kassign);
  free(tassign);
  free(startlist);
  free(endlist);
  if (debug > 1) Rcout << "Leaving P7WeeViterbi" << std::endl;
  return ret_sc;
}





/* Function: P7SmallViterbi()
 * Date:     SRE, Fri Mar  6 15:29:41 1998 [St. Louis]
 *
 * Purpose:  Wrapper function, for linear memory alignment
 *           with same arguments as P7Viterbi().
 *
 *           Calls P7ParsingViterbi to break the sequence
 *           into fragments. Then, based on size of fragments,
 *           calls either P7Viterbi() or P7WeeViterbi() to
 *           get traces for them. Finally, assembles all these
 *           traces together to produce an overall optimal
 *           trace for the sequence.
 *
 *           If the trace isn't needed for some reason,
 *           all we do is call P7ParsingViterbi.
 *
 * Args:     dsq    - sequence in digitized form
 *           L      - length of dsq
 *           hmm    - the model
 *           mx     - DP matrix, growable
 *           ret_tr - RETURN: traceback; pass NULL if it's not wanted
 *
 * Returns:  Score of optimal alignment in bits.
 */
float
P7SmallViterbi(unsigned char *dsq, int L, struct plan7_s *hmm, struct dpmatrix_s *mx, struct p7trace_s **ret_tr)
{
  P7SmallViterbi_count++;

  if (debug > 1) Rcout << "In P7SmallViterbi" << std::endl;

  struct p7trace_s *ctr;        /* collapsed trace of optimal parse */
  struct p7trace_s *tr;         /* full trace of optimal alignment */
  struct p7trace_s **tarr;      /* trace array */
  int   ndom;                   /* number of subsequences */
  int   i;                      /* counter over domains   */
  int   pos;                    /* position in sequence */
  int   tpos;                   /* position in trace */
  int   tlen;                   /* length of full trace   */
  int   sqlen;                  /* length of a subsequence */
  int   totlen;                 /* length of L matched by model (as opposed to N/C/J) */
  float sc;                     /* score of optimal alignment */
  int   t2;                     /* position in a subtrace */

  /* Step 1. Call P7ParsingViterbi to calculate an optimal parse
   *         of the sequence into single-hit subsequences; this parse
   *         is returned in a "collapsed" trace
   */
  sc = P7ParsingViterbi(dsq, L, hmm, &ctr);

  // return sc;    // MRL - Debug ... early return

  /* If we don't want full trace, we're done;
   * also, if parsing viterbi returned a NULL trace we're done. */
  if (ctr == NULL || ret_tr == NULL)
    {
      P7FreeTrace(ctr);
      return sc;
    }
 
  /* Step 2. Call either P7Viterbi or P7WeeViterbi on each subsequence
   *         to recover a full traceback of each, collecting them in
   *         an array.
   */
  ndom = ctr->tlen/2 - 1;

  // tarr = MallocOrDie(sizeof(struct p7trace_s *) * ndom);
  tarr = (struct p7trace_s **) malloc(ndom * sizeof(struct p7trace_s *));  if (tarr == NULL) Rcpp::stop("Memory allocation failed!\n");

  tlen = totlen = 0;
  for (i = 0; i < ndom; i++)
    {
      sqlen = ctr->pos[i*2+2] - ctr->pos[i*2+1];   /* length of subseq */

      if (P7ViterbiSpaceOK(sqlen, hmm->M, mx))
        P7Viterbi(dsq + ctr->pos[i*2+1], sqlen, hmm, mx, &(tarr[i]));
      else
        P7WeeViterbi(dsq + ctr->pos[i*2+1], sqlen, hmm, &(tarr[i]));

      tlen  += tarr[i]->tlen - 4; /* not counting S->N,...,C->T */
      totlen += sqlen;
    }

  /* Step 3. Compose the subtraces into one big final trace.
   *         This is wasteful because we're going to TraceDecompose()
   *         it again in both hmmsearch and hmmpfam to look at
   *         individual domains; but we do it anyway so the P7SmallViterbi
   *         interface looks exactly like the P7Viterbi interface. Maybe
   *         long traces shouldn't include all the N/J/C states anyway,
   *         since they're unambiguously implied.
   */

  /* Calculate total trace len and alloc;
   * nonemitting SNCT + nonemitting J's + emitting NJC
   */
  tlen += 4 + (ndom-1) + (L-totlen);
  P7AllocTrace(tlen, &tr);
  tr->tlen = tlen;

  /* Add N-terminal trace framework
   */
  tr->statetype[0] = STS;
  tr->nodeidx[0]   = 0;
  tr->pos[0]       = 0;
  tr->statetype[1] = STN;
  tr->nodeidx[1]   = 0;
  tr->pos[1]       = 0;
  tpos = 2;
                                /* add implied N's */
  for (pos = 1; pos <= ctr->pos[1]; pos++)
    {
      tr->statetype[tpos] = STN;
      tr->nodeidx[tpos]   = 0;
      tr->pos[tpos]       = pos;
      tpos++;
    }

  /* Add each subseq trace in, with its appropriate
   * sequence offset derived from the collapsed trace
   */
  for (i = 0; i < ndom; i++)
    {                           /* skip SN, CT framework at ends */
      for (t2 = 2; t2 < tarr[i]->tlen-2; t2++)
        {
          tr->statetype[tpos] = tarr[i]->statetype[t2];
          tr->nodeidx[tpos]   = tarr[i]->nodeidx[t2];
          if (tarr[i]->pos[t2] > 0)
            tr->pos[tpos]       = tarr[i]->pos[t2] + ctr->pos[i*2+1];
          else
            tr->pos[tpos]       = 0;
          tpos++;
        }
                                /* add nonemitting J or C */
      tr->statetype[tpos] = (i == ndom-1) ? STC : STJ;
      tr->nodeidx[tpos]   = 0;
      tr->pos[tpos]       = 0;
      tpos++;
                                /* add implied emitting J's */
      if (i != ndom-1)
        for (pos = ctr->pos[i*2+2]+1; pos <= ctr->pos[(i+1)*2+1]; pos++)
          {
            tr->statetype[tpos] = STJ;
            tr->nodeidx[tpos]   = 0;
            tr->pos[tpos]       = pos;
            tpos++;
          }
    }

                                /* add implied C's */
  for (pos = ctr->pos[ndom*2]+1; pos <= L; pos++)
    {
      tr->statetype[tpos] = STC;
      tr->nodeidx[tpos]   = 0;
      tr->pos[tpos]       = pos;
      tpos++;
    }
                                /* add terminal T */
  tr->statetype[tpos] = STT;
  tr->nodeidx[tpos]   = 0;
  tr->pos[tpos]       = 0;
  tpos++;

  for (i = 0; i < ndom; i++) P7FreeTrace(tarr[i]);
  free(tarr);
  P7FreeTrace(ctr);

  *ret_tr = tr;
  if (debug > 1) Rcout << "Leaving P7SmallViterbi" << std::endl;
  return sc;
}









NumericVector hmmsearch(char *sequence, int slen, std::string hmmDir, int domain, int molecule, int searchType) {
   
  // Input parameters:
  //   sequence   - The sequence being searched for rRNA genes
  //   slen       - The length of the sequence
  //   domain     - Archaea, Bacteria, or Eukarya
  //   molecule   - TSU (5/8s rRNA), SSU (16/18s rRNA), or LSU (23/28s rRNA)
  //   searchType - Initial or Full




  // The NumericVector matches will contain four values for each sequence alignment found by hmmsearch
  //   start  - the starting coordinate of the alignment in the searched sequence (integer)
  //   stop   - the ending   coordinate of the alignment in the searched sequence (integer)
  //   score  - the score of the alignment (real-valued)
  //   evalue - the e-value of the alignment (real-valued)


  NumericVector matches;

  // Beginning of actual function


  std::string hmmModel;

  struct plan7_s *hmm; // The structure into which the HMM will be read

  // Choose HMM file
  if      ((domain == ARC) && (molecule == TSU) && (searchType == INIT)) { hmmModel.assign(  "arc.tsu.rnammer.initial.hmm" ); }
  else if ((domain == ARC) && (molecule == SSU) && (searchType == INIT)) { hmmModel.assign(  "arc.ssu.rnammer.initial.hmm" ); }
  else if ((domain == ARC) && (molecule == LSU) && (searchType == INIT)) { hmmModel.assign(  "arc.lsu.rnammer.initial.hmm" ); }
  else if ((domain == BAC) && (molecule == TSU) && (searchType == INIT)) { hmmModel.assign(  "bac.tsu.rnammer.initial.hmm" ); }
  else if ((domain == BAC) && (molecule == SSU) && (searchType == INIT)) { hmmModel.assign(  "bac.ssu.rnammer.initial.hmm" ); }
  else if ((domain == BAC) && (molecule == LSU) && (searchType == INIT)) { hmmModel.assign(  "bac.lsu.rnammer.initial.hmm" ); }
  else if ((domain == EUK) && (molecule == TSU) && (searchType == INIT)) { hmmModel.assign(  "euk.tsu.rnammer.initial.hmm" ); }
  else if ((domain == EUK) && (molecule == SSU) && (searchType == INIT)) { hmmModel.assign(  "euk.ssu.rnammer.initial.hmm" ); }
  else if ((domain == EUK) && (molecule == LSU) && (searchType == INIT)) { hmmModel.assign(  "euk.lsu.rnammer.initial.hmm" ); }
  else if ((domain == ARC) && (molecule == TSU) && (searchType == FULL)) { hmmModel.assign(  "arc.tsu.rnammer.hmm"         ); }
  else if ((domain == ARC) && (molecule == SSU) && (searchType == FULL)) { hmmModel.assign(  "arc.ssu.rnammer.hmm"         ); }
  else if ((domain == ARC) && (molecule == LSU) && (searchType == FULL)) { hmmModel.assign(  "arc.lsu.rnammer.hmm"         ); }
  else if ((domain == BAC) && (molecule == TSU) && (searchType == FULL)) { hmmModel.assign(  "bac.tsu.rnammer.hmm"         ); }
  else if ((domain == BAC) && (molecule == SSU) && (searchType == FULL)) { hmmModel.assign(  "bac.ssu.rnammer.hmm"         ); }
  else if ((domain == BAC) && (molecule == LSU) && (searchType == FULL)) { hmmModel.assign(  "bac.lsu.rnammer.hmm"         ); }
  else if ((domain == EUK) && (molecule == TSU) && (searchType == FULL)) { hmmModel.assign(  "euk.tsu.rnammer.hmm"         ); }
  else if ((domain == EUK) && (molecule == SSU) && (searchType == FULL)) { hmmModel.assign(  "euk.ssu.rnammer.hmm"         ); }
  else if ((domain == EUK) && (molecule == LSU) && (searchType == FULL)) { hmmModel.assign(  "euk.lsu.rnammer.hmm"         ); }

  char hmmFile[150];

  strcpy(hmmFile, (hmmDir + hmmModel).c_str());

  if (debug > 1) Rcout << "In hmmsearch" << std::endl;
  if (debug > 1) Rcout << "Domain:    "  << domain  << std::endl;
  if (debug > 1) Rcout << "Molecule:  " << molecule << std::endl;
  if (debug > 1) Rcout << "Search:    " << searchType << std::endl;
  if (debug > 1) Rcout << "HMM file: |" << hmmFile << "|" << std::endl;






  FILE *fp;
  struct dpmatrix_s   *mx;
  struct p7trace_s    *tr;
  struct tophit_s     *ghit;      // list of top hits for whole sequences
  struct tophit_s     *dhit;      // list of top hits for domains




  if ((fp = fopen(hmmFile, "r")) == NULL) return("");

  read_asc20hmm(fp, &hmm);

  P7Logoddsify(hmm, !do_forward);

  if (debug > 1) Rcout << "HMM:" << std::endl;
  if (debug > 1) Rcout << "       name:                 " << hmm->name           << std::endl;
  if (debug > 1) Rcout << "       M:                    " << hmm->M              << std::endl;
  if (debug > 1) Rcout << "       hmm->tsc[TMM]   [1] = " << hmm->tsc[TMM]   [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->tsc[TIM]   [1] = " << hmm->tsc[TIM]   [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->bsc        [1] = " << hmm->bsc        [1] << std::endl;    // DEBUG - MRL ... check progress
  if (debug > 1) Rcout << "       hmm->tsc[TDM]   [1] = " << hmm->tsc[TDM]   [1] << std::endl;    // DEBUG - MRL ... check progress




  // Create a DP matrix, initially only two rows big, but growable.
  // We overalloc by 25 rows (L dimension) when we grow.
  // Not growable in model dimension, since we know the hmm size.

  mx = CreatePlan7Matrix(1, hmm->M, 25, 0);

  if (debug > 1) Rcout << "mx:" << std::endl;
  if (debug > 1) Rcout << "maxN:" << mx->maxN << std::endl;
  if (debug > 1) Rcout << "maxM:" << mx->maxM << std::endl;
  if (debug > 1) Rcout << "padN:" << mx->padN << std::endl;
  if (debug > 1) Rcout << "padM:" << mx->padM << std::endl;


  // Digitize the sequence

  unsigned char *dsq;
  dsq = DigitizeSequence(sequence, slen);


  // Recover a trace by Viterbi

  float sc;           // score of an HMM search

  if (P7ViterbiSpaceOK(slen, hmm->M, mx)) {
    sc = P7Viterbi(dsq, slen, hmm, mx, &tr);
  }
  else {
    sc = P7SmallViterbi(dsq, slen, hmm, mx, &tr);
  }

  struct threshold_s  *thresh;

  thresh = (struct threshold_s *) malloc(sizeof(struct threshold_s)); if (thresh == NULL) Rcpp::stop("Memory allocation failed for thresh!\n");

  thresh->globT =   0.0;     // -T    parameter
  thresh->globE = 1e-05;     // -E    parameter
  thresh->domT  =   0.0;     // -domT parameter
  thresh->domE  = 1e-05;     // -domE parameter

  ghit = AllocTophits(200);         // per-seq hits: 200=lumpsize
  dhit = AllocTophits(200);         // domain hits:  200=lumpsize



  // These values SHOULD be correct, since this implementation only looks at a single sequence
  int nseq  = 1;
  thresh->Z = 1;

  double pvalue = PValue(hmm, sc);
  double evalue = thresh->Z ? (double) thresh->Z * pvalue : (double) nseq * pvalue;

  if (sc >= thresh->globT && evalue <= thresh->globE) {
     sc = PostprocessSignificantHit(ghit,
                                    dhit,
                                    tr,
                                    hmm,
                                    dsq,
                                //  sqinfo.len,
                                    slen,
                                //  sqinfo.name,
                                //  sqinfo.flags & SQINFO_ACC  ? sqinfo.acc  : NULL,
                                //  sqinfo.flags & SQINFO_DESC ? sqinfo.desc : NULL,
                                    do_forward,
                                    sc,
                                    do_null2,
                                    thresh,
                                    FALSE); /* FALSE-> not hmmpfam mode, hmmsearch mode */
  }


  if (debug > 0) Rcout << "Number of hits reported: " << dhit->num << std::endl;


  int i;
  int nreported;      // # of hits reported in a list


  for (i = 0, nreported = 0; i < dhit->num; i++)
    {

      evalue = dhit->unsrt[i].pvalue * (double) thresh->Z;

      if (dhit->unsrt[i].motherp * (double) thresh->Z > thresh->globE || dhit->unsrt[i].mothersc < thresh->globT)
         continue;
      else if (evalue <= thresh->domE && sc >= thresh->domT) {
        if (debug > 1) Rcout << dhit->unsrt[i].sqfrom << " " << dhit->unsrt[i].sqto << " " << dhit->unsrt[i].score << " " << evalue << std::endl;
        matches.push_back(dhit->unsrt[i].sqfrom);
        matches.push_back(dhit->unsrt[i].sqto);
        matches.push_back(dhit->unsrt[i].score);
        matches.push_back(evalue);
        nreported++;
      }
    }


  if (debug > 0) Rcout << "     Size of matches: " << matches.size() << std::endl;
  return matches;

   
}



// [[Rcpp::export]]

DataFrame hmmAccess(CharacterVector sequence, CharacterVector reverse, int domain, int molecule, CharacterVector hmmDirectory) {

  #include <iostream>
  #include <string>

  // This function takes information from the R layer,
  //   makes appropriate conversions for C++, and
  //   sets up calls to hmmsearch.

  using namespace std;

  if (debug > 1) Rcout << "In hmmAccess " << std::endl;

  // Convert the forward and reverse sequences to character strings

  std::string sss;
  sss.assign(sequence[0]);
  char *seq = &sss[0];

  std::string rrr;
  rrr.assign(reverse[0]);
  char *rev = &rrr[0];

  int slen = sss.length();

  if (debug > 1) Rcout << "Sequence length: " << slen << std::endl;

  // Convert the HMM Directory identifier to a standard C++ string

  std::string hmmDir;
  hmmDir.assign(hmmDirectory[0]);
  
  if (debug > 1) Rcout << "HMM Directory: " << hmmDir << std::endl;


  // *********************
  // * Call to HMMSEARCH *
  // *********************

  int    start, stop;
  float  score;
  double evalue;

  // "Set flanking regions around spotter hits"

  int flank;

  if      (molecule == TSU) flank =  150;
  else if (molecule == SSU) flank = 2500;
  else if (molecule == LSU) flank = 4500;
  else                      flank =    0;      /* added to prevent compiler warning */

  int subseq_beg, subseq_end;

  IntegerVector   return_start ;
  IntegerVector   return_stop  ;
  CharacterVector return_strand;
  NumericVector   return_score ;
  NumericVector   return_evalue;
  CharacterVector return_rrna  ;


  // Forward Strand

  {
    NumericVector search_results;
  
    search_results = hmmsearch(seq, slen, hmmDir, domain, molecule, INIT);
  
    int search_size = search_results.size(),
        sub_search_size;
  
    for (int i = 0; i < search_size; i+=4) {
      subseq_beg = search_results[i]   - flank;  if (subseq_beg < 1   ) subseq_beg = 1   ;
      subseq_end = search_results[i+1] + flank;  if (subseq_end > slen) subseq_end = slen;
  
      int subslen = subseq_end - subseq_beg + 1;
  
      std::string subsss = sss.substr(subseq_beg-1, subslen);
      char *subseq = &subsss[0];
      
      NumericVector sub_search_results;
      sub_search_results = hmmsearch(subseq, subslen, hmmDir, domain, molecule, FULL);
      sub_search_size = sub_search_results.size();
  
      for (int j = 0; j < sub_search_size; j+=4) {
        start  = sub_search_results[j]   + subseq_beg - 1;
        stop   = sub_search_results[j+1] + subseq_beg - 1;
        score  = sub_search_results[j+2]                 ;
        evalue = sub_search_results[j+3]                 ;
  
        std::string rrna = sss.substr(start-1,stop-start+1);
  
        return_start.push_back  (start)  ;
        return_stop.push_back   (stop)   ;
        return_strand.push_back ("+")    ;
        return_score.push_back  (score)  ;
        return_evalue.push_back (evalue) ;
        return_rrna.push_back   (rrna)   ;
      }
    }
  }


  // Reverse Strand

  {
    NumericVector search_results;
  
    search_results = hmmsearch(rev, slen, hmmDir, domain, molecule, INIT);
  
    int search_size = search_results.size(),
        sub_search_size;
  
    for (int i = 0; i < search_size; i+=4) {
      if (debug > 0) Rcout << "   Targeted search " << (i/4)+1 << std::endl;
      subseq_beg = search_results[i]   - flank;  if (subseq_beg < 1   ) subseq_beg = 1   ;
      subseq_end = search_results[i+1] + flank;  if (subseq_end > slen) subseq_end = slen;
  
      int subslen = subseq_end - subseq_beg + 1;

      std::string subrrr = rrr.substr(subseq_beg-1, subslen);
      char *subrev = &subrrr[0];
      
      NumericVector sub_search_results;
      sub_search_results = hmmsearch(subrev, subslen, hmmDir, domain, molecule, FULL);
      sub_search_size = sub_search_results.size();
  
      for (int j = 0; j < sub_search_size; j+=4) {
        start  = sub_search_results[j]   + subseq_beg - 1;
        stop   = sub_search_results[j+1] + subseq_beg - 1;
        
        // find the search result on the "-" strand
        std::string rrna = rrr.substr(start-1,stop-start+1);

        // redefine coordinates to "+" strand
        stop   = slen - (sub_search_results[j]   + subseq_beg - 1) + 1;
        start  = slen - (sub_search_results[j+1] + subseq_beg - 1) + 1;
        score  = sub_search_results[j+2]                              ;
        evalue = sub_search_results[j+3]                              ;
  
        return_start.push_back  (start)  ;
        return_stop.push_back   (stop)   ;
        return_strand.push_back ("-")    ;
        return_score.push_back  (score)  ;
        return_evalue.push_back (evalue) ;
        return_rrna.push_back   (rrna)   ;
      }
    }
  }


  Rcpp::DataFrame DF;

  DF["begin" ] = return_start ;
  DF["end"   ] = return_stop  ;
  DF["strand"] = return_strand;
  DF["score" ] = return_score ;
  DF["evalue"] = return_evalue;
  DF["gene"  ] = return_rrna  ;

  return(DF);

  




  // Output number of calls to various functions:
  //   Set debug to 3 on line 18
  //   Move return(DF); to below block

  if (debug == 3) {
    Rcout << "AllocPlan7Body_count  = " << AllocPlan7Body_count  << std::endl;
    Rcout << "AllocPlan7Matrix_count  = " << AllocPlan7Matrix_count  << std::endl;
    Rcout << "AllocPlan7Shell_count  = " << AllocPlan7Shell_count  << std::endl;
    Rcout << "AllocTophits_count  = " << AllocTophits_count  << std::endl;
    Rcout << "CreatePlan7Matrix_count  = " << CreatePlan7Matrix_count  << std::endl;
    Rcout << "DegenerateSymbolScore_count  = " << DegenerateSymbolScore_count  << std::endl;
    Rcout << "DigitizeSequence_count  = " << DigitizeSequence_count  << std::endl;
    Rcout << "ExtremeValueP_count  = " << ExtremeValueP_count  << std::endl;
    Rcout << "FAdd_count  = " << FAdd_count  << std::endl;
    Rcout << "FArgMax_count  = " << FArgMax_count  << std::endl;
    Rcout << "FNorm_count  = " << FNorm_count  << std::endl;
    Rcout << "FScale_count  = " << FScale_count  << std::endl;
    Rcout << "FSet_count  = " << FSet_count  << std::endl;
    Rcout << "FSum_count  = " << FSum_count  << std::endl;
    Rcout << "FreePlan7Matrix_count  = " << FreePlan7Matrix_count  << std::endl;
    Rcout << "FreePlan7_count  = " << FreePlan7_count  << std::endl;
    Rcout << "GrowTophits_count  = " << GrowTophits_count  << std::endl;
    Rcout << "ILogsum_count  = " << ILogsum_count  << std::endl;
    Rcout << "LogSum_count  = " << LogSum_count  << std::endl;
    Rcout << "P7AllocTrace_count  = " << P7AllocTrace_count  << std::endl;
    Rcout << "P7FreeTrace_count  = " << P7FreeTrace_count  << std::endl;
    Rcout << "P7Logoddsify_count  = " << P7Logoddsify_count  << std::endl;
    Rcout << "P7ParsingViterbi_count  = " << P7ParsingViterbi_count  << std::endl;
    Rcout << "P7ReallocTrace_count  = " << P7ReallocTrace_count  << std::endl;
    Rcout << "P7ReverseTrace_count  = " << P7ReverseTrace_count  << std::endl;
    Rcout << "P7SmallViterbiSize_count  = " << P7SmallViterbiSize_count  << std::endl;
    Rcout << "P7SmallViterbi_count  = " << P7SmallViterbi_count  << std::endl;
    Rcout << "P7TraceScore_count  = " << P7TraceScore_count  << std::endl;
    Rcout << "P7ViterbiSize_count  = " << P7ViterbiSize_count  << std::endl;
    Rcout << "P7ViterbiSpaceOK_count  = " << P7ViterbiSpaceOK_count  << std::endl;
    Rcout << "P7ViterbiTrace_count  = " << P7ViterbiTrace_count  << std::endl;
    Rcout << "P7Viterbi_count  = " << P7Viterbi_count  << std::endl;
    Rcout << "P7WeeViterbi_count  = " << P7WeeViterbi_count  << std::endl;
    Rcout << "P7WeeViterbiSize_count  = " << P7WeeViterbiSize_count  << std::endl;
    Rcout << "PValue_count  = " << PValue_count  << std::endl;
    Rcout << "Plan7Renormalize_count  = " << Plan7Renormalize_count  << std::endl;
    Rcout << "Plan7SetName_count  = " << Plan7SetName_count  << std::endl;
    Rcout << "PostprocessSignificantHit_count  = " << PostprocessSignificantHit_count  << std::endl;
    Rcout << "Prob2Score_count  = " << Prob2Score_count  << std::endl;
    Rcout << "RegisterHit_count  = " << RegisterHit_count  << std::endl;
    Rcout << "ResizePlan7Matrix_count  = " << ResizePlan7Matrix_count  << std::endl;
    Rcout << "Score2Prob_count  = " << Score2Prob_count  << std::endl;
    Rcout << "Scorify_count  = " << Scorify_count  << std::endl;
    Rcout << "SetAlphabet_count  = " << SetAlphabet_count  << std::endl;
    Rcout << "Strdup_count  = " << Strdup_count  << std::endl;
    Rcout << "StringChop_count  = " << StringChop_count  << std::endl;
    Rcout << "SymbolIndex_count  = " << SymbolIndex_count  << std::endl;
    Rcout << "TraceDecompose_count  = " << TraceDecompose_count  << std::endl;
    Rcout << "TraceScoreCorrection_count  = " << TraceScoreCorrection_count  << std::endl;
    Rcout << "TraceSimpleBounds_count  = " << TraceSimpleBounds_count  << std::endl;
    Rcout << "TransitionScoreLookup_count  = " << TransitionScoreLookup_count  << std::endl;
    Rcout << "ascii2prob_count  = " << ascii2prob_count  << std::endl;
    Rcout << "get_wee_midpt_count  = " << get_wee_midpt_count  << std::endl;
    Rcout << "read_asc20hmm_count  = " << read_asc20hmm_count  << std::endl;
    Rcout << "set_degenerate_count  = " << set_degenerate_count  << std::endl;
  }


}
