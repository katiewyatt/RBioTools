.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to RBiotools!\n\u00A9 2023, Michael R. Leuze <RBiotools@gmail.com>\nDo not distribute without permission.")
}
