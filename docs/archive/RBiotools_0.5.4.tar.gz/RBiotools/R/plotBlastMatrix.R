#' plotBlastMatrix
#'
#' Creates an SVG file in the working directory for a BLAST matrix for a set of genomes
#'
#' @param proteinGrouping a homology matrix data frame constructed by \code{runLinclust} containing protein grouping information
#' @param organismIdentifier character vector indicating the name to be used for organisms; options are \code{"accessionNumber"}, \code{"fullName"} or \code{"shortName"}; \code{"fullName"} is recommended for a diverse, multi-species set of genomes; \code{"shortName"} is recommended for a single-species set of genomes.
#' @param digits integer indicating the number of decimal digits to be displayed in homology percentage; values 0, 1, and 2 are supported.
#'
#' @details \code{plotBlastMatrix} creates a SVG file containing a figure that displays, for a set of genomes, homology between pairs of genomes and homology within genomes. \code{plotBlastMatrix} uses a "protein grouping" constructed by \code{runLinclust}. The protein grouping is returned from \code{runLinclust} as a homology matrix, with a column for each genome and a row for each protein group. Each homology matrix entry is a count of proteins for a genome / group combination.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("AP012306", "KK583188", "U00096", "CP000802", "CP000800") # E. coli genomes
#' proteinGrouping <- runLinclust(myGenomes)
#' plotBlastMatrix(proteinGrouping)
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom grDevices dev.cur
#' @importFrom grImport  grid.picture PostScriptTrace readPicture
#' @importFrom methods   as




plotBlastMatrix <- function(proteinGrouping, organismIdentifier = "shortName", digits = 0) {

  # Check whether number of displayed decimal digits for percentage homology is within bounds
  if ((digits != 0) && (digits != 1) & (digits != 2)) {
    message(paste0("digits value: ", digits, " is not supported. Setting to 0"))
    digits <- 0 
  } 

  if (digits == 0) { percentFontSize <- 135 }
  if (digits == 1) { percentFontSize <- 110 }
  if (digits == 2) { percentFontSize <-  85 }

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  get("orgData.df", envir = .GlobalEnv)


  # Check whether the argument is a panGenome or a data.frame ...

  if ((class(proteinGrouping) == "pgFullLoc") || (class(proteinGrouping) == "data.frame")) {
    
    # Use the pangenome matrix to compute intra- and inter-genome homology
  
    oCnt <- as(proteinGrouping, 'matrix')  # ortholog counts

    # Which identifiers will be used?
    # -------------------------------
    # Use organism accession number as identifier
    if (organismIdentifier == "accessionNumber") {
      organismNames <- dimnames(oCnt)[[2]]
    }
    else
    # Use organism full name as identifier: species + strain (+ substrain)
    if (organismIdentifier == "fullName") {
      organismNames <- NULL
      for (aaa in dimnames(oCnt)[[2]]) {
        organismNames <- c(organismNames, orgName.df[orgName.df$accession == as.name(aaa),]$fullName)
      }
    }
    else
    # Use only strain (+ substrain) as organism identifier
    if (organismIdentifier == "shortName") {
      organismNames <- NULL
      for (aaa in dimnames(oCnt)[[2]]) {
        organismNames <- c(organismNames, orgName.df[orgName.df$accession == as.name(aaa),]$shortName)
      }
    }
    else {
      # organism identifier not recognized, default to short name
      message(paste0("organismIdentifier value: ", organismIdentifier, " invalid. Defaulting to shortName"))
      organismNames <- NULL
      for (aaa in dimnames(oCnt)[[2]]) {
        organismNames <- c(organismNames, orgName.df[orgName.df$accession == as.name(aaa),]$shortName)
      }
    }

    # Compute unions and intersections
    # --------------------------------

    homologyMatrix <- matrix(nrow = ncol(oCnt), ncol = ncol(oCnt))

    share <- matrix(nrow = ncol(oCnt), ncol = ncol(oCnt))
    total <- matrix(nrow = ncol(oCnt), ncol = ncol(oCnt))
  
    for (i in 1:ncol(oCnt)) {
      share[i,i] <- sum(oCnt[,i] > 1)    # Gene families with more than one member
      total[i,i] <- sum(oCnt[,i] > 0)    # Total number of gene families
      homologyMatrix[i,i] <- share[i,i] / total[i,i]
    }

    diagMax <- max(diag(homologyMatrix))
    diagMin <- min(diag(homologyMatrix))
 
    matMax <- 0.0
    matMin <- 1.0
  
    for (i in 1:ncol(oCnt)) {
      for (j in i:ncol(oCnt)) {
        if (i != j) {
          share[i,j] <- sum(oCnt[,i] > 0 & oCnt[,j] > 0)    # Union
          total[i,j] <- sum(oCnt[,i] > 0 | oCnt[,j] > 0)    # Intersection
          homologyMatrix[i,j] <- share[i,j] / total[i,j]
          if (homologyMatrix[i,j] > matMax) { matMax <- homologyMatrix[i,j] }
          if (homologyMatrix[i,j] < matMin) { matMin <- homologyMatrix[i,j] }
        }
      }
    }
  }

  else {
    cat("The argument for plotBlastMatrix must be a pangenome or a protein grouping.\n")
    cat("Pangenome example:\n")
    cat("  > myPanGenome <- buildPanGenome(myGenomes)\n")
    cat("  > plotBlastMatrix(myPanGenome)\n")
    cat("Protein grouping example:\n")
    cat("  > myProteinGrouping <- runLinclust(myGenomes)\n")
    cat("  > plotBlastMatrix(myProteinGrouping)\n")

    return()
  }
  

    
    
  # Write an SVG file for the Blast Matrix figure

  svg_file <- "BlastMatrix.svg"

  # Determine size of plot
  numOrganisms <- ncol(oCnt)

  plotWidth <- numOrganisms * 100 + 400     # 200pt on both sides for organism labels
                                            #   This should be sufficent space.
                                            #   A tighter bound based on plotted organisms is possible.
  plotHeight <- numOrganisms * 50 + 500     # 200pt on top for organism labels
                                            # 300pt on bottom for legend
  


  write('<svg version="1.1"',                                                                svg_file               )
  write('   baseProfile="full"',                                                             svg_file, append = TRUE)
  write(paste0('   width="', plotWidth, '" height="', plotHeight, '"'),                      svg_file, append = TRUE)
  write('   xmlns="http://www.w3.org/2000/svg"',                                             svg_file, append = TRUE)
  write('   xmlns:xlink="http://www.w3.org/1999/xlink">',                                    svg_file, append = TRUE)

  # A rectangle to show the boundaries of the plot
  # write(paste0('<rect width="', plotWidth, '" height="', plotHeight, '" stroke="black" stroke-width="10" style="fill:rgb(200,200,250)" />'), svg_file, append = TRUE)

  write('   <defs>',                                                                         svg_file, append = TRUE)
  write('     <rect id = "element"',                                                         svg_file, append = TRUE)
  write('           x="0" y="0" width="70.71067811" height="70.71067811" rx="10"',           svg_file, append = TRUE)
  write('           stroke="black" stroke-width="2"',                                        svg_file, append = TRUE)
  write('           transform = "rotate(-45 0 0)"/>',                                        svg_file, append = TRUE)
  write('   </defs>',                                                                        svg_file, append = TRUE)
 

  
  # Introduce a scaling factor to keep the maximum homology value away from total red, green, or blue,
  # ... which are the only colors this image currently supports.

  cScale <- 0.6     # 1.0 - no color scaling, 0.0 - total scaling (everthing white)


  xStart <- 200                         # 200pt border on the left
  yStart <- 200 + numOrganisms * 50     # 200pt border on the top

  xLoc <- xStart
  yLoc <- yStart


  # Compute and plot homology WITHIN proteomes
  # ------------------------------------------

  maxWithin <- 0
  minWithin <- 1
  
  dHM <- diag(homologyMatrix)
  for (i in 1:length(dHM)) {
    # compute "homology within proteome" percentage
    hVal <- dHM[i]
      if (hVal > maxWithin) { maxWithin <- hVal }
      if (hVal < minWithin) { minWithin <- hVal }

    # Original
    # hValPerCent <- paste0(format(round(hVal*10000)/100, nsmall = 2), "%")  # character string %-age

    # Replacement
    hValPerCent <- paste0(format(round(hVal*100, digits), nsmall = digits), "%")  # character string %-age


    colVal <- 1 - ((hVal - diagMin)/(diagMax - diagMin)) * cScale
    shareVal <- share[i,i]
    totalVal <- total[i,i]

    # convert colVal to hex
    colValHex <- as.hexmode(round(colVal*255))

    write(paste0('   <use xlink:href="#element" x="', xLoc, '" y="', yLoc, '" fill="#ff', colValHex, colValHex, '" />'),          svg_file, append = TRUE)
    write(paste0('   <text x="', xLoc+50, '" y="', yLoc-5,  '" class="strong" text-anchor="middle" font-size="', percentFontSize, '%">',
                      hValPerCent, '</text>'),                                                                                    svg_file, append = TRUE)
    write(paste0('   <text x="', xLoc+50, '" y="', yLoc+10, '" class="strong" text-anchor="middle" font-size="85%">',
                      shareVal, ' / ', totalVal, '</text>'),                                                                      svg_file, append = TRUE)

    xLoc <- xLoc + 100
  }

  # Compute and plot homology BETWEEN proteomes
  # -------------------------------------------

  maxBetween <- 0
  minBetween <- 1

  # Give homologyMatrix a shorter name!
  HM <- homologyMatrix
  n <- nrow(HM) - 1
  
  xStart <- xStart + 50
  yStart <- yStart - 50

  xLoc <- xStart
  yLoc <- yStart

  for (i in 1:n) {
    vecHM <- HM[row(HM) == (col(HM) - i)]
    vecSH <- share[row(share) == (col(share) - i)]
    vecTO <- total[row(total) == (col(total) - i)]

    for (j in 1:length(vecHM)) {
      # compute "homology between proteomes" percentage
      hVal <- vecHM[j]
        if (hVal > maxBetween) { maxBetween <- hVal }
        if (hVal < minBetween) { minBetween <- hVal }
      hValPerCent <- paste0(format(round(hVal*100, digits), nsmall = digits), "%")  # character string %-age

      colVal <- 1 - ((hVal - matMin)/(matMax - matMin)) * cScale
      shareVal <- vecSH[j]
      totalVal <- vecTO[j]

      # convert colVal to hex
      colValHex <- as.hexmode(round(colVal*255))

      write(paste0('   <use xlink:href="#element" x="', xLoc, '" y="', yLoc, '" fill="#', colValHex, 'ff', colValHex, '" />'),      svg_file, append = TRUE)
      write(paste0('   <text x="', xLoc+50, '" y="', yLoc-5,  '" class="strong" text-anchor="middle" font-size="', percentFontSize, '%">',
                        hValPerCent, '</text>'),                                                                                    svg_file, append = TRUE)
      write(paste0('   <text x="', xLoc+50, '" y="', yLoc+10, '" class="strong" text-anchor="middle" font-size="85%">',
                        shareVal, ' / ', totalVal, '</text>'),                                                                      svg_file, append = TRUE)


      xLoc <- xLoc+100
    }

    xStart <- xStart + 50
    yStart <- yStart - 50

    xLoc <- xStart
    yLoc <- yStart
  }

  # Add organism labels
  # -------------------

  # LEFT side
  #   start 5pt above and to the left of the upper left border of the lower left block
  xStart <- 213                                # adjustments to nudge the label away from block and center the line
  yStart <- 172 + (numOrganisms * 50)

  xLoc <- xStart
  yLoc <- yStart

  for (i in 1:nrow(HM)) {
    write(paste0('   <text x="0" y="0" font-style="italic" text-anchor="end" transform="translate(', xLoc, ',', yLoc, '), rotate(45)">', organismNames[i], '</text>'), svg_file, append = TRUE)
    xLoc <- xLoc + 50
    yLoc <- yLoc - 50
  }


  # RIGHT side
  #   start 5pt above and to the right of the upper right border of the top block
  xStart <- 283 + ((numOrganisms - 1) * 50)    # adjustments to nudge the label away from block and center the line
  yStart <- 223

  xLoc <- xStart
  yLoc <- yStart

  for (i in 1:nrow(HM)) {
    write(paste0('   <text x="0" y="0" font-style="italic" text-anchor="start" transform="translate(', xLoc, ',', yLoc, '), rotate(-45)">', organismNames[i], '</text>'), svg_file, append = TRUE)
    xLoc <- xLoc + 50
    yLoc <- yLoc + 50
  }

  # Add the legend
  # --------------

  colorVal <- as.hexmode(round((1-cScale)*255))

  write('  <defs>',                                                                           svg_file, append = TRUE)
  write('    <linearGradient id="red_linear" x1="0%" y1="0%" x2="100%" y2="0%">',             svg_file, append = TRUE)
  write('       <stop offset="0%"   stop-color="#ffffff"/>',                                  svg_file, append = TRUE)
  write(paste0('       <stop offset="100%" stop-color="#ff', colorVal, colorVal, '"/>'),      svg_file, append = TRUE)
  write('    </linearGradient>',                                                              svg_file, append = TRUE)
  write('    <linearGradient id="green_linear" x1="0%" y1="0%" x2="100%" y2="0%">',           svg_file, append = TRUE)
  write('       <stop offset="0%"   stop-color="#ffffff"/>',                                  svg_file, append = TRUE)
  write(paste0('       <stop offset="100%" stop-color="#', colorVal, 'ff', colorVal, '"/>'),  svg_file, append = TRUE)
  write('    </linearGradient>',                                                              svg_file, append = TRUE)
  write('  </defs>',                                                                          svg_file, append = TRUE)


  xCenter <- 200 + numOrganisms * 50
  yCenter <- 200 + numOrganisms * 50 + 50

  xSize <- 250
  ySize <-  30

  gapSize  <- 100
  dropSize <-  50

  nudgeDown <- 15

  write(paste0(
    '  <rect x="', xCenter - (gapSize / 2) - xSize, '" y="', yCenter + dropSize, '" width="', xSize, '" height="', ySize,
           '" stroke="black" stroke-width="2" fill="url(#red_linear)" />'),                                                  svg_file, append = TRUE)
  write(paste0(
    '  <rect x="', xCenter + (gapSize / 2),         '" y="', yCenter + dropSize, '" width="', xSize, '" height="', ySize,
           '" stroke="black" stroke-width="2" fill="url(#green_linear)" />'),                                                svg_file, append = TRUE)

  # Labels
  write(paste0(' <text x="', xCenter - (gapSize / 2) - (xSize / 2), '" y="', yCenter + dropSize - 10,
               '" class="strong" text-anchor="middle">Homology within proteomes</text>'),                                    svg_file, append = TRUE)

  minWithinPC <- paste0(format(round(minWithin*10000)/100, nsmall = 2), "%")  # character string %-age
  write(paste0(' <text x="', xCenter - (gapSize / 2) - xSize, '" y="', yCenter + dropSize + ySize + nudgeDown,
               '" class="strong" text-anchor="middle" font-size="100%">', minWithinPC, '</text>'),                           svg_file, append = TRUE)

  maxWithinPC <- paste0(format(round(maxWithin*10000)/100, nsmall = 2), "%")  # character string %-age
  write(paste0(' <text x="', xCenter - (gapSize / 2),         '" y="', yCenter + dropSize + ySize + nudgeDown,
               '" class="strong" text-anchor="middle" font-size="100%">', maxWithinPC, '</text>'),                           svg_file, append = TRUE)


  write(paste0(' <text x="', xCenter + (gapSize / 2) + (xSize / 2), '" y="', yCenter + dropSize - 10,
               '" class="strong" text-anchor="middle">Homology between proteomes</text>'),                                   svg_file, append = TRUE)

  minBetweenPC <- paste0(format(round(minBetween*10000)/100, nsmall = 2), "%")  # character string %-age
  write(paste0(' <text x="', xCenter + (gapSize / 2),         '" y="', yCenter + dropSize + ySize + nudgeDown,
               '" class="strong" text-anchor="middle" font-size="100%">', minBetweenPC, '</text>'),                          svg_file, append = TRUE)

  maxBetweenPC <- paste0(format(round(maxBetween*10000)/100, nsmall = 2), "%")  # character string %-age
  write(paste0(' <text x="', xCenter + (gapSize / 2) + xSize, '" y="', yCenter + dropSize + ySize + nudgeDown,
               '" class="strong" text-anchor="middle" font-size="100%">', maxBetweenPC, '</text>'),                          svg_file, append = TRUE)




  # END of SVG file
  write('</svg>', svg_file, append = TRUE)


if (FALSE) {

  write("%!PS", ps_file)

  write("/entry", ps_file, append = TRUE)
  write("{", ps_file, append = TRUE)
  write("  /S exch def", ps_file, append = TRUE)     # Shared gene families
  write("  /P exch def", ps_file, append = TRUE)     # Percentage homology
  write("  /B exch def", ps_file, append = TRUE)
  write("  /G exch def", ps_file, append = TRUE)
  write("  /R exch def", ps_file, append = TRUE)
  write("  /rad 30 def", ps_file, append = TRUE)
  
  write("  newpath", ps_file, append = TRUE)
  write("   -100 100 moveto", ps_file, append = TRUE)
  write("      0  200  100  100 rad arcto", ps_file, append = TRUE)
  write("    200    0  100 -100 rad arcto", ps_file, append = TRUE)
  write("      0 -200 -100 -100 rad arcto", ps_file, append = TRUE)
  write("   -200    0 -100  100 rad arcto", ps_file, append = TRUE)
  write("   closepath", ps_file, append = TRUE)
  write("   gsave", ps_file, append = TRUE)
  write("   R G B setrgbcolor fill", ps_file, append = TRUE)
  write("   grestore", ps_file, append = TRUE)
  write("   8 setlinewidth", ps_file, append = TRUE)
  write("   stroke", ps_file, append = TRUE)

  write("  /Times-Bold findfont 60 scalefont setfont", ps_file, append = TRUE)
  write("   0", ps_file, append = TRUE)
  write("   P stringwidth pop sub 2 div", ps_file, append = TRUE)
  write("   20 moveto", ps_file, append = TRUE)     # Y location
  write("   P show", ps_file, append = TRUE)

  write("  /Times-Bold findfont 45 scalefont setfont", ps_file, append = TRUE)
  write("   0", ps_file, append = TRUE)
  write("   S stringwidth pop sub 2 div", ps_file, append = TRUE)
  write("   -30 moveto", ps_file, append = TRUE)     # Y location
  write("   S show", ps_file, append = TRUE)
  write("} def", ps_file, append = TRUE)
  
  write("gsave", ps_file, append = TRUE)
  
  
  # Introduce a scaling factor to keep the maximum homology value away from total red, green, or blue,
  # ... which are the only colors this image currently supports.
  
  cScale <- 0.6     # 1.0 - no scaling, 0.0 - total scaling (everthing white)
  
  dHM <- diag(homologyMatrix)
  for (i in 1:length(dHM)) {
     hVal <- dHM[i]
     colVal <- 1 - ((hVal - diagMin)/(diagMax - diagMin)) * cScale
     cV <- format(colVal, digits = 5, nsmall = 5)
     shareVal <- share[i,i]
     totalVal <- total[i,i]
     write(paste0("1 ", cV, " ", cV, " (", format(round(hVal*100, 2), nsmall = 2), "%) (", shareVal, " / ", totalVal, ") entry"), ps_file, append = TRUE)
     write("400 0 translate", ps_file, append = TRUE)
  }
  

  # Give homologyMatrix a shorter name!
  HM <- homologyMatrix; n <- nrow(HM) - 1
  
  xLoc <- 0
  yLoc <- 0

  for (i in 1:n) {
    write("grestore", ps_file, append = TRUE)
    xLoc <- xLoc + 200
    yLoc <- yLoc + 200
    write(paste0(xLoc, " ", yLoc, " translate"), ps_file, append = TRUE)
    vecHM <- HM[row(HM) == (col(HM) - i)]
    vecSH <- share[row(share) == (col(share) - i)]
    vecTO <- total[row(total) == (col(total) - i)]
    for (j in 1:length(vecHM)) {
      hVal <- vecHM[j]
      shareVal <- vecSH[j]
      totalVal <- vecTO[j]
      colVal <- 1 - ((hVal - matMin)/(matMax - matMin)) * cScale
      cV <- format(colVal, digits = 5, nsmall = 5)
      write(paste0(cV, " 1 ", cV, " (", format(round(hVal*100, 2), nsmall = 2), "%) (", shareVal, " / ", totalVal, ") entry"), ps_file, append = TRUE)
      write("400 0 translate", ps_file, append = TRUE)
    }
  }
  
  
  write(paste0("/YY ", (n + 1)*200, " def"), ps_file, append = TRUE)
  write("grestore", ps_file, append = TRUE)
  write("pop pop", ps_file, append = TRUE)
  write("/labelL", ps_file, append = TRUE)
  write("{", ps_file, append = TRUE)
  write("  /L exch def", ps_file, append = TRUE)
  write("  /Times-Italic findfont 75 scalefont setfont", ps_file, append = TRUE)
  write("  0 0 moveto", ps_file, append = TRUE)
  write("  0", ps_file, append = TRUE)
  write("  L stringwidth pop sub", ps_file, append = TRUE)
  write("  0 moveto", ps_file, append = TRUE)
  write("  L show", ps_file, append = TRUE)
  write("} def", ps_file, append = TRUE)
  write("/labelR", ps_file, append = TRUE)
  write("{", ps_file, append = TRUE)
  write("  /L exch def", ps_file, append = TRUE)
  write("  /Times-Italic findfont 75 scalefont setfont", ps_file, append = TRUE)
  write("  0 0 moveto", ps_file, append = TRUE)
  write("  L show", ps_file, append = TRUE)
  write("} def", ps_file, append = TRUE)
  write("0 0 moveto", ps_file, append = TRUE)
  
  write("/X -140 def", ps_file, append = TRUE)
  write("/Y  120 def", ps_file, append = TRUE)
  
  oNames <- dimnames(oCnt)[[2]]
  
  for (i in 1:(n + 1)) {
    write("gsave", ps_file, append = TRUE)
    write("X Y translate", ps_file, append = TRUE)
    write("-45 rotate", ps_file, append = TRUE)
    write(paste0("(", organismNames[i], ") labelL"), ps_file, append = TRUE)
    write("grestore", ps_file, append = TRUE)
    write("/X X 200 add def", ps_file, append = TRUE)
    write("/Y Y 200 add def", ps_file, append = TRUE)
  }
  
  write("/X YY 60 sub def", ps_file, append = TRUE)
  write("/Y YY 80 sub def", ps_file, append = TRUE)
  
  for (i in 1:(n + 1)) {
    write("gsave", ps_file, append = TRUE)
    write("X Y translate", ps_file, append = TRUE)
    write("45 rotate", ps_file, append = TRUE)
    write(paste0("(", organismNames[i], ") labelR"), ps_file, append = TRUE)
    write("grestore", ps_file, append = TRUE)
    write("/X X 200 add def", ps_file, append = TRUE)
    write("/Y Y 200 sub def", ps_file, append = TRUE)
  }
  
  # Define a PostScript function to draw a line
  write("/drawLine {", ps_file, append = TRUE)
  write("  /H exch def", ps_file, append = TRUE)
  write("  8 setlinewidth", ps_file, append = TRUE)
  write("  0 0 moveto", ps_file, append = TRUE)
  write("  0 0 H sub lineto", ps_file, append = TRUE)
  write("  stroke", ps_file, append = TRUE)
  write("} def", ps_file, append = TRUE)
  
  # Scaling - by (n+0.5)/9.5 - below this point is quirky
  # because (0,0) in the PostScript coordinate system
  # in located in the center of the lower left box.
  
  # Define a PostScript function to draw a colour legend
  write("/drawLegend {", ps_file, append = TRUE)
  write("  /X exch def", ps_file, append = TRUE)
  write("  /Y exch def", ps_file, append = TRUE)
  write("  /W exch def   % width of bar in points", ps_file, append = TRUE)
  write("  /H exch def   % height of bar in points", ps_file, append = TRUE)
  write("  /C exch def   % 0 = Blue, 1 = Red, 2 = Green", ps_file, append = TRUE)
  write("  /A exch def   % maximum percentage", ps_file, append = TRUE)
  write("  /B exch def   % minimum percentage", ps_file, append = TRUE)
  write("  /L exch def   % legend", ps_file, append = TRUE)
  write("  gsave", ps_file, append = TRUE)
  write("  X Y translate", ps_file, append = TRUE)
  write("  gsave", ps_file, append = TRUE)
  
  write(paste(1, -cScale/200, 1 - cScale), ps_file, append = TRUE)
  write(paste("  { dup 1 3 C roll setrgbcolor H drawLine", 2.875, "0 translate } for"), ps_file, append = TRUE)
  write("  1 1 1 setrgbcolor H drawLine", ps_file, append = TRUE)
  write("  grestore", ps_file, append = TRUE)
  write("  8 setlinewidth", ps_file, append = TRUE)
  write("  newpath", ps_file, append = TRUE)
  write("    0 0 H sub moveto", ps_file, append = TRUE)
  write("    0 0 lineto", ps_file, append = TRUE)
  write("    W 0 lineto", ps_file, append = TRUE)
  write("    W 0 H sub lineto", ps_file, append = TRUE)
  write("  closepath", ps_file, append = TRUE)
  write("  0 setgray", ps_file, append = TRUE)
  write("  stroke", ps_file, append = TRUE)
  
  write("  /Times-Roman findfont 35 scalefont setfont", ps_file, append = TRUE)
  write("  0 0 H sub moveto", ps_file, append = TRUE)
  write("  0 -30 rlineto", ps_file, append = TRUE)
  write("  stroke", ps_file, append = TRUE)
  
  write("  W 0 H sub moveto", ps_file, append = TRUE)
  write("  0 -30 rlineto", ps_file, append = TRUE)
  write("  stroke", ps_file, append = TRUE)
  
  write("  W", ps_file, append = TRUE)
  write("  A stringwidth pop", ps_file, append = TRUE)
  write("  2 div sub", ps_file, append = TRUE)
  write("  -150 moveto", ps_file, append = TRUE)
  write("  A show", ps_file, append = TRUE)
  
  write("  0", ps_file, append = TRUE)
  write("  B stringwidth pop", ps_file, append = TRUE)
  write("  2 div sub", ps_file, append = TRUE)
  write("  -150 moveto", ps_file, append = TRUE)
  write("  B show", ps_file, append = TRUE)
  
  write("  /Times-Roman findfont 40 scalefont setfont", ps_file, append = TRUE)
  write("  W 2 div", ps_file, append = TRUE)
  write("  L stringwidth pop", ps_file, append = TRUE)
  write("  2 div sub", ps_file, append = TRUE)
  write("  25 moveto", ps_file, append = TRUE)
  write("  L show", ps_file, append = TRUE)
  
  write("  grestore", ps_file, append = TRUE)
  write("} def", ps_file, append = TRUE)
  
  write("  gsave", ps_file, append = TRUE)
  
  # Draw colour legends for intra- and inter-genome homology
  write(paste(200*n, -300 - (n - 5)*20, "translate"), ps_file, append = TRUE)
  
  write(paste((n + 1)/6.0, (n + 1)/6.0, "scale"), ps_file, append = TRUE)
  
  write(paste0("(Homology within proteome) (",  format(round(diagMin*100, 2), nsmall = 2), "%) (", format(round(diagMax*100, 2), nsmall = 2), "%) 1 ",
     85, " ", 575, " ", 0, " ", -750, " drawLegend"), ps_file, append = TRUE)
  write(paste0("(Homology between proteomes) (", format(round( matMin*100, 2), nsmall = 2), "%) (", format(round( matMax*100, 2), nsmall = 2), "%) 2 ",
     85, " ", 575, " ", 0, " ",  175, " drawLegend"), ps_file, append = TRUE)

  write("  grestore", ps_file, append = TRUE)   # We may be adding some other features later
  

  # Write to a postScript file???
  # writeLines(ps_file, "BlastMatrix.ps")


  # Display PostScript
  
  # clear the plot space if necessary
  if (dev.cur() != 1) {  # device 1 is the null device
    dev.off()
  }

  PostScriptTrace(ps_file)
  pic_xml <- readPicture(paste0(ps_file, ".xml"))
  grid.picture(pic_xml)

}

}
