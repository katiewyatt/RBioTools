#' writeProteinFAA
#'
#' A function for writing protein FASTA files to the current working directory for a set of genomes
#'
#' @references Hyall et al. \emph{Prodigal: prokaryotic gene recognition and translation initiation site identification:} \url{https://doi.org/10.1186/1471-2105-11-119}
#' @references Hyatt \emph{Understanding the Prodigal Output:} \url{https://github.com/hyattpd/Prodigal/wiki/Understanding-the-Prodigal-Output}
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details \code{writeProteinFAA} writes protein FASTA files to the current working directory for a set of genomes. The genomes are specified in a list of GenBank (or GenBank-like) accession numbers. The protein FASTA files use Prodigal formatting for the headers; each protein translation is written on a single line and terminated with a \code{"*"} character.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' genomeSet <- c(
#'   "AP012306",  # Escherichia coli str. K-12 substr. MDS42 DNA
#'   "CP018295"   # Bacillus subtilis subsp. subtilis strain J-5
#' )
#'
#' runProdigal(genomeSet)
#'
#' writeProteinFAA(genomeSet)
#' }



writeProteinFAA <- function(accessionList)
{

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }
  
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df",    envir = .GlobalEnv)
  get("orgData.df",    envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls",  envir = .GlobalEnv)

  for (uncheckedID in accessionList) {

    aaa <- checkIdentifier(uncheckedID)

    genes.df <- ProdigalCalls[which(ProdigalCalls$accession == aaa),]

    if (nrow(genes.df) == 0) {
      cat(paste("Calling protein genes for accession ID:", organism, "\n"))
      runProdigal(organism, verbose = FALSE)
      genes.df <- ProdigalCalls[which(ProdigalCalls$accession == aaa),]
    }
  
    # Change the strand from "+"/"-" to 1/-1

    genes.df[which(genes.df$strand == '+'),]$strand <-  1
    genes.df[which(genes.df$strand == '-'),]$strand <- -1

    fasta_output <- paste0( ">",
                             genes.df$accession, "_", (1:nrow(genes.df)), " # ",
                             genes.df$begin,                              " # ",
                             genes.df$end,                                " # ",
                             genes.df$strand,                             " # ",

                             "ID="        , genes.df$identifier, ";",
                             "partial="   , genes.df$partial   , ";",
                             "start_type=", genes.df$start_type, ";",
                             "rbs_motif=" , genes.df$rbs_motif , ";",
                             "rbs_spacer=", genes.df$rbs_spacer, ";",
                             "gc_cont="   , genes.df$gc_cont,   "\n",

                             genes.df$protein
                           )
  
     # Write the file to the current working directory

     write(fasta_output, paste0(aaa, ".faa"))
  }
}
