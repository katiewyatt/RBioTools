#' fetchRNAmmerCalls
#'
#' Extracts RNAmmer gene calls from the RBiotools global data store
#'
#' @param accessionList character vector containing GenBank accession numbers -- only the first vector element is used
#'
#' @details This function fetches RNAmmer gene calls for a genome specified by an accession number. If the \code{accessionList} character vector parameter contains multiple accession numbers, only the first is used. It fetches the RNAmmer gene calls by subsetting the global data frame \code{RNAmmerCalls}. Entries where the value in \code{RNAmmerCalls$accession} matches the specified accession number are selected, and the results are returned in a data frame. If the genome specified by the accession number has not been downloaded or if all types of rRNA genes have not been called, \code{RBiotools} will perform these tasks automatically.
#'
#' \emph{\strong{Note:} \code{fetchRNAmmerCalls} will seldom, if ever, need to be called directly by the \code{RBiotools} user. It is included in \code{RBiotools} primarily as a tool for future development of functionality.}
#'
#' @return genes.df
#'
#' @examples
#' \dontrun{
#' geneCalls <- fetchRNAmmerCalls("U00096")
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"

fetchRNAmmerCalls <- function(accessionList) {

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  ## Use only the first accession ID in accessionList
  aaa <- accessionList[1]

  checkedID <- checkIdentifier(aaa)

  if (length(accessionList) > 1) {
    cat(paste("The accession list contains multiple genomes.\n"))
    cat(paste("RNAmmer gene calls will be returned for the first genome with accession ID:", checkedID, "\n"))
  }

  # Subset the global RNAmmer data frame
  genes.df <- RNAmmerCalls[which(RNAmmerCalls$accession == checkedID),]

  # Renumber the rows in the subsetted data frame
  if (nrow(genes.df) > 0) {
    row.names(genes.df) <- 1:nrow(genes.df)
  }
  else {
    cat(paste("No RNAmmer gene calls found for genome with accession ID:", checkedID, "\n"))
  }

  return(genes.df)
}
