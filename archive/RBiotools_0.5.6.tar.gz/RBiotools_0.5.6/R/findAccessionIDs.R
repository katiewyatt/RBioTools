#' findAccessionIDs
#'
#' Searches for complete chromosome GenBank sequence assession numbers
#'
#' @param accessionID character GenBank accession number
#' @param includeStrain logical indicates whether strain is to be included in the search, default is FALSE
#'
#' @details \code{findAccessionIDs} is potentially useful for constructing sets of genomes for analysis.
#'
#' \code{findAccessionIDs} searches for complete GenBank chromosomal sequences associated with a specified GenBank accession number. It uses \code{rentrez} functions that work with the NCBI Eutils API to search and download summary data from the GenBank nucleotide database.
#'
#' \strong{Note:} There are some situations in which \code{findAccessionIDs} will fail, in particular, when the name of the organism is \strong{not} included in the title of the GenBank record. An example of this is accession number \code{CP000800}, for which the organism name is \emph{Escherichia coli O139:H28 str. E24377A} and the title of the GenBank record is \emph{Escherichia coli E24377A, complete genome}. A more subtle mismatch occurs for accession number \code{FM180568}, where the organism name contains \emph{str.} preceding the strain, but the title of the GenBank record does not. A more sophisticated parsing of organism names and record titles may improve the performance of this function, but it is unlikely that all inconsistencies will be identified and resolved.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' accessionID <- "NZ_JVDK01001145"  # Burkholderia cenocepacia strain 530_BMUL (WGS)
#' findAccessionIDs(accessionID)     # This call returns (as of May 2019)
#'                                   # 57 IDs for complete chromosomal sequences from:
#'                                   # * 20 Burkholderia cenocepacia strains and
#'                                   # *  4 complete phage sequences
#' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"
#'
#' @importFrom rentrez entrez_search entrez_summary



findAccessionIDs <- function(accessionID, includeStrain = FALSE, maxReturn = 50)
{

  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }
  
  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df", envir = .GlobalEnv)
  get("orgData.df", envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls", envir = .GlobalEnv)

  # Find organism and strain for the specified accessionID

  goodDownload <- tryCatch(
    {
      summary <- entrez_summary(db = "nucleotide", id = accessionID)
      flag <- TRUE
    },
    error = function(e) {
      cat(paste0("No complete chromosomal sequences associated with accession ID ", accessionID, "found\n" ))
      flag <- FALSE
    }
  )

  if (goodDownload) { # valid accession ID
    organismName <- summary$organism
    strainName   <- summary$strain

    if (includeStrain) {
      query <- paste0(
                 "(",
                    organismName, "[Title]",
                    " AND ",
                    strainName, "[Title]",
                    " AND ",
                    "((chromosome[Title] AND complete sequence[Title]) OR complete genome[Title])",
                 ")",
                 " NOT ",
                 "RefSeq.[Keyword]"
               )
    }
    else {
      query <- paste0(
                 "(",
                    organismName, "[Title]",
                    " AND ",
                    "((chromosome[Title] AND complete sequence[Title]) OR complete genome[Title])",
                 ")",
                 " NOT ",
                 "RefSeq.[Keyword]"
               )
    }

    ## cat(paste0(query, "\n"))

    complete <- entrez_search(db = "nucleotide", term = query, retmax = 10000)

    ## cat(paste0(complete$id, "\n"))
    
    numRet <- length(complete$id)

    if (numRet > maxReturn) {
      cat(paste0(numRet, " accession IDs found. Returning the first ", maxReturn, "\n"))
      numRet <- maxReturn
    }

    if (numRet > 0) {
      for (seqID in complete$id[1:numRet]) {
        summary <- entrez_summary(db = "nucleotide", id = seqID)
        cat(paste(summary$caption, ": "))
        cat(paste(summary$title, "\n"))
      }
    }
    else {
      cat(paste0("No accession IDs found for ", accessionID, "\n"))
    }
  }
}
