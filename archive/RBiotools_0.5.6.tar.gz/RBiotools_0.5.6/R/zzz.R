.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Welcome to RBiotools 0.5.6!\n\u00A9 2025, Michael R. Leuze <RBiotools@gmail.com>\nDo not distribute without permission.")
}
