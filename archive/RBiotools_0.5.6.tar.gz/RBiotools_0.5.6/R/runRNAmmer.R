#' runRNAmmer
#'
#' A convenience function that calls the \code{rnammer} gene calling function for a set of genomes and adds the results to the \code{RBiotools} global data store
#'
#' @param accessionList character vector containing GenBank accession numbers
#'
#' @details This convenience function calls the \code{rnammer} gene calling function for a set of genomes specified by accession numbers, using genomic sequences found in the global data list \code{GenomeSeqList}. If a genomic sequence is not found in the global data store for a specified accession number, the user is prompted to download genomic information using the function \code{downloadGenBank}. For each genome for which a genomic sequence is found, \code{runRNAmmer} adds the called genes to \code{RNAmmerCalls}, an \code{RBiotools} global data frame containing called genes, genomic coordinates, scores, and nucleotide sequences. The function \code{fetchRNAmmerCalls} can then be used to extract a data frame from \code{RNAmmerCalls} with gene calls for a specified genome.
#'
#' @return None
#'
#' @examples
#' \dontrun{
#' myGenomes <- c("CP003284",
#'                "CP003597",
#'                "NONSENSE", # This entry will be skipped, since a corresponding genomic sequence will not be found
#'                "CP003289",
#'                "CP006632"
#'               )
#' runRNAmmer(myGenomes) #' calledGenes <- fetchRNAmmerCalls("CP003284") #' }
#'
#' @useDynLib RBiotools
#' @exportPattern "^[[:alpha:]]+"



runRNAmmer <- function(accessionList, scope = "ALL") {


  # Check whether RBiotools has been initialized,
  #   that is, do the global variables exist?

  if (!exists("GenomeSeqList")) {   # NOT initialized
    initializeRBiotools()
  }

  ## Global variables

  get("GenomeSeqList", envir = .GlobalEnv)
  get("orgName.df",    envir = .GlobalEnv)
  get("orgData.df",    envir = .GlobalEnv)
  get("ProdigalCalls", envir = .GlobalEnv)
  get("RNAmmerCalls",  envir = .GlobalEnv)
  get("rRNAcalled.df", envir = .GlobalEnv)

  for (uncheckedID in accessionList) {   # The accessionList consists of unchecked IDs

    aaa <- checkIdentifier(uncheckedID)

    # Check whether the the genome has been downloaded from GenBank
   
    seqSet <- GenomeSeqList[aaa][[aaa]]
    if (is.null(seqSet)) {
      downloadGenBank(aaa)
    }

    if (scope == "ALL") {
      for (rRNA in c("TSU", "SSU", "LSU")) {
        if (subset(subset(rRNAcalled.df, accession == aaa), type == rRNA)$called == FALSE) {

          cat(paste0("Calling type ", rRNA, " rRNA genes for genome with accession ID: ", aaa, "\n"))
          seqSet <- GenomeSeqList[aaa][[aaa]]
          genes.df <- rnammer(seqSet, "BAC", rRNA)

          if (nrow(genes.df) > 0) {
            # Add the accession number of this organism as the first column of the data frame
            genes.df <- cbind(accession = aaa, genes.df)
        
            # Add calls to the global Prodigal data frame
            RNAmmerCalls <<- rbind(RNAmmerCalls, genes.df)

            # Note that rRNA genes have been called
            row <- which(rRNAcalled.df$accession == aaa & rRNAcalled.df$type == rRNA)
            rRNAcalled.df$called[row] <<- TRUE   # Assignment in parent environment
          }
        }
      }
    }


    else
    if (scope == "5s" || scope == "5S") {
      if (subset(subset(rRNAcalled.df, accession == aaa), type == "TSU")$called == FALSE) {

        cat(paste0("Calling type 'TSU' rRNA genes for genome with accession ID: ", aaa, "\n"))
        seqSet <- GenomeSeqList[aaa][[aaa]]
        genes.df <- rnammer(seqSet, "BAC", "TSU")

        if (nrow(genes.df) > 0) {
          # Add the accession number of this organism as the first column of the data frame
          genes.df <- cbind(accession = aaa, genes.df)
      
          # Add calls to the global Prodigal data frame
          RNAmmerCalls <<- rbind(RNAmmerCalls, genes.df)

          # Note that rRNA genes have been called
          row <- which(rRNAcalled.df$accession == aaa & rRNAcalled.df$type == "TSU")
          rRNAcalled.df$called[row] <<- TRUE   # Assignment in parent environment
        }
      }
    }


    else
    if (scope == "16s" || scope == "16S") {
      if (subset(subset(rRNAcalled.df, accession == aaa), type == "SSU")$called == FALSE) {

        cat(paste0("Calling type 'SSU' rRNA genes for genome with accession ID: ", aaa, "\n"))
        seqSet <- GenomeSeqList[aaa][[aaa]]
        genes.df <- rnammer(seqSet, "BAC", "SSU")

        if (nrow(genes.df) > 0) {
          # Add the accession number of this organism as the first column of the data frame
          genes.df <- cbind(accession = aaa, genes.df)
      
          # Add calls to the global Prodigal data frame
          RNAmmerCalls <<- rbind(RNAmmerCalls, genes.df)

          # Note that rRNA genes have been called
          row <- which(rRNAcalled.df$accession == aaa & rRNAcalled.df$type == "SSU")
          rRNAcalled.df$called[row] <<- TRUE   # Assignment in parent environment
        }
      }
    }


    else
    if (scope == "23s" || scope == "23S") {
      if (subset(subset(rRNAcalled.df, accession == aaa), type == "LSU")$called == FALSE) {

        cat(paste0("Calling type 'LSU' rRNA genes for genome with accession ID: ", aaa, "\n"))
        seqSet <- GenomeSeqList[aaa][[aaa]]
        genes.df <- rnammer(seqSet, "BAC", "LSU")

        if (nrow(genes.df) > 0) {
          # Add the accession number of this organism as the first column of the data frame
          genes.df <- cbind(accession = aaa, genes.df)
      
          # Add calls to the global Prodigal data frame
          RNAmmerCalls <<- rbind(RNAmmerCalls, genes.df)

          # Note that rRNA genes have been called
          row <- which(rRNAcalled.df$accession == aaa & rRNAcalled.df$type == "LSU")
          rRNAcalled.df$called[row] <<- TRUE   # Assignment in parent environment
        }
      }
    }

  }

}
